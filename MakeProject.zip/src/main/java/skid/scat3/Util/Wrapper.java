package skid.scat3.Util;

import net.minecraft.client.Minecraft;

public interface Wrapper
{
    Minecraft mc = Minecraft.getMinecraft();
}