package skid.scat3.Util.chams;

@FunctionalInterface
public interface ShaderProducer {
    FramebufferShader INSTANCE();
}

