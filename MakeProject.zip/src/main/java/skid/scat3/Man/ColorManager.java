package skid.scat3.Man;

import java.awt.Color;

import dev.madcat.m3dc3t.features.gui.components.Component;
import dev.madcat.m3dc3t.features.modules.client.ClickGui;
import skid.scat3.Util.ColorUtil;

public class ColorManager {
    private float red = 1.0f;
    private float blue = 1.0f;
    private float alpha = 1.0f;
    private float green = 1.0f;
    private Color color = new Color(this.red, this.green, this.blue, this.alpha);

    public void setRed(float f) {
        this.red = f;
        this.updateColor();
    }

    public void setBlue(float f) {
        this.blue = f;
        this.updateColor();
    }

    public void setColor(int n, int n2, int n3, int n4) {
        this.red = (float)n / 255.0f;
        this.green = (float)n2 / 255.0f;
        this.blue = (float)n3 / 255.0f;
        this.alpha = (float)n4 / 255.0f;
        this.updateColor();
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public int getColorAsInt() {
        return ColorUtil.toRGBA(this.color);
    }

    public void setGreen(float f) {
        this.green = f;
        this.updateColor();
    }


    public ColorManager() {
        Color current = new Color(-1);
    }


    public Color getColor() {
        return this.color;
    }

    public int getColorAsIntFullAlpha() {
        return ColorUtil.toRGBA(new Color(this.color.getRed(), this.color.getGreen(), this.color.getBlue(), 255));
    }

    public void setAlpha(float f) {
        this.alpha = f;
        this.updateColor();
    }


    public void updateColor() {
        this.setColor(new Color(this.red, this.green, this.blue, this.alpha));
    }


    public void setColor(float f, float f2, float f3, float f4) {
        this.red = f;
        this.green = f2;
        this.blue = f3;
        this.alpha = f4;
        this.updateColor();
    }
}

