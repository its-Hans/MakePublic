package skid.scat3.Event.events;

import dev.madcat.m3dc3t.event.EventStage;

public class Render3DEvent
extends EventStage {
    private final float partialTicks;

    public Render3DEvent(float f) {
        this.partialTicks = f;
    }

    public float getPartialTicks() {
        return this.partialTicks;
    }
}

