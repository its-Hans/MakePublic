package skid.scat3.Event.events;

import dev.madcat.m3dc3t.event.EventStage;

public class PlayerJumpEvent
extends EventStage {
    public final double motionX;
    public final double motionY;

    public PlayerJumpEvent(double d, double d2) {
        this.motionX = d;
        this.motionY = d2;
    }
}

