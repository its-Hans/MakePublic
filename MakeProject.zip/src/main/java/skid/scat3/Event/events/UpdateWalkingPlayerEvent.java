package skid.scat3.Event.events;

import dev.madcat.m3dc3t.event.EventStage;

public class UpdateWalkingPlayerEvent
extends EventStage {
    public UpdateWalkingPlayerEvent(int n) {
        super(n);
    }
}

