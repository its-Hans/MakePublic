package skid.scat3.Event.events;

import dev.madcat.m3dc3t.event.EventStage;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class NoRenderEvent
extends EventStage {
    public NoRenderEvent(int n) {
        super(n);
    }
}

