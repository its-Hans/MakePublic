package skid.scat3.Event.events;

import dev.madcat.m3dc3t.event.EventStage;
import net.minecraft.entity.player.EntityPlayer;

public class TotemPopEvent
extends EventStage {
    private final EntityPlayer entity;

    public TotemPopEvent(EntityPlayer entityPlayer) {
        this.entity = entityPlayer;
    }

    public EntityPlayer getEntity() {
        return this.entity;
    }
}

