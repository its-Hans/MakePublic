package skid.scat3.Event.events;

import dev.madcat.m3dc3t.event.EventStage;
import net.minecraft.entity.player.EntityPlayer;

public class DeathEvent
extends EventStage {
    public final EntityPlayer player;

    public DeathEvent(EntityPlayer entityPlayer) {
        this.player = entityPlayer;
    }
}

