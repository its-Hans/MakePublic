package skid.sxulu.Event;

import java.lang.reflect.InvocationTargetException;

import dev.madcat.m3dc3t.M3dC3t;
import dev.madcat.m3dc3t.util.Wrapper;
import dev.madcat.m3dc3t.manager.EventManager;

public abstract class Event {

	private static State state = State.PRE;
	private boolean cancelled;
	private final float partialTicks;

	public Event() {
		this.partialTicks = Wrapper.getMinecraft().getRenderPartialTicks();
	}

	public float getPartialTicks() {
		return partialTicks;
	}

	public static State getEventState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

	public enum State {PRE, POST}
	public boolean isCancelled() {
		return this.cancelled;
	}

	public void setCancelled(boolean cancelled) {
		this.cancelled = cancelled;
	}
}
