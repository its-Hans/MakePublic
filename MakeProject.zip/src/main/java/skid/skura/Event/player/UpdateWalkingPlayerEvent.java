package skid.skura.Event.player;

import dev.madcat.m3dc3t.event.EventStage;
import net.minecraft.client.Minecraft;

public class UpdateWalkingPlayerEvent extends EventStage
{
    protected float yaw;
    protected float pitch;
    
    public UpdateWalkingPlayerEvent(final int stage) {
        super(stage);
    }
    
    public void setRotation(final float yaw, final float pitch) {
        if (Minecraft.getMinecraft().player != null) {
            Minecraft.getMinecraft().player.rotationYawHead = yaw;
            Minecraft.getMinecraft().player.renderYawOffset = yaw;
        }
        this.setYaw(yaw);
        this.setPitch(pitch);
    }
    
    public void setYaw(final float yaw) {
        this.yaw = yaw;
    }
    
    public void setPitch(final float pitch) {
        this.pitch = pitch;
    }
}
