package skid.skura.Man;

import java.util.concurrent.ConcurrentHashMap;
import dev.madcat.m3dc3t.util.MathUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.Event;

public class RotationManager extends Event
{
    private static final Minecraft mc;
    private static final ConcurrentHashMap<Float, Float> rotationMap;
    
    private static boolean fullNullCheck() {
        return RotationManager.mc.player == null || RotationManager.mc.world == null;
    }
    
    public static void addRotations(final float yaw, final float pitch) {
        if (RotationManager.rotationMap != null) {
            RotationManager.rotationMap.put(yaw, pitch);
        }
    }
    
    public static void resetRotation() {
    }
    
    public void setPlayerRotations(final float yaw, final float pitch) {
        RotationManager.mc.player.rotationYaw = yaw;
        RotationManager.mc.player.rotationYawHead = yaw;
        RotationManager.mc.player.rotationPitch = pitch;
    }
    
    public void lookAtVec3d(final Vec3d vec3d) {
        final float[] angle = MathUtil.calcAngle(RotationManager.mc.player.getPositionEyes(RotationManager.mc.getRenderPartialTicks()), new Vec3d(vec3d.x, vec3d.y, vec3d.z));
        this.setPlayerRotations(angle[0], angle[1]);
    }
    
    public void lookAtVec3d(final double x, final double y, final double z) {
        final Vec3d vec3d = new Vec3d(x, y, z);
        this.lookAtVec3d(vec3d);
    }
    
    static {
        mc = Minecraft.getMinecraft();
        rotationMap = new ConcurrentHashMap<Float, Float>();
    }
}
