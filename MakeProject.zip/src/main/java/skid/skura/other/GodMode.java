package skid.skura.other;

import org.apache.commons.codec.digest.DigestUtils;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class GodMode {
    public static final String UrlGodMode = "https://pastebin.com/raw/B6mrQN1d"; //URL FOR HWID
    public static List<String> hwids = new ArrayList<>();

    public static String GensHWID()
    {
        return DigestUtils.sha256Hex
        (
                DigestUtils.sha256Hex
                    (System.getenv("os")
                        + "NanShengKeAiDeXiaoDongZuo"
                        + "XianZaiKaiShiDaJiao"
                        + System.getProperty("os.name")
                        + System.getProperty("os.arch")
                        + System.getProperty("user.name")
                        + System.getenv("PROCESSOR_LEVEL")
                        + System.getenv("PROCESSOR_REVISION")
                        + System.getenv("PROCESSOR_IDENTIFIER")
                        + System.getenv("PROCESSOR_ARCHITEW6432")
                        + "1145141919810"
                    )
        );
    }
    public static void crashOnYou()
    {

        if (!hwidCheck())
        {
            JOptionPane.showMessageDialog(null, "HWID verification failed! \\u000d your hwid is in logs..");
            Object[] L = null; while (true) {L = new Object[]{L};} //Crash
        } else { JOptionPane.showMessageDialog(null, "HWID verification successful!"); }
    }

    public static List<String> readURL()
    {
        List<String> s = new ArrayList<>();
        try
        {
            final URL url = new URL(GodMode.UrlGodMode);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(url.openStream()));
            String hwid;
            while ((hwid = bufferedReader.readLine()) != null) {s.add(hwid);}

        } catch (Exception e) {/* FMLLog.log.info(e); */}
        return s;
    }

    public static Boolean hwidCheck()
    {
        /*
        hwids = GodMode.readURL();
        boolean isHwidPresent = hwids.contains(GodMode.GensHWID());
        return isHwidPresent;
        */
        return true; //hwid down!
    }
}