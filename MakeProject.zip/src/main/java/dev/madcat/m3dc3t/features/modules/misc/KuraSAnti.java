package dev.madcat.m3dc3t.features.modules.misc;

import dev.madcat.m3dc3t.features.modules.Module;
import dev.madcat.m3dc3t.features.setting.Setting;
import dev.madcat.m3dc3t.util.BlockUtil;
import dev.madcat.m3dc3t.util.InventoryUtil;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class KuraSAnti extends Module
{
    private final Setting<Boolean> rotate;
    private int obsidian;
    
    public KuraSAnti() {
        super("KuraSAnti", "Anti push.", Category.MISC, true, false, false);
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", true));
        this.obsidian = -1;
    }
    
    public void onUpdate() {
        if (Module.fullNullCheck()) {return;}
        if (Module.mc.player == null || Module.mc.world == null) {return;}
        
        this.obsidian = InventoryUtil.findHotbarBlock(Blocks.OBSIDIAN);
        if (this.obsidian == -1) {return;}
        
        final BlockPos pos = new BlockPos(Module.mc.player.posX, Module.mc.player.posY, Module.mc.player.posZ);
        final BlockPos add = pos.add(1, 1, 0);
        Intrinsics.checkNotNullExpressionValue(add, "pos.add(1, 1, 0)");
        if (this.getBlock(add).getBlock() == Blocks.PISTON)
        {
            final BlockPos add2 = pos.add(-1, 0, 0);
            Intrinsics.checkNotNullExpressionValue(add2, "pos.add(-1, 0, 0)");

            if (this.getBlock(add2).getBlock() == Blocks.AIR)
            {
                final BlockPos add3 = pos.add(-1, 0, 0);
                Intrinsics.checkNotNullExpressionValue(add3, "pos.add(-1, 0, 0)");
                this.perform(add3);
            }
            else
            {
                final BlockPos add4 = pos.add(-1, 1, 0);
                Intrinsics.checkNotNullExpressionValue(add4, "pos.add(-1, 1, 0)");
                if (this.getBlock(add4).getBlock() == Blocks.AIR)
                {
                    final BlockPos add5 = pos.add(-1, 1, 0);
                    Intrinsics.checkNotNullExpressionValue(add5, "pos.add(-1, 1, 0)");
                    this.perform(add5);
                }
                else
                {
                    final BlockPos add6 = pos.add(-1, 2, 0);
                    Intrinsics.checkNotNullExpressionValue(add6, "pos.add(-1, 2, 0)");

                    if (this.getBlock(add6).getBlock() == Blocks.AIR)
                    {
                        final BlockPos add7 = pos.add(-1, 2, 0);
                        Intrinsics.checkNotNullExpressionValue(add7, "pos.add(-1, 2, 0)");
                        this.perform(add7);
                    }
                    else
                    {
                        final BlockPos add8 = pos.add(0, 2, 0);
                        Intrinsics.checkNotNullExpressionValue(add8, "pos.add(0, 2, 0)");
                        if (this.getBlock(add8).getBlock() == Blocks.AIR)
                        {
                            final BlockPos add9 = pos.add(0, 2, 0);
                            Intrinsics.checkNotNullExpressionValue(add9, "pos.add(0, 2, 0)");
                            this.perform(add9);
                        }
                    }
                }
            }
        }
        final BlockPos add10 = pos.add(-1, 1, 0);
        Intrinsics.checkNotNullExpressionValue(add10, "pos.add(-1, 1, 0)");

        if (this.getBlock(add10).getBlock() == Blocks.PISTON)
        {
            final BlockPos add11 = pos.add(1, 0, 0);
            Intrinsics.checkNotNullExpressionValue(add11, "pos.add(1, 0, 0)");
            if (this.getBlock(add11).getBlock() == Blocks.AIR)
            {
                final BlockPos add12 = pos.add(1, 0, 0);
                Intrinsics.checkNotNullExpressionValue(add12, "pos.add(1, 0, 0)");
                this.perform(add12);
            }
            else
            {
                final BlockPos add13 = pos.add(1, 1, 0);
                Intrinsics.checkNotNullExpressionValue(add13, "pos.add(1, 1, 0)");

                if (this.getBlock(add13).getBlock() == Blocks.AIR)
                {
                    final BlockPos add14 = pos.add(1, 1, 0);
                    Intrinsics.checkNotNullExpressionValue(add14, "pos.add(1, 1, 0)");
                    this.perform(add14);
                }
                else
                {
                    final BlockPos add15 = pos.add(1, 2, 0);
                    Intrinsics.checkNotNullExpressionValue(add15, "pos.add(1, 2, 0)");

                    if (this.getBlock(add15).getBlock() == Blocks.AIR)
                    {
                        final BlockPos add16 = pos.add(1, 2, 0);
                        Intrinsics.checkNotNullExpressionValue(add16, "pos.add(1, 2, 0)");
                        this.perform(add16);
                    }
                    else
                    {
                        final BlockPos add17 = pos.add(0, 2, 0);
                        Intrinsics.checkNotNullExpressionValue(add17, "pos.add(0, 2, 0)");
                        if (this.getBlock(add17).getBlock() == Blocks.AIR)
                        {
                            final BlockPos add18 = pos.add(0, 2, 0);
                            Intrinsics.checkNotNullExpressionValue(add18, "pos.add(0, 2, 0)");
                            this.perform(add18);
                        }
                    }
                }
            }
        }
        final BlockPos add19 = pos.add(0, 1, 1);
        Intrinsics.checkNotNullExpressionValue(add19, "pos.add(0, 1, 1)");
        if (this.getBlock(add19).getBlock() == Blocks.PISTON)
        {
            final BlockPos add20 = pos.add(0, 0, -1);
            Intrinsics.checkNotNullExpressionValue(add20, "pos.add(0, 0, -1)");

            if (this.getBlock(add20).getBlock() == Blocks.AIR)
            {
                final BlockPos add21 = pos.add(0, 0, -1);
                Intrinsics.checkNotNullExpressionValue(add21, "pos.add(0, 0, -1)");
                this.perform(add21);
            }
            else
            {
                final BlockPos add22 = pos.add(0, 1, -1);
                Intrinsics.checkNotNullExpressionValue(add22, "pos.add(0, 1, -1)");
                if (this.getBlock(add22).getBlock() == Blocks.AIR)
                {
                    final BlockPos add23 = pos.add(0, 1, -1);
                    Intrinsics.checkNotNullExpressionValue(add23, "pos.add(0, 1, -1)");
                    this.perform(add23);
                }
                else
                {
                    final BlockPos add24 = pos.add(0, 2, -1);
                    Intrinsics.checkNotNullExpressionValue(add24, "pos.add(0, 2, -1)");

                    if (this.getBlock(add24).getBlock() == Blocks.AIR)
                    {
                        final BlockPos add25 = pos.add(0, 2, -1);
                        Intrinsics.checkNotNullExpressionValue(add25, "pos.add(0, 2, -1)");
                        this.perform(add25);
                    }
                    else
                    {
                        final BlockPos add26 = pos.add(0, 2, 0);
                        Intrinsics.checkNotNullExpressionValue(add26, "pos.add(0, 2, 0)");

                        if (this.getBlock(add26).getBlock() == Blocks.AIR)
                        {
                            final BlockPos add27 = pos.add(0, 2, 0);
                            Intrinsics.checkNotNullExpressionValue(add27, "pos.add(0, 2, 0)");
                            this.perform(add27);
                        }
                    }
                }
            }
        }
        final BlockPos add28 = pos.add(0, 1, -1);
        Intrinsics.checkNotNullExpressionValue(add28, "pos.add(0, 1, -1)");
        if (this.getBlock(add28).getBlock() == Blocks.PISTON) {
            final BlockPos add29 = pos.add(0, 0, 1);
            Intrinsics.checkNotNullExpressionValue(add29, "pos.add(0, 0, 1)");
            if (this.getBlock(add29).getBlock() == Blocks.AIR) {
                final BlockPos add30 = pos.add(0, 0, 1);
                Intrinsics.checkNotNullExpressionValue(add30, "pos.add(0, 0, 1)");
                this.perform(add30);
            }
            else {
                final BlockPos add31 = pos.add(0, 1, 1);
                Intrinsics.checkNotNullExpressionValue(add31, "pos.add(0, 1, 1)");
                if (this.getBlock(add31).getBlock() == Blocks.AIR) {
                    final BlockPos add32 = pos.add(0, 1, 1);
                    Intrinsics.checkNotNullExpressionValue(add32, "pos.add(0, 1, 1)");
                    this.perform(add32);
                }
                else {
                    final BlockPos add33 = pos.add(0, 2, 1);
                    Intrinsics.checkNotNullExpressionValue(add33, "pos.add(0, 2, 1)");
                    if (this.getBlock(add33).getBlock() == Blocks.AIR) {
                        final BlockPos add34 = pos.add(0, 2, 1);
                        Intrinsics.checkNotNullExpressionValue(add34, "pos.add(0, 2, 1)");
                        this.perform(add34);
                    }
                    else {
                        final BlockPos add35 = pos.add(0, 2, 0);
                        Intrinsics.checkNotNullExpressionValue(add35, "pos.add(0, 2, 0)");
                        if (this.getBlock(add35).getBlock() == Blocks.AIR) {
                            final BlockPos add36 = pos.add(0, 2, 0);
                            Intrinsics.checkNotNullExpressionValue(add36, "pos.add(0, 2, 0)");
                            this.perform(add36);
                        }
                    }
                }
            }
        }
        final BlockPos add37 = pos.add(1, 1, 0);
        Intrinsics.checkNotNullExpressionValue(add37, "pos.add(1, 1, 0)");

        if (this.getBlock(add37).getBlock() == Blocks.STICKY_PISTON)
        {
            final BlockPos add38 = pos.add(-1, 0, 0);
            Intrinsics.checkNotNullExpressionValue(add38, "pos.add(-1, 0, 0)");
            if (this.getBlock(add38).getBlock() == Blocks.AIR)
            {
                final BlockPos add39 = pos.add(-1, 0, 0);
                Intrinsics.checkNotNullExpressionValue(add39, "pos.add(-1, 0, 0)");
                this.perform(add39);
            }
            else
            {
                final BlockPos add40 = pos.add(-1, 1, 0);
                Intrinsics.checkNotNullExpressionValue(add40, "pos.add(-1, 1, 0)");
                if (this.getBlock(add40).getBlock() == Blocks.AIR)
                {
                    final BlockPos add41 = pos.add(-1, 1, 0);
                    Intrinsics.checkNotNullExpressionValue(add41, "pos.add(-1, 1, 0)");
                    this.perform(add41);
                }
                else
                {
                    final BlockPos add42 = pos.add(-1, 2, 0);
                    Intrinsics.checkNotNullExpressionValue(add42, "pos.add(-1, 2, 0)");
                    if (this.getBlock(add42).getBlock() == Blocks.AIR)
                    {
                        final BlockPos add43 = pos.add(-1, 2, 0);
                        Intrinsics.checkNotNullExpressionValue(add43, "pos.add(-1, 2, 0)");
                        this.perform(add43);
                    }
                    else
                    {
                        final BlockPos add44 = pos.add(0, 2, 0);
                        Intrinsics.checkNotNullExpressionValue(add44, "pos.add(0, 2, 0)");
                        if (this.getBlock(add44).getBlock() == Blocks.AIR)
                        {
                            final BlockPos add45 = pos.add(0, 2, 0);
                            Intrinsics.checkNotNullExpressionValue(add45, "pos.add(0, 2, 0)");
                            this.perform(add45);
                        }
                    }
                }
            }
        }
        final BlockPos add46 = pos.add(-1, 1, 0);
        Intrinsics.checkNotNullExpressionValue(add46, "pos.add(-1, 1, 0)");
        if (this.getBlock(add46).getBlock() == Blocks.STICKY_PISTON)
        {
            final BlockPos add47 = pos.add(1, 0, 0);
            Intrinsics.checkNotNullExpressionValue(add47, "pos.add(1, 0, 0)");
            if (this.getBlock(add47).getBlock() == Blocks.AIR)
            {
                final BlockPos add48 = pos.add(1, 0, 0);
                Intrinsics.checkNotNullExpressionValue(add48, "pos.add(1, 0, 0)");
                this.perform(add48);
            }
            else
            {
                final BlockPos add49 = pos.add(1, 1, 0);
                Intrinsics.checkNotNullExpressionValue(add49, "pos.add(1, 1, 0)");

                if (this.getBlock(add49).getBlock() == Blocks.AIR)
                {
                    final BlockPos add50 = pos.add(1, 1, 0);
                    Intrinsics.checkNotNullExpressionValue(add50, "pos.add(1, 1, 0)");
                    this.perform(add50);
                }
                else
                {
                    final BlockPos add51 = pos.add(1, 2, 0);
                    Intrinsics.checkNotNullExpressionValue(add51, "pos.add(1, 2, 0)");
                    if (this.getBlock(add51).getBlock() == Blocks.AIR)
                    {
                        final BlockPos add52 = pos.add(1, 2, 0);
                        Intrinsics.checkNotNullExpressionValue(add52, "pos.add(1, 2, 0)");
                        this.perform(add52);
                    }
                    else
                    {
                        final BlockPos add53 = pos.add(0, 2, 0);
                        Intrinsics.checkNotNullExpressionValue(add53, "pos.add(0, 2, 0)");

                        if (this.getBlock(add53).getBlock() == Blocks.AIR)
                        {
                            final BlockPos add54 = pos.add(0, 2, 0);
                            Intrinsics.checkNotNullExpressionValue(add54, "pos.add(0, 2, 0)");
                            this.perform(add54);
                        }
                    }
                }
            }
        }
        final BlockPos add55 = pos.add(0, 1, 1);
        Intrinsics.checkNotNullExpressionValue(add55, "pos.add(0, 1, 1)");

        if (this.getBlock(add55).getBlock() == Blocks.STICKY_PISTON)
        {
            final BlockPos add56 = pos.add(0, 0, -1);
            Intrinsics.checkNotNullExpressionValue(add56, "pos.add(0, 0, -1)");

            if (this.getBlock(add56).getBlock() == Blocks.AIR)
            {
                final BlockPos add57 = pos.add(0, 0, -1);
                Intrinsics.checkNotNullExpressionValue(add57, "pos.add(0, 0, -1)");
                this.perform(add57);
            }
            else
            {
                final BlockPos add58 = pos.add(0, 1, -1);
                Intrinsics.checkNotNullExpressionValue(add58, "pos.add(0, 1, -1)");
                if (this.getBlock(add58).getBlock() == Blocks.AIR)
                {
                    final BlockPos add59 = pos.add(0, 1, -1);
                    Intrinsics.checkNotNullExpressionValue(add59, "pos.add(0, 1, -1)");
                    this.perform(add59);
                }
                else
                {
                    final BlockPos add60 = pos.add(0, 2, -1);
                    Intrinsics.checkNotNullExpressionValue(add60, "pos.add(0, 2, -1)");
                    if (this.getBlock(add60).getBlock() == Blocks.AIR)
                    {
                        final BlockPos add61 = pos.add(0, 2, -1);
                        Intrinsics.checkNotNullExpressionValue(add61, "pos.add(0, 2, -1)");
                        this.perform(add61);
                    }
                    else
                    {
                        final BlockPos add62 = pos.add(0, 2, 0);
                        Intrinsics.checkNotNullExpressionValue(add62, "pos.add(0, 2, 0)");
                        if (this.getBlock(add62).getBlock() == Blocks.AIR)
                        {
                            final BlockPos add63 = pos.add(0, 2, 0);
                            Intrinsics.checkNotNullExpressionValue(add63, "pos.add(0, 2, 0)");
                            this.perform(add63);
                        }
                    }
                }
            }
        }
        final BlockPos add64 = pos.add(0, 1, -1);
        Intrinsics.checkNotNullExpressionValue(add64, "pos.add(0, 1, -1)");
        if (this.getBlock(add64).getBlock() == Blocks.STICKY_PISTON)
        {
            final BlockPos add65 = pos.add(0, 1, 1);
            Intrinsics.checkNotNullExpressionValue(add65, "pos.add(0, 1, 1)");
            if (this.getBlock(add65).getBlock() == Blocks.AIR)
            {
                final BlockPos add66 = pos.add(0, 1, 1);
                Intrinsics.checkNotNullExpressionValue(add66, "pos.add(0, 1, 1)");
                this.perform(add66);
            }
            else
            {
                final BlockPos add67 = pos.add(0, 1, 1);
                Intrinsics.checkNotNullExpressionValue(add67, "pos.add(0, 1, 1)");
                if (this.getBlock(add67).getBlock() == Blocks.AIR)
                {
                    final BlockPos add68 = pos.add(0, 1, 1);
                    Intrinsics.checkNotNullExpressionValue(add68, "pos.add(0, 1, 1)");
                    this.perform(add68);
                }
                else
                {
                    final BlockPos add69 = pos.add(0, 2, 1);
                    Intrinsics.checkNotNullExpressionValue(add69, "pos.add(0, 2, 1)");
                    if (this.getBlock(add69).getBlock() == Blocks.AIR)
                    {
                        final BlockPos add70 = pos.add(0, 2, 1);
                        Intrinsics.checkNotNullExpressionValue(add70, "pos.add(0, 2, 1)");
                        this.perform(add70);
                    }
                    else
                    {
                        final BlockPos add71 = pos.add(0, 2, 0);
                        Intrinsics.checkNotNullExpressionValue(add71, "pos.add(0, 2, 0)");
                        if (this.getBlock(add71).getBlock() == Blocks.AIR)
                        {
                            final BlockPos add72 = pos.add(0, 2, 0);
                            Intrinsics.checkNotNullExpressionValue(add72, "pos.add(0, 2, 0)");
                            this.perform(add72);
                        }
                    }
                }
            }
        }
    }

    private final void switchToSlot(final int slot)
    {
        if (Module.fullNullCheck()) {return;}

        Module.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot));
        Module.mc.player.inventory.currentItem = slot;
        Module.mc.playerController.updateController();
    }

    private final IBlockState getBlock(final BlockPos block)
    {
        final IBlockState getBlockState = Module.mc.world.getBlockState(block);
        Intrinsics.checkNotNullExpressionValue(getBlockState, "mc.world.getBlockState(block)");
        return getBlockState;
    }

    private final void perform(final BlockPos pos) {
        if (Module.fullNullCheck()) {return;}

        final int old = Module.mc.player.inventory.currentItem;
        this.switchToSlot(this.obsidian);
        final EnumHand main_HAND = EnumHand.MAIN_HAND;
        final Boolean value = this.rotate.getValue();
        Intrinsics.checkNotNullExpressionValue(value, "rotate.value");
        BlockUtil.placeBlock(pos, main_HAND, value, true, false);
        this.switchToSlot(old);
    }
}
