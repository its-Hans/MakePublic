package dev.madcat.m3dc3t.features.modules.combat;

import dev.madcat.m3dc3t.features.modules.useless.CAT3INSTANT;
import dev.madcat.m3dc3t.features.setting.Setting;
import dev.madcat.m3dc3t.M3dC3t;
import dev.madcat.m3dc3t.features.modules.Module;

import skid.scat3.Util.BlockUtil;
import skid.scat3.Util.EntityUtil;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;

public class AutoCity2
extends Module {
    private final Setting<Float> range;
    private final Setting<Boolean> toggle;
    public final Setting<Boolean> db;

    public static EntityPlayer target;

    public AutoCity2() {
        super("AutoCity2", "cityfag", Category.COMBAT, true, false, false);
        this.range = (Setting<Float>) this.register(new Setting("Range", 5.0f, 1.0f, 8.0f));
        this.toggle = (Setting<Boolean>) this.register(new Setting("Toggle", false));
        this.db = (Setting<Boolean>) this.register(new Setting("Double Mode", false));
    }

    private IBlockState getBlock(BlockPos blockPos) {
        return AutoCity2.mc.world.getBlockState(blockPos);
    }

    private EntityPlayer getTarget(double d) {
        EntityPlayer entityPlayer = null;
        double d2 = Math.pow(d, 2.0) + 1.0;
        for (EntityPlayer entityPlayer2 : AutoCity2.mc.world.playerEntities) {
            if (EntityUtil.isntValid(entityPlayer2, d)) continue;
            if (M3dC3t.speedManager.getPlayerSpeed(entityPlayer2) > 10.0) {
                continue;
            }
            if (entityPlayer == null) {
                entityPlayer = entityPlayer2;
                d2 = AutoCity2.mc.player.getDistanceSq(entityPlayer2);
                continue;
            }
            if (AutoCity2.mc.player.getDistanceSq(entityPlayer2) >= d2) {
                continue;
            }
            entityPlayer = entityPlayer2;
            d2 = AutoCity2.mc.player.getDistanceSq(entityPlayer2);
        }
        return entityPlayer;
    }

    private boolean detection(EntityPlayer entityPlayer) {
        boolean bl = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX + 1.2, entityPlayer.posY, entityPlayer.posZ)).getBlock() == Blocks.AIR;
        boolean bl2 = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX + 1.2, entityPlayer.posY + 1.0, entityPlayer.posZ)).getBlock() == Blocks.AIR;
        boolean bl3 = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX - 1.2, entityPlayer.posY, entityPlayer.posZ)).getBlock() == Blocks.AIR;
        boolean bl4 = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX - 1.2, entityPlayer.posY + 1.0, entityPlayer.posZ)).getBlock() == Blocks.AIR;
        boolean bl5 = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX, entityPlayer.posY, entityPlayer.posZ + 1.2)).getBlock() == Blocks.AIR;
        boolean bl6 = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX, entityPlayer.posY + 1.0, entityPlayer.posZ + 1.2)).getBlock() == Blocks.AIR;
        boolean bl7 = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX, entityPlayer.posY, entityPlayer.posZ - 1.2)).getBlock() == Blocks.AIR;
        boolean bl8 = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX, entityPlayer.posY + 1.0, entityPlayer.posZ - 1.2)).getBlock() == Blocks.AIR;
        boolean bl9 = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX + 2.2, entityPlayer.posY + 1.0, entityPlayer.posZ)).getBlock() == Blocks.AIR;
        boolean bl10 = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX + 2.2, entityPlayer.posY, entityPlayer.posZ)).getBlock() == Blocks.AIR;
        boolean bl11 = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX + 1.2, entityPlayer.posY, entityPlayer.posZ)).getBlock() == Blocks.AIR;
        boolean bl12 = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX - 2.2, entityPlayer.posY + 1.0, entityPlayer.posZ)).getBlock() == Blocks.AIR;
        boolean bl13 = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX - 2.2, entityPlayer.posY, entityPlayer.posZ)).getBlock() == Blocks.AIR;
        boolean bl14 = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX - 1.2, entityPlayer.posY, entityPlayer.posZ)).getBlock() == Blocks.AIR;
        boolean bl15 = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX, entityPlayer.posY + 1.0, entityPlayer.posZ + 2.2)).getBlock() == Blocks.AIR;
        boolean bl16 = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX, entityPlayer.posY, entityPlayer.posZ + 2.2)).getBlock() == Blocks.AIR;
        boolean bl17 = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX, entityPlayer.posY, entityPlayer.posZ + 1.2)).getBlock() == Blocks.AIR;
        boolean bl18 = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX, entityPlayer.posY + 1.0, entityPlayer.posZ - 2.2)).getBlock() == Blocks.AIR;
        boolean bl19 = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX, entityPlayer.posY, entityPlayer.posZ - 2.2)).getBlock() == Blocks.AIR;
        boolean bl20 = AutoCity2.mc.world.getBlockState(new BlockPos(entityPlayer.posX, entityPlayer.posY, entityPlayer.posZ - 1.2)).getBlock() == Blocks.AIR;
        return false;
    }

    @Override
    public void onUpdate() {
        target = this.getTarget(this.range.getValue());
        if (target == null) {
            return;
        }
        BlockPos blockPos = new BlockPos(AutoCity2.target.posX, AutoCity2.target.posY, AutoCity2.target.posZ);
        if (!this.detection(target)) {
            if (this.db.getValue()) {
                if (this.getBlock(blockPos.add(0, 1, 2)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, 2)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(0, 0, 1));
                } else if (this.getBlock(blockPos.add(0, 1, -2)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, -2)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(0, 0, -1));
                } else if (this.getBlock(blockPos.add(2, 1, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(2, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(1, 0, 0));
                } else if (this.getBlock(blockPos.add(-2, 1, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-2, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(-1, 0, 0));
                } else if (this.getBlock(blockPos.add(2, 1, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(2, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(2, 0, 0)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(2, 0, 0));
                } else if (this.getBlock(blockPos.add(-2, 1, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-2, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(-2, 0, 0)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(-2, 0, 0));
                } else if (this.getBlock(blockPos.add(0, 1, -2)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, -2)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, -2)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(0, 0, -2));
                } else if (this.getBlock(blockPos.add(0, 1, 2)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, 2)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, 2)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(0, 0, 2));
                } else if (this.getBlock(blockPos.add(2, 1, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(2, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(2, 0, 0)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(2, 0, 0));
                    if (CAT3INSTANT.breakPos2 == null) {
                        this.surroundMine(blockPos.add(1, 0, 0));
                    }
                } else if (this.getBlock(blockPos.add(-2, 1, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-2, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(-2, 0, 0)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(-2, 0, 0));
                    if (CAT3INSTANT.breakPos2 == null) {
                        this.surroundMine(blockPos.add(-1, 0, 0));
                    }
                } else if (this.getBlock(blockPos.add(0, 1, -2)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, -2)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, -2)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(0, 0, -2));
                    if (CAT3INSTANT.breakPos2 == null) {
                        this.surroundMine(blockPos.add(0, 0, -1));
                    }
                } else if (this.getBlock(blockPos.add(0, 1, 2)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, 2)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, 2)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(0, 0, 2));
                    if (CAT3INSTANT.breakPos2 == null) {
                        this.surroundMine(blockPos.add(0, 0, 1));
                    }
                } else if (this.getBlock(blockPos.add(0, 2, 1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 1, 1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 1, 1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 1, 1)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(0, 1, 1));
                } else if (this.getBlock(blockPos.add(0, 2, 1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 1, 1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(0, 0, 1));
                } else if (this.getBlock(blockPos.add(0, 2, -1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 1, -1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(0, 0, -1));
                } else if (this.getBlock(blockPos.add(1, 2, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(1, 1, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(1, 0, 0));
                } else if (this.getBlock(blockPos.add(-1, 2, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-1, 1, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(-1, 0, 0));
                } else if (this.getBlock(blockPos.add(1, 2, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(1, 1, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(1, 1, 0)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(1, 1, 0));
                } else if (this.getBlock(blockPos.add(-1, 2, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-1, 1, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-1, 1, 0)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(-1, 1, 0));
                } else if (this.getBlock(blockPos.add(0, 2, -1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 1, -1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 1, -1)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(0, 1, -1));
                } else if (this.getBlock(blockPos.add(1, 2, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(1, 1, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(1, 1, 0)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(1, 1, 0));
                    if (CAT3INSTANT.breakPos2 == null) {
                        this.surroundMine(blockPos.add(1, 0, 0));
                    }
                } else if (this.getBlock(blockPos.add(-1, 2, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-1, 1, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(-1, 1, 0)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(-1, 1, 0));
                    if (CAT3INSTANT.breakPos2 == null) {
                        this.surroundMine(blockPos.add(-1, 0, 0));
                    }
                } else if (this.getBlock(blockPos.add(0, 2, -1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 1, -1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 1, -1)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(0, 1, -1));
                    if (CAT3INSTANT.breakPos2 == null) {
                        this.surroundMine(blockPos.add(0, 0, -1));
                    }
                } else if (this.getBlock(blockPos.add(0, 2, 1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 1, 1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 1, 1)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(0, 1, 1));
                    if (CAT3INSTANT.breakPos2 == null) {
                        this.surroundMine(blockPos.add(0, 0, 1));
                    }
                } else if (this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(-2, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(-2, 1, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-2, 1, 0)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(-2, 1, 0));
                } else if (this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(2, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(2, 1, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(2, 1, 0)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(2, 1, 0));
                } else if (this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, 2)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 1, 2)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 1, 2)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(0, 1, 2));
                } else if (this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, -2)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 1, -2)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 1, -2)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(0, 1, -2));
                } else if (this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(-1, 1, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(-1, 2, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-1, 2, 0)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(-1, 2, 0));
                } else if (this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(1, 1, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(1, 2, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(1, 2, 0)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(1, 2, 0));
                } else if (this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 1, 1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 2, 1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 2, 1)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(0, 2, 1));
                } else if (this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 1, -1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 2, -1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 2, -1)).getBlock() != Blocks.BEDROCK) {
                    this.surroundMine(blockPos.add(0, 2, -1));
                }
            } else if (this.getBlock(blockPos.add(0, 1, 2)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, 2)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(0, 0, 1));
            } else if (this.getBlock(blockPos.add(0, 1, -2)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, -2)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(0, 0, -1));
            } else if (this.getBlock(blockPos.add(2, 1, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(2, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(1, 0, 0));
            } else if (this.getBlock(blockPos.add(-2, 1, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-2, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(-1, 0, 0));
            } else if (this.getBlock(blockPos.add(2, 1, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(2, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(2, 0, 0)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(2, 0, 0));
            } else if (this.getBlock(blockPos.add(-2, 1, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-2, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(-2, 0, 0)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(-2, 0, 0));
            } else if (this.getBlock(blockPos.add(0, 1, -2)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, -2)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, -2)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(0, 0, -2));
            } else if (this.getBlock(blockPos.add(0, 1, 2)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, 2)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, 2)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(0, 0, 2));
            } else if (this.getBlock(blockPos.add(2, 1, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(2, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(2, 0, 0)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(2, 0, 0));
            } else if (this.getBlock(blockPos.add(-2, 1, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-2, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(-2, 0, 0)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(-2, 0, 0));
            } else if (this.getBlock(blockPos.add(0, 1, -2)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, -2)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, -2)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(0, 0, -2));
            } else if (this.getBlock(blockPos.add(0, 1, 2)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, 2)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, 2)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(0, 0, 2));
            } else if (this.getBlock(blockPos.add(0, 2, 1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 1, 1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 1, 1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 1, 1)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(0, 1, 1));
            } else if (this.getBlock(blockPos.add(0, 2, 1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 1, 1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(0, 0, 1));
            } else if (this.getBlock(blockPos.add(0, 2, -1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 1, -1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(0, 0, -1));
            } else if (this.getBlock(blockPos.add(1, 2, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(1, 1, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(1, 0, 0));
            } else if (this.getBlock(blockPos.add(-1, 2, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-1, 1, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(-1, 0, 0));
            } else if (this.getBlock(blockPos.add(1, 2, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(1, 1, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(1, 1, 0)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(1, 1, 0));
            } else if (this.getBlock(blockPos.add(-1, 2, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-1, 1, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-1, 1, 0)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(-1, 1, 0));
            } else if (this.getBlock(blockPos.add(0, 2, -1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 1, -1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 1, -1)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(0, 1, -1));
            } else if (this.getBlock(blockPos.add(1, 2, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(1, 1, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(1, 1, 0)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(1, 1, 0));
            } else if (this.getBlock(blockPos.add(-1, 2, 0)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-1, 1, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(-1, 1, 0)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(-1, 1, 0));
            } else if (this.getBlock(blockPos.add(0, 2, -1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 1, -1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 1, -1)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(0, 1, -1));
            } else if (this.getBlock(blockPos.add(0, 2, 1)).getBlock() == Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 1, 1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 1, 1)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(0, 1, 1));
            } else if (this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(-2, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(-2, 1, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-2, 1, 0)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(-2, 1, 0));
            } else if (this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(2, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(2, 1, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(2, 1, 0)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(2, 1, 0));
            } else if (this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, 2)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 1, 2)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 1, 2)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(0, 1, 2));
            } else if (this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 0, -2)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 1, -2)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 1, -2)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(0, 1, -2));
            } else if (this.getBlock(blockPos.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(-1, 1, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(-1, 2, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(-1, 2, 0)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(-1, 2, 0));
            } else if (this.getBlock(blockPos.add(1, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(1, 1, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(1, 2, 0)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(1, 2, 0)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(1, 2, 0));
            } else if (this.getBlock(blockPos.add(0, 0, 1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 1, 1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 2, 1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 2, 1)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(0, 2, 1));
            } else if (this.getBlock(blockPos.add(0, 0, -1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 1, -1)).getBlock() != Blocks.BEDROCK && this.getBlock(blockPos.add(0, 2, -1)).getBlock() != Blocks.AIR && this.getBlock(blockPos.add(0, 2, -1)).getBlock() != Blocks.BEDROCK) {
                this.surroundMine(blockPos.add(0, 2, -1));
            }
        }
        if (this.toggle.getValue()) {
            this.disable();
        }
    }

    @Override
    public String getDisplayInfo() {
        if (target != null) {
            return target.getName();
        }
        return null;
    }

    private void surroundMine(BlockPos blockPos) {
        if (CAT3INSTANT.breakPos != null) {
            if (CAT3INSTANT.breakPos.equals(blockPos)) {
                return;
            }
            if (CAT3INSTANT.breakPos.equals(new BlockPos(AutoCity2.target.posX, AutoCity2.target.posY, AutoCity2.target.posZ)) && AutoCity2.mc.world.getBlockState(new BlockPos(AutoCity2.target.posX, AutoCity2.target.posY, AutoCity2.target.posZ)).getBlock() != Blocks.AIR) {
                return;
            }
            if (CAT3INSTANT.breakPos.equals(new BlockPos(AutoCity2.mc.player.posX, AutoCity2.mc.player.posY + 2.0, AutoCity2.mc.player.posZ))) {
                return;
            }
            if (CAT3INSTANT.breakPos.equals(new BlockPos(AutoCity2.mc.player.posX, AutoCity2.mc.player.posY - 1.0, AutoCity2.mc.player.posZ))) {
                return;
            }
            if (AutoCity2.mc.world.getBlockState(CAT3INSTANT.breakPos).getBlock() == Blocks.WEB) {
                return;
            }
        }
        AutoCity2.mc.playerController.onPlayerDamageBlock(blockPos, BlockUtil.getRayTraceFacing(blockPos));
    }


}

