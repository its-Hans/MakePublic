//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "G:\PortableSoft\JBY\MC_Deobf3000\1.12-MCP-Mappings"!

//Decompiled by Procyon!

package dev.madcat.m3dc3t.features.modules.useless;

import dev.madcat.m3dc3t.M3dC3t;
import dev.madcat.m3dc3t.event.events.BlockEvent;
import dev.madcat.m3dc3t.event.events.PacketEvent;
import dev.madcat.m3dc3t.event.events.Render3DEvent;
import dev.madcat.m3dc3t.features.modules.Module;
import dev.madcat.m3dc3t.features.setting.Setting;
import dev.madcat.m3dc3t.util.BlockUtil;
import dev.madcat.m3dc3t.util.InventoryUtil;
import dev.madcat.m3dc3t.util.MathUtil;
import dev.madcat.m3dc3t.util.RenderUtil;
import dev.madcat.m3dc3t.util.Timer;
import java.awt.Color;
import net.minecraft.block.BlockEndPortalFrame;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ArkMine extends Module
{
    private static ArkMine INSTANCE;
    public final Timer timer;
    private final Setting<Float> range;
    public Setting<Boolean> tweaks;
    public Setting<Mode> mode;
    public Setting<Boolean> reset;
    public Setting<Float> damage;
    public Setting<Boolean> noBreakAnim;
    public Setting<Boolean> noDelay;
    public Setting<Boolean> noSwing;
    public Setting<Boolean> allow;
    public Setting<Boolean> doubleBreak;
    public Setting<Boolean> webSwitch;
    public Setting<Boolean> silentSwitch;
    public Setting<Boolean> render;
    public Setting<Integer> red;
    public Setting<Integer> green;
    public Setting<Integer> blue;
    public Setting<Boolean> box;
    private final Setting<Integer> boxAlpha;
    public Setting<Boolean> outline;
    public final Setting<Float> lineWidth;
    public BlockPos currentPos;
    public IBlockState currentBlockState;
    public float breakTime;
    private boolean isMining;
    private BlockPos lastPos;
    private EnumFacing lastFacing;
    
    public ArkMine() {
        super("ArkMine", "Speeds up mining.", Category.USELESS, true, false, false);
        this.timer = new Timer();
        this.range = (Setting<Float>)this.register(new Setting("Range", (Object)10.0f, (Object)0.0f, (Object)50.0f));
        this.tweaks = (Setting<Boolean>)this.register(new Setting("Tweaks", (Object)true));
        this.mode = (Setting<Mode>)this.register(new Setting("Mode", (Object)Mode.PACKET, v -> (boolean)this.tweaks.getValue()));
        this.reset = (Setting<Boolean>)this.register(new Setting("Reset", (Object)true));
        this.damage = (Setting<Float>)this.register(new Setting("Damage", (Object)0.7f, (Object)0.0f, (Object)1.0f, v -> this.mode.getValue() == Mode.DAMAGE && (boolean)this.tweaks.getValue()));
        this.noBreakAnim = (Setting<Boolean>)this.register(new Setting("NoBreakAnim", (Object)false));
        this.noDelay = (Setting<Boolean>)this.register(new Setting("NoDelay", (Object)false));
        this.noSwing = (Setting<Boolean>)this.register(new Setting("NoSwing", (Object)false));
        this.allow = (Setting<Boolean>)this.register(new Setting("AllowMultiTask", (Object)false));
        this.doubleBreak = (Setting<Boolean>)this.register(new Setting("DoubleBreak", (Object)false));
        this.webSwitch = (Setting<Boolean>)this.register(new Setting("WebSwitch", (Object)false));
        this.silentSwitch = (Setting<Boolean>)this.register(new Setting("Ghost hand", (Object)false));
        this.render = (Setting<Boolean>)this.register(new Setting("Render", (Object)false));
        this.red = (Setting<Integer>)this.register(new Setting("Red", (Object)125, (Object)0, (Object)255, v -> (boolean)this.render.getValue()));
        this.green = (Setting<Integer>)this.register(new Setting("Green", (Object)0, (Object)0, (Object)255, v -> (boolean)this.render.getValue()));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", (Object)255, (Object)0, (Object)255, v -> (boolean)this.render.getValue()));
        this.box = (Setting<Boolean>)this.register(new Setting("Box", (Object)Boolean.FALSE, v -> (boolean)this.render.getValue()));
        this.boxAlpha = (Setting<Integer>)this.register(new Setting("BoxAlpha", (Object)85, (Object)0, (Object)255, v -> (boolean)this.box.getValue() && (boolean)this.render.getValue()));
        this.outline = (Setting<Boolean>)this.register(new Setting("Outline", (Object)Boolean.TRUE, v -> (boolean)this.render.getValue()));
        this.lineWidth = (Setting<Float>)this.register(new Setting("LineWidth", (Object)1.0f, (Object)0.1f, (Object)5.0f, v -> (boolean)this.outline.getValue() && (boolean)this.render.getValue()));
        this.breakTime = -1.0f;
        this.setInstance();
    }
    
    public static ArkMine getInstance() {
        if (ArkMine.INSTANCE == null) {
            ArkMine.INSTANCE = new ArkMine();
        }
        return ArkMine.INSTANCE;
    }
    
    private void setInstance() {
        ArkMine.INSTANCE = this;
    }
    
    public void onTick() {
        if (this.currentPos != null) {
            if (ArkMine.mc.player != null && ArkMine.mc.player.getDistanceSq(this.currentPos) > MathUtil.square((double)(float)this.range.getValue())) {
                this.currentPos = null;
                this.currentBlockState = null;
                return;
            }
            if (ArkMine.mc.player != null && (boolean)this.silentSwitch.getValue() && this.timer.passedMs((long)(int)(2000.0f * M3dC3t.serverManager.getTpsFactor())) && this.getPickSlot() != -1) {
                ArkMine.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(this.getPickSlot()));
            }
            if (ArkMine.mc.player != null && (boolean)this.silentSwitch.getValue() && this.timer.passedMs((long)(int)(2200.0f * M3dC3t.serverManager.getTpsFactor()))) {
                final int oldSlot = ArkMine.mc.player.inventory.currentItem;
                ArkMine.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(oldSlot));
            }
            if (fullNullCheck()) {
                return;
            }
            if (!ArkMine.mc.world.getBlockState(this.currentPos).equals(this.currentBlockState) || ArkMine.mc.world.getBlockState(this.currentPos).getBlock() == Blocks.AIR) {
                this.currentPos = null;
                this.currentBlockState = null;
            }
            else if ((boolean)this.webSwitch.getValue() && this.currentBlockState.getBlock() == Blocks.WEB && ArkMine.mc.player.getHeldItemMainhand().getItem() instanceof ItemPickaxe) {
                InventoryUtil.switchToHotbarSlot((Class)ItemSword.class, false);
            }
        }
    }
    
    public void onUpdate() {
        if (fullNullCheck()) {
            return;
        }
        if (this.noDelay.getValue()) {
            ArkMine.mc.playerController.blockHitDelay = 0;
        }
        if (this.isMining && this.lastPos != null && this.lastFacing != null && (boolean)this.noBreakAnim.getValue()) {
            ArkMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, this.lastPos, this.lastFacing));
        }
        if ((boolean)this.reset.getValue() && ArkMine.mc.gameSettings.keyBindUseItem.isKeyDown() && !(boolean)this.allow.getValue()) {
            ArkMine.mc.playerController.isHittingBlock = false;
        }
    }
    
    public void onRender3D(final Render3DEvent render3DEvent) {
        if ((boolean)this.render.getValue() && this.currentPos != null) {
            final Color color = new Color((int)this.red.getValue(), (int)this.green.getValue(), (int)this.blue.getValue(), (int)this.boxAlpha.getValue());
            RenderUtil.boxESP(this.currentPos, color, (float)this.lineWidth.getValue(), (boolean)this.outline.getValue(), (boolean)this.box.getValue(), (int)this.boxAlpha.getValue(), true);
        }
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send event) {
        if (fullNullCheck()) {
            return;
        }
        if (event.getStage() == 0) {
            if ((boolean)this.noSwing.getValue() && event.getPacket() instanceof CPacketAnimation) {
                event.setCanceled(true);
            }
            final CPacketPlayerDigging packet;
            if ((boolean)this.noBreakAnim.getValue() && event.getPacket() instanceof CPacketPlayerDigging && (packet = (CPacketPlayerDigging)event.getPacket()) != null) {
                packet.getPosition();
                try {
                    for (final Entity entity : ArkMine.mc.world.getEntitiesWithinAABBExcludingEntity((Entity)null, new AxisAlignedBB(packet.getPosition()))) {
                        if (!(entity instanceof EntityEnderCrystal)) {
                            continue;
                        }
                        this.showAnimation();
                        return;
                    }
                }
                catch (Exception ex) {}
                if (packet.getAction().equals((Object)CPacketPlayerDigging.Action.START_DESTROY_BLOCK)) {
                    this.showAnimation(true, packet.getPosition(), packet.getFacing());
                }
                if (packet.getAction().equals((Object)CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK)) {
                    this.showAnimation();
                }
            }
        }
    }
    
    @SubscribeEvent
    public void onBlockEvent(final BlockEvent event) {
        if (fullNullCheck()) {
            return;
        }
        if (event.getStage() == 3 && ArkMine.mc.world.getBlockState(event.pos).getBlock() instanceof BlockEndPortalFrame) {
            ArkMine.mc.world.getBlockState(event.pos).getBlock().setHardness(50.0f);
        }
        if (event.getStage() == 3 && (boolean)this.reset.getValue() && ArkMine.mc.playerController.curBlockDamageMP > 0.1f) {
            ArkMine.mc.playerController.isHittingBlock = true;
        }
        if (event.getStage() == 4 && (boolean)this.tweaks.getValue()) {
            if (BlockUtil.canBreak(event.pos)) {
                if (this.reset.getValue()) {
                    ArkMine.mc.playerController.isHittingBlock = false;
                }
                switch ((Mode)this.mode.getValue()) {
                    case PACKET: {
                        if (this.currentPos == null) {
                            this.currentPos = event.pos;
                            this.currentBlockState = ArkMine.mc.world.getBlockState(this.currentPos);
                            final ItemStack object = new ItemStack(Items.DIAMOND_PICKAXE);
                            this.breakTime = object.getDestroySpeed(this.currentBlockState) / 3.71f;
                            this.timer.reset();
                        }
                        ArkMine.mc.player.swingArm(EnumHand.MAIN_HAND);
                        ArkMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, event.pos, event.facing));
                        ArkMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, event.pos, event.facing));
                        event.setCanceled(true);
                        break;
                    }
                    case DAMAGE: {
                        if (ArkMine.mc.playerController.curBlockDamageMP < (float)this.damage.getValue()) {
                            break;
                        }
                        ArkMine.mc.playerController.curBlockDamageMP = 1.0f;
                        break;
                    }
                    case INSTANT: {
                        ArkMine.mc.player.swingArm(EnumHand.MAIN_HAND);
                        ArkMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, event.pos, event.facing));
                        ArkMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, event.pos, event.facing));
                        ArkMine.mc.playerController.onPlayerDestroyBlock(event.pos);
                        ArkMine.mc.world.setBlockToAir(event.pos);
                        break;
                    }
                }
            }
            final BlockPos above;
            if ((boolean)this.doubleBreak.getValue() && BlockUtil.canBreak(above = event.pos.add(0, 1, 0)) && ArkMine.mc.player.getDistance((double)above.getX(), (double)above.getY(), (double)above.getZ()) <= 5.0) {
                ArkMine.mc.player.swingArm(EnumHand.MAIN_HAND);
                ArkMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, above, event.facing));
                ArkMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, above, event.facing));
                ArkMine.mc.playerController.onPlayerDestroyBlock(above);
                ArkMine.mc.world.setBlockToAir(above);
            }
        }
    }
    
    private int getPickSlot() {
        for (int i = 0; i < 9; ++i) {
            if (ArkMine.mc.player.inventory.getStackInSlot(i).getItem() == Items.DIAMOND_PICKAXE) {
                return i;
            }
        }
        return -1;
    }
    
    private void showAnimation(final boolean isMining, final BlockPos lastPos, final EnumFacing lastFacing) {
        this.isMining = isMining;
        this.lastPos = lastPos;
        this.lastFacing = lastFacing;
    }
    
    public void showAnimation() {
        this.showAnimation(false, null, null);
    }
    
    public String getDisplayInfo() {
        return this.mode.currentEnumName();
    }
    
    static {
        ArkMine.INSTANCE = new ArkMine();
    }
    
    public enum Mode
    {
        PACKET, 
        DAMAGE, 
        INSTANT;
    }
}
