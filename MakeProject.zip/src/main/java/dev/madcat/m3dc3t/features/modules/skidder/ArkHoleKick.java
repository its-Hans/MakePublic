package dev.madcat.m3dc3t.features.modules.skidder;

import dev.madcat.m3dc3t.M3dC3t;
import dev.madcat.m3dc3t.event.events.Render3DEvent;
import dev.madcat.m3dc3t.features.command.Command;
import dev.madcat.m3dc3t.features.modules.Module;
import dev.madcat.m3dc3t.features.modules.useless.InstantMine;
import dev.madcat.m3dc3t.features.setting.Setting;
import dev.madcat.m3dc3t.util.skidding.BlockUtilsss;
import dev.madcat.m3dc3t.util.BlockUtil;
import dev.madcat.m3dc3t.util.CombatUtil;
import dev.madcat.m3dc3t.util.EntityUtil;
import dev.madcat.m3dc3t.util.InventoryUtil;
import dev.madcat.m3dc3t.util.RenderUtil;
import dev.madcat.m3dc3t.util.RotationUtil;
import dev.madcat.m3dc3t.util.Timer;
import java.awt.Color;
import java.util.*;

import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class ArkHoleKick extends Module
{
    private final Setting<Double> var1;
    private final Setting<Boolean> var2;
    private final Setting<Float> range;
    private final Setting<Integer> delay;
    private final Setting<Boolean> attackCry;
    private final Setting<Integer> noSuicide;
    private final Setting<Integer> attackRange;
    private final Setting<Boolean> surCheck;
    private final Setting<Boolean> onGroundCheck;
    private final Setting<Integer> count;
    private final Setting<Integer> renderTime;
    private final Setting<Boolean> render;
    private final Setting<Double> renderSpeed;
    private final Setting<Boolean> renderText;
    private final Setting<Boolean> noPushSelf;
    private final Setting<Double> mineDelay;
    private final Setting<Boolean> ignoreBBox;
    Timer var3;
    Timer var4;
    BlockPos ppos;
    BlockPos pos;
    int stage;
    int ct;
    int ct1;
    EntityPlayer target;
    private BlockPos renderPos;
    Timer dynamicRenderingTimer;
    double renderCount;
    Timer renderTimer;
    boolean canRender;
    int rotate;
    
    public ArkHoleKick() {
        super("ArkHoleKick", "AutoKick", Category.SKIDDER, true, false, false);
        this.ignoreBBox = (Setting<Boolean>)this.register(new Setting("ignoreBBox", (Object)true));
        this.var1 = (Setting<Double>)this.register(new Setting("MaxTargetSpeed", (Object)7.0, (Object)0.0, (Object)15.0));
        this.var2 = (Setting<Boolean>)this.register(new Setting("DisableOnNoBlock", (Object)true));
        this.range = (Setting<Float>)this.register(new Setting("Range", (Object)5.0f, (Object)1.0f, (Object)6.0f));
        this.delay = (Setting<Integer>)this.register(new Setting("Delay", (Object)0, (Object)0, (Object)1000));
        this.attackCry = (Setting<Boolean>)this.register(new Setting("AttackCrystal", (Object)true));
        this.noSuicide = (Setting<Integer>)this.register(new Setting("NoSuicideHealth", (Object)5, (Object)0, (Object)20, v -> (boolean)this.attackCry.getValue()));
        this.attackRange = (Setting<Integer>)this.register(new Setting("AttackCryRange", (Object)5, (Object)0, (Object)7, v -> (boolean)this.attackCry.getValue()));
        this.surCheck = (Setting<Boolean>)this.register(new Setting("OnlyPushSurrounded", (Object)true));
        this.onGroundCheck = (Setting<Boolean>)this.register(new Setting("OnGroundCheck", (Object)true));
        this.count = (Setting<Integer>)this.register(new Setting("AntiStickCount", (Object)20, (Object)0, (Object)200));
        this.renderTime = (Setting<Integer>)this.register(new Setting("RenderTime", (Object)200, (Object)0, (Object)1000));
        this.render = (Setting<Boolean>)this.register(new Setting("render", (Object)true));
        this.renderSpeed = (Setting<Double>)this.register(new Setting("RenderSpeed", (Object)5.0, (Object)0.0, (Object)10.0));
        this.renderText = (Setting<Boolean>)this.register(new Setting("RenderText", (Object)true));
        this.noPushSelf = (Setting<Boolean>)this.register(new Setting("NoPushSelf", (Object)true));
        this.mineDelay = (Setting<Double>)this.register(new Setting("mineDelay", (Object)0.0, (Object)0.0, (Object)400.0));
        this.var3 = new Timer();
        this.var4 = new Timer();
        this.stage = 0;
        this.ct = 0;
        this.ct1 = 0;
        this.dynamicRenderingTimer = new Timer();
        this.renderTimer = new Timer();
        this.canRender = false;
    }
    
    public void onRender3D(final Render3DEvent event) {
        if (this.ppos != null) {
            this.renderPos = this.ppos;
        }
        if (this.canRender) {
            if (this.renderCount / 100.0 < 0.5 && this.dynamicRenderingTimer.passedDms(0.5)) {
                this.renderCount += (double)this.renderSpeed.getValue();
                this.dynamicRenderingTimer.reset();
            }
            final AxisAlignedBB axisAlignedBB = new AxisAlignedBB(this.renderPos.getX() + 0.5 - this.renderCount / 100.0, this.renderPos.getY() + 0.5 - this.renderCount / 100.0, this.renderPos.getZ() + 0.5 - this.renderCount / 100.0, this.renderPos.getX() + 0.5 + this.renderCount / 100.0, this.renderPos.getY() + 0.5 + this.renderCount / 100.0, this.renderPos.getZ() + 0.5 + this.renderCount / 100.0);
            if (this.render.getValue()) {
                RenderUtil.drawBBFill(axisAlignedBB, new Color(232, 226, 2), 100);
            }
            if (this.renderText.getValue()) {
                RenderUtil.drawText(this.renderPos, "PUSH!");
            }
        }
        else {
            this.renderCount = 0.0;
        }
    }
    
    public void onTick() {
        if (this.renderTimer.passedDms((double)(int)this.renderTime.getValue())) {
            this.canRender = false;
        }
        final int oldSlot = ArkHoleKick.mc.player.inventory.currentItem;
        final int obbySlot = InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.OBSIDIAN));
        int pisSlot = InventoryUtil.getItemHotbar(Item.getItemFromBlock((Block)Blocks.PISTON));
        if (pisSlot == -1) {
            pisSlot = InventoryUtil.getItemHotbar(Item.getItemFromBlock((Block)Blocks.STICKY_PISTON));
            if (pisSlot == -1) {
                if (this.var2.getValue()) {
                    Command.sendMessage("NoPiston");
                    this.disable();
                }
                return;
            }
        }
        final int rstSlot = InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.REDSTONE_BLOCK));
        if (rstSlot == -1) {
            if (this.var2.getValue()) {
                Command.sendMessage("NoRedStoneBlock");
                this.disable();
            }
            return;
        }
        if (this.stage == 0) {
            if (!this.var4.passedDms((double)(int)this.delay.getValue())) {
                return;
            }
            final EntityPlayer target = this.getTarget((float)this.range.getValue());
            this.target = target;
            this.ppos = this.getPistonPos(target);
            if (this.ppos == null) {
                return;
            }
            this.pos = this.getRSTPos(this.ppos);
            if (this.pos == null) {
                return;
            }
            this.ct = 0;
            this.ct1 = 0;
            ++this.stage;
        }
        if (this.stage == 1) {
            ++this.stage;
        }
        else if (this.stage == 2) {
            if (!this.var4.passedDms((double)(int)this.delay.getValue())) {
                return;
            }
            this.var4.reset();
            this.canRender = true;
            this.renderTimer.reset();
            if (this.attackCry.getValue()) {
                this.attackCrystal();
            }
            InventoryUtil.switchToHotbarSlot(pisSlot, false);
            RotationUtil.faceYawAndPitch((float)this.rotate, 0.0f);
            BlockUtil.placeBlock(this.ppos, EnumHand.MAIN_HAND, false, true, true);
            InventoryUtil.switchToHotbarSlot(oldSlot, false);
            if (ArkHoleKick.mc.world.getBlockState(this.ppos).getBlock().equals(Blocks.PISTON)) {
                ++this.stage;
            }
            else {
                ++this.ct1;
                if (this.ct1 > (int)this.count.getValue()) {
                    this.stage = 0;
                }
            }
        }
        if (this.stage == 3) {
            if (BlockUtilsss.haveNeighborBlock(this.ppos, Blocks.REDSTONE_BLOCK).size() > 0) {
                this.var3.reset();
                this.stage = 4;
                return;
            }
            if (ArkHoleKick.mc.world.getBlockState(this.ppos).getBlock().equals(Blocks.PISTON) || !ArkHoleKick.mc.world.getBlockState(this.ppos).getBlock().equals(Blocks.STICKY_PISTON)) {}
            InventoryUtil.switchToHotbarSlot(rstSlot, false);
            BlockUtil.placeBlock(this.pos, EnumHand.MAIN_HAND, false, true, true);
            InventoryUtil.switchToHotbarSlot(oldSlot, false);
            if (ArkHoleKick.mc.world.getBlockState(this.pos).getBlock().equals(Blocks.REDSTONE_BLOCK)) {
                this.var3.reset();
                this.stage = 4;
            }
            ++this.ct;
            if (this.ct > (int)this.count.getValue()) {
                this.stage = 0;
            }
        }
        else if (this.stage == 4) {
            if (!this.var3.passedDms((double)this.mineDelay.getValue())) {
                return;
            }
            if (!ArkHoleKick.mc.world.getBlockState(CombatUtil.getFlooredPosition((Entity)this.target)).getBlock().equals(Blocks.AIR) && ArkHoleKick.mc.world.getBlockState(CombatUtil.getFlooredPosition((Entity)this.target).add(0, 2, 0)).getBlock().equals(Blocks.AIR) && !ArkHoleKick.mc.world.getBlockState(this.ppos.add(0, -1, 0)).getBlock().equals(Blocks.AIR)) {
                if (ArkHoleKick.mc.world.getBlockState(this.ppos.add(0, 1, 0)).getBlock().equals(Blocks.AIR)) {
                    if (BlockUtilsss.haveNeighborBlock(this.ppos, Blocks.REDSTONE_BLOCK).size() == 1) {
                        final BlockPos minePos = BlockUtilsss.haveNeighborBlock(this.ppos, Blocks.REDSTONE_BLOCK).get(0);
                        if (minePos != null && (InstantMine.breakPos == null || !InstantMine.breakPos.equals((Object)minePos))) {
                            ArkHoleKick.mc.playerController.onPlayerDamageBlock(minePos, BlockUtil.getRayTraceFacing(minePos));
                        }
                    }
                }
                else if (ArkHoleKick.mc.world.getBlockState(this.ppos.add(0, 1, 0)).getBlock().equals(Blocks.REDSTONE_BLOCK) && BlockUtilsss.haveNeighborBlock(this.ppos, Blocks.REDSTONE_BLOCK).size() == 1 && !InstantMine.breakPos.equals((Object)this.ppos.add(0, 1, 0))) {
                    ArkHoleKick.mc.playerController.onPlayerDamageBlock(this.ppos.add(0, 1, 0), BlockUtil.getRayTraceFacing(this.ppos.add(0, 1, 0)));
                }
            }
            this.stage = 0;
            this.disable();
        }
    }
    
    public boolean isSur(final Entity player) {
        final BlockPos playerPos = CombatUtil.getFlooredPosition(player);
        return (!ArkHoleKick.mc.world.getBlockState(playerPos.add(1, 0, 0)).getBlock().equals(Blocks.AIR) && !ArkHoleKick.mc.world.getBlockState(playerPos.add(-1, 0, 0)).getBlock().equals(Blocks.AIR) && !ArkHoleKick.mc.world.getBlockState(playerPos.add(0, 0, 1)).getBlock().equals(Blocks.AIR) && !ArkHoleKick.mc.world.getBlockState(playerPos.add(0, 0, -1)).getBlock().equals(Blocks.AIR)) || EntityUtil.isBothHole(playerPos);
    }
    
    private EntityPlayer getTarget(final double range) {
        EntityPlayer target = null;
        double distance = range;
        for (final EntityPlayer player : ArkHoleKick.mc.world.playerEntities) {
            final BlockPos pistonPos = this.getPistonPos(player);
            final BlockPos rstPos = this.getRSTPos(this.getPistonPos(player));
            if (!EntityUtil.isntValid((Entity)player, range) && !M3dC3t.friendManager.isFriend(player.getName()) && ArkHoleKick.mc.player.posY - player.posY >= -1.0 && ArkHoleKick.mc.player.posY - player.posY <= 1.0 && M3dC3t.speedManager.getPlayerSpeed(player) <= (double)this.var1.getValue() && pistonPos != null) {
                if (rstPos == null) {
                    continue;
                }
                if (this.surCheck.getValue()) {
                    final Boolean p = true;
                    if (!this.isSur((Entity)player) && p) {
                        continue;
                    }
                }
                if ((boolean)this.noPushSelf.getValue() && CombatUtil.getFlooredPosition((Entity)player).equals((Object)CombatUtil.getFlooredPosition((Entity)ArkHoleKick.mc.player))) {
                    continue;
                }
                if (ArkHoleKick.mc.player.posY - player.posY == -1.0 && ArkHoleKick.mc.player.getDistance(pistonPos.getX() + 0.5, pistonPos.getY() + 0.5, pistonPos.getZ() + 0.5) < 3.7) {
                    continue;
                }
                if ((boolean)this.onGroundCheck.getValue() && !ArkHoleKick.mc.player.onGround) {
                    continue;
                }
                if (target == null) {
                    target = player;
                    distance = EntityUtil.mc.player.getDistanceSq((Entity)player);
                }
                else {
                    if (EntityUtil.mc.player.getDistanceSq((Entity)player) >= distance) {
                        continue;
                    }
                    target = player;
                    distance = EntityUtil.mc.player.getDistanceSq((Entity)player);
                }
            }
        }
        return target;
    }
    
    public void attackCrystal() {
        if (ArkHoleKick.mc.player.getHealth() < (int)this.noSuicide.getValue()) {
            return;
        }
        final ArrayList<Entity> crystalList = new ArrayList<Entity>();
        for (final Entity entity : ArkHoleKick.mc.world.loadedEntityList) {
            if (entity instanceof EntityEnderCrystal) {
                crystalList.add(entity);
            }
        }
        if (crystalList.size() == 0) {
            return;
        }
        final HashMap<Entity, Double> distantMap = new HashMap<Entity, Double>();
        for (final Entity crystal : crystalList) {
            if (ArkHoleKick.mc.player.getDistance(crystal.posX, crystal.posY, crystal.posZ) < (int)this.attackRange.getValue()) {
                distantMap.put(crystal, ArkHoleKick.mc.player.getDistance(crystal.posX, crystal.posY, crystal.posZ));
            }
        }
        final List<Map.Entry<Entity, Double>> list = new ArrayList<Map.Entry<Entity, Double>>(distantMap.entrySet());
        if (list.size() == 0) {
            return;
        }
        if (list.get(0).getValue() < 5.0) {
            EntityUtil.attackEntity((Entity)list.get(list.size() - 1).getKey(), true, true);
        }
    }
    
    public BlockPos getRSTPos(final BlockPos pistonPos) {
        if (pistonPos == null) {
            return null;
        }
        if (BlockUtilsss.haveNeighborBlock(pistonPos, Blocks.REDSTONE_BLOCK).size() > 0 && this.isAABBBlocked(pistonPos)) {
            return BlockUtilsss.haveNeighborBlock(pistonPos, Blocks.REDSTONE_BLOCK).get(0);
        }
        final ArrayList<BlockPos> placePosList = new ArrayList<BlockPos>();
        placePosList.add(pistonPos.add(0, 1, 0));
        placePosList.add(pistonPos.add(0, -1, 0));
        if (this.rotate != -90) {
            placePosList.add(pistonPos.add(-1, 0, 0));
        }
        if (this.rotate != 90) {
            placePosList.add(pistonPos.add(1, 0, 0));
        }
        if (this.rotate != 0) {
            placePosList.add(pistonPos.add(0, 0, -1));
        }
        if (this.rotate != 180) {
            placePosList.add(pistonPos.add(0, 0, 1));
        }
        final HashMap<BlockPos, Double> distantMap = new HashMap<BlockPos, Double>();
        for (final BlockPos rSTPos : placePosList) {
            if (ArkHoleKick.mc.world.getBlockState(rSTPos).getBlock().equals(Blocks.AIR) && this.isAABBBlocked(rSTPos)) {
                distantMap.put(rSTPos, ArkHoleKick.mc.player.getDistanceSq(rSTPos));
            }
        }
        final List<Map.Entry<BlockPos, Double>> list = new ArrayList<Map.Entry<BlockPos, Double>>(distantMap.entrySet());
        if (list.size() == 0) {
            return null;
        }
        return list.get(0).getKey();
    }
    
    public BlockPos getPistonPos(final EntityPlayer player) {
        if (player == null) {
            return null;
        }
        final BlockPos pPos = CombatUtil.getFlooredPosition((Entity)player);
        if (!ArkHoleKick.mc.world.getBlockState(pPos.add(0, 1, 0)).getBlock().equals(Blocks.AIR) || !ArkHoleKick.mc.world.getBlockState(pPos.add(0, 2, 0)).getBlock().equals(Blocks.AIR)) {
            return null;
        }
        final HashMap<BlockPos, Double> distantMap = new HashMap<BlockPos, Double>();
        if (ArkHoleKick.mc.world.getBlockState(pPos.add(1, 1, 0)).getBlock().equals(Blocks.AIR) && this.isAABBBlocked(pPos.add(1, 1, 0)) && ArkHoleKick.mc.world.getBlockState(pPos.add(-1, 1, 0)).getBlock().equals(Blocks.AIR) && ArkHoleKick.mc.world.getBlockState(pPos.add(-1, 2, 0)).getBlock().equals(Blocks.AIR)) {
            distantMap.put(pPos.add(1, 1, 0), ArkHoleKick.mc.player.getDistance((double)pPos.add(1, 1, 0).getX(), (double)pPos.add(1, 1, 0).getY(), (double)pPos.add(1, 1, 0).getZ()));
        }
        else if (ArkHoleKick.mc.world.getBlockState(pPos.add(1, 1, 0)).getBlock().equals(Blocks.AIR) && this.isAABBBlocked(pPos.add(1, 1, 0)) && !ArkHoleKick.mc.world.getBlockState(pPos.add(1, 0, 0)).getBlock().equals(Blocks.AIR) && !ArkHoleKick.mc.world.getBlockState(pPos.add(1, 0, 0)).getBlock().equals(Blocks.REDSTONE_BLOCK) && !ArkHoleKick.mc.world.getBlockState(pPos).getBlock().equals(Blocks.AIR) && ArkHoleKick.mc.world.getBlockState(pPos.add(1, 2, 0)).getBlock().equals(Blocks.AIR)) {
            distantMap.put(pPos.add(1, 1, 0), ArkHoleKick.mc.player.getDistance((double)pPos.add(1, 1, 0).getX(), (double)pPos.add(1, 1, 0).getY(), (double)pPos.add(1, 1, 0).getZ()));
        }
        if (ArkHoleKick.mc.world.getBlockState(pPos.add(-1, 1, 0)).getBlock().equals(Blocks.AIR) && this.isAABBBlocked(pPos.add(-1, 1, 0)) && ArkHoleKick.mc.world.getBlockState(pPos.add(1, 1, 0)).getBlock().equals(Blocks.AIR) && ArkHoleKick.mc.world.getBlockState(pPos.add(1, 2, 0)).getBlock().equals(Blocks.AIR)) {
            distantMap.put(pPos.add(-1, 1, 0), ArkHoleKick.mc.player.getDistance((double)pPos.add(-1, 1, 0).getX(), (double)pPos.add(-1, 1, 0).getY(), (double)pPos.add(-1, 1, 0).getZ()));
        }
        else if (ArkHoleKick.mc.world.getBlockState(pPos.add(-1, 1, 0)).getBlock().equals(Blocks.AIR) && this.isAABBBlocked(pPos.add(-1, 1, 0)) && !ArkHoleKick.mc.world.getBlockState(pPos.add(-1, 0, 0)).getBlock().equals(Blocks.AIR) && !ArkHoleKick.mc.world.getBlockState(pPos.add(-1, 0, 0)).getBlock().equals(Blocks.REDSTONE_BLOCK) && !ArkHoleKick.mc.world.getBlockState(pPos).getBlock().equals(Blocks.AIR) && ArkHoleKick.mc.world.getBlockState(pPos.add(-1, 2, 0)).getBlock().equals(Blocks.AIR)) {
            distantMap.put(pPos.add(-1, 1, 0), ArkHoleKick.mc.player.getDistance((double)pPos.add(-1, 1, 0).getX(), (double)pPos.add(-1, 1, 0).getY(), (double)pPos.add(-1, 1, 0).getZ()));
        }
        if (ArkHoleKick.mc.world.getBlockState(pPos.add(0, 1, 1)).getBlock().equals(Blocks.AIR) && this.isAABBBlocked(pPos.add(0, 1, 1)) && ArkHoleKick.mc.world.getBlockState(pPos.add(0, 1, -1)).getBlock().equals(Blocks.AIR) && ArkHoleKick.mc.world.getBlockState(pPos.add(0, 2, -1)).getBlock().equals(Blocks.AIR)) {
            distantMap.put(pPos.add(0, 1, 1), ArkHoleKick.mc.player.getDistance((double)pPos.add(0, 1, 1).getX(), (double)pPos.add(0, 1, 1).getY(), (double)pPos.add(0, 1, 1).getZ()));
        }
        else if (ArkHoleKick.mc.world.getBlockState(pPos.add(0, 1, 1)).getBlock().equals(Blocks.AIR) && this.isAABBBlocked(pPos.add(0, 1, 1)) && !ArkHoleKick.mc.world.getBlockState(pPos.add(0, 0, 1)).getBlock().equals(Blocks.AIR) && !ArkHoleKick.mc.world.getBlockState(pPos.add(0, 0, 1)).getBlock().equals(Blocks.REDSTONE_BLOCK) && !ArkHoleKick.mc.world.getBlockState(pPos).getBlock().equals(Blocks.AIR) && ArkHoleKick.mc.world.getBlockState(pPos.add(0, 2, 1)).getBlock().equals(Blocks.AIR)) {
            distantMap.put(pPos.add(0, 1, 1), ArkHoleKick.mc.player.getDistance((double)pPos.add(0, 1, 1).getX(), (double)pPos.add(0, 1, 1).getY(), (double)pPos.add(0, 1, 1).getZ()));
        }
        if (ArkHoleKick.mc.world.getBlockState(pPos.add(0, 1, -1)).getBlock().equals(Blocks.AIR) && this.isAABBBlocked(pPos.add(0, 1, -1)) && ArkHoleKick.mc.world.getBlockState(pPos.add(0, 1, 1)).getBlock().equals(Blocks.AIR) && ArkHoleKick.mc.world.getBlockState(pPos.add(0, 2, 1)).getBlock().equals(Blocks.AIR)) {
            distantMap.put(pPos.add(0, 1, -1), ArkHoleKick.mc.player.getDistance((double)pPos.add(0, 1, -1).getX(), (double)pPos.add(0, 1, -1).getY(), (double)pPos.add(0, 1, -1).getZ()));
        }
        else if (ArkHoleKick.mc.world.getBlockState(pPos.add(0, 1, -1)).getBlock().equals(Blocks.AIR) && this.isAABBBlocked(pPos.add(0, 1, -1)) && !ArkHoleKick.mc.world.getBlockState(pPos).getBlock().equals(Blocks.AIR) && ArkHoleKick.mc.world.getBlockState(pPos.add(0, 2, -1)).getBlock().equals(Blocks.AIR)) {
            distantMap.put(pPos.add(0, 1, -1), ArkHoleKick.mc.player.getDistance((double)pPos.add(0, 1, -1).getX(), (double)pPos.add(0, 1, -1).getY(), (double)pPos.add(0, 1, -1).getZ()));
        }
        final List<Map.Entry<BlockPos, Double>> list = new ArrayList<Map.Entry<BlockPos, Double>>(distantMap.entrySet());
        if (list.size() == 0) {
            return null;
        }
        if (list.get(0).getKey().equals((Object)pPos.add(1, 1, 0))) {
            this.rotate = -90;
        }
        if (list.get(0).getKey().equals((Object)pPos.add(-1, 1, 0))) {
            this.rotate = 90;
        }
        if (list.get(0).getKey().equals((Object)pPos.add(0, 1, 1))) {
            this.rotate = 0;
        }
        if (list.get(0).getKey().equals((Object)pPos.add(0, 1, -1))) {
            this.rotate = 180;
        }
        return list.get(0).getKey();
    }
    
    public boolean isAABBBlocked(final BlockPos pos) {
        if (this.ignoreBBox.getValue()) {
            return true;
        }
        final AxisAlignedBB axisAlignedBB = new AxisAlignedBB(pos);
        final boolean i = false;
        final List l = ArkHoleKick.mc.world.getEntitiesWithinAABBExcludingEntity((Entity)null, axisAlignedBB);
        return l.size() == 0;
    }
}
