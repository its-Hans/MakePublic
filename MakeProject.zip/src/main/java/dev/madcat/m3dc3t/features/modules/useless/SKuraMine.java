package dev.madcat.m3dc3t.features.modules.useless;

import dev.madcat.m3dc3t.features.modules.Module;
import dev.madcat.m3dc3t.features.setting.Setting;

import dev.madcat.m3dc3t.util.BlockUtil;
import dev.madcat.m3dc3t.util.InventoryUtil;

import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;

import skid.skura.Event.block.BlockEvent;
import skid.skura.Event.player.UpdateWalkingPlayerEvent;
import skid.skura.Man.RotationManager;

public class SKuraMine extends Module
{
    Setting<Boolean> packet;
    Setting<Boolean> spoofSwing;
    Setting<Integer> startSwingtime;
    Setting<Boolean> swap;
    Setting<Boolean> rotate;
    static BlockPos currentPos;
    IBlockState currentBlockState;
    EnumFacing facing;
    int oldSlot;
    int picSlot;
    
    public SKuraMine()
    {
        super("SKuraMine", "crash on you", Category.USELESS, true, false, false);
        this.packet = (Setting<Boolean>)this.register(new Setting("PacketOnly", false));
        this.spoofSwing = (Setting<Boolean>)this.register(new Setting("SpoofSwing", false));
        this.startSwingtime = (Setting<Integer>)this.register(new Setting("StartSwingTime", 1350, 0, 2000));
        this.swap = (Setting<Boolean>)this.register(new Setting("SwapMine", true));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", false));
    }
    
    private void equipBestTool(final IBlockState blockState)
    {
        int bestSlot = -1;
        double max = 0.0;
        for (int i = 0; i < 9; ++i)
        {
            final float f = 0.0f;
            final ItemStack stack = SKuraMine.mc.player.inventory.getStackInSlot(i);
            if (!stack.isEmpty())
            {
                float speed = stack.getDestroySpeed(blockState);
                if (f > 1.0f)
                {
                    final int eff;
                    if ((speed += (float)(((eff = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, stack)) > 0) ? (eff + 1.0) : 0.0)) > max)
                    {
                        max = speed;
                        bestSlot = i;
                    }
                }
            }
        }
        if (bestSlot != -1) {InventoryUtil.switchToHotbarSlot(bestSlot, false);}
    }
    
    @SubscribeEvent
    public void onDisconnect(final FMLNetworkEvent.ClientDisconnectionFromServerEvent event)
    {
        SKuraMine.currentPos = null;
        this.facing = null;
    }
    
    @SubscribeEvent
    public void onBlockEvent(final BlockEvent event) {
        if (fullNullCheck()) {
            return;
        }
        this.oldSlot = SKuraMine.mc.player.inventory.currentItem;
        this.picSlot = InventoryUtil.findHotbarItem(Items.DIAMOND_PICKAXE);
        try
        {
            if (SKuraMine.currentPos != null)
            {
                if (!BlockUtil.canBreak(SKuraMine.currentPos))
                {
                    SKuraMine.currentPos = null;
                    return;
                }
                if (SKuraMine.currentPos.getX() == event.getPos().getX() && SKuraMine.currentPos.getY() == event.getPos().getY() && SKuraMine.currentPos.getZ() == event.getPos().getZ()) {return;}
            }
            SKuraMine.currentPos = event.getPos();
            this.facing = event.getFacing();
            this.currentBlockState = SKuraMine.mc.world.getBlockState(SKuraMine.currentPos);
            if (SKuraMine.mc.getConnection() != null && BlockUtil.canBreak(SKuraMine.currentPos))
            {
                SKuraMine.mc.player.swingArm(EnumHand.MAIN_HAND);
                SKuraMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, SKuraMine.currentPos, this.facing));
                SKuraMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, SKuraMine.currentPos, this.facing));
            }
            event.setCanceled(true);
        }
        catch (Exception ex) {}
    }
    
    @SubscribeEvent
    public void onUpdate(final UpdateWalkingPlayerEvent event)
    {
        if (fullNullCheck()) {return;}
        this.oldSlot = SKuraMine.mc.player.inventory.currentItem;
        this.picSlot = InventoryUtil.findHotbarItem(Items.DIAMOND_PICKAXE);
        try {
            if (BlockUtil.canBreak(SKuraMine.currentPos))
            {
                if (this.swap.getValue() && !this.currentBlockState.getBlock().equals(Blocks.SNOW_LAYER)) {this.equipBestTool(this.currentBlockState);}
                else if (this.swap.getValue() && this.currentBlockState.getBlock().equals(Blocks.SNOW_LAYER)) {InventoryUtil.switchToHotbarSlot(this.picSlot, false);}

                if (!this.packet.getValue()) {SKuraMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, SKuraMine.currentPos, this.facing));}
                if (this.swap.getValue()) {InventoryUtil.switchToHotbarSlot(this.oldSlot, false);}
            }
        }
        catch (Exception ex) {}
    }
    
    public void onDisable()
    {
        if (fullNullCheck()) {return;}
        SKuraMine.currentPos = null;
        this.facing = null;
        RotationManager.resetRotation();
    }
    
    public void onEnable()
    {
        if (fullNullCheck()) {return;}
        SKuraMine.currentPos = null;
        this.facing = null;
    }
    
    public String getHudInfo() {return this.packet.getValue() ? "Packet" : "Instant";}
    
    static
    {
        SKuraMine.currentPos = null;
    }
}
