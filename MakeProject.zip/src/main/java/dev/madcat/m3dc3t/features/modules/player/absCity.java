package dev.madcat.m3dc3t.features.modules.player;

import dev.madcat.m3dc3t.M3dC3t;
import dev.madcat.m3dc3t.features.modules.Module;
import dev.madcat.m3dc3t.features.setting.Setting;

import dev.madcat.m3dc3t.features.modules.useless.InstantMine;

import dev.madcat.m3dc3t.manager.skid.ABBreakManager;

import dev.madcat.m3dc3t.util.BlockUtil;
import dev.madcat.m3dc3t.util.EntityUtil;
import dev.madcat.m3dc3t.util.InventoryUtil;
import dev.madcat.m3dc3t.util.MathUtil;
import dev.madcat.m3dc3t.util.skidding.MutableBlockPosHelper;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class absCity
extends Module
{
    public static EntityPlayer target;
    public static BlockPos feet;
    private final Setting<Float> range = this.register(new Setting<Float>("Range", Float.valueOf(6.0f), Float.valueOf(1.0f), Float.valueOf(6.0f)));
    private final Setting<Boolean> under = this.register(new Setting<Boolean>("MineUnder", false));
    private final Setting<Boolean> cycle = this.register(new Setting<Boolean>("CycleMine", false));
    private final Setting<Boolean> mineweb = this.register(new Setting<Boolean>("Mine Web", true));
    private final Setting<Boolean> toggle = this.register(new Setting<Boolean>("AutoToggle", false));
    private final MutableBlockPosHelper mutablePos = new MutableBlockPosHelper();

    public absCity() {
        super("absCity", "absCity", Category.PLAYER, true, false, false);
    }

    private static boolean safeCheck(BlockPos pos)
    {
        for (Entity entity : absCity.mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(pos)))
        {
            if (!(entity instanceof EntityPlayer) || entity != absCity.mc.player) continue;
            return false;
        }
        return true;
    }

    @Override
    public void onUpdate()
    {
        if (absCity.fullNullCheck()) {return;}
        if (InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE) == -1) {return;}
        target = this.getTarget(this.range.getValue().floatValue());
        if (target != null && (M3dC3t.moduleManager.isModuleEnabled("AutoCev") || M3dC3t.moduleManager.isModuleEnabled("PistonCrystal")) && this.isAir(new BlockPos(absCity.target.posX, absCity.target.posY, absCity.target.posZ))) {return;}
        this.surroundMine();
        if (this.toggle.getValue().booleanValue()) {this.disable();}
    }

    @Override
    public String getDisplayInfo()
    {
        if (target != null) {return target.getName();}
        return null;
    }

    private void surroundMine()
    {
        if (target == null) {return;}
        feet = EntityUtil.getPlayerPos(target);
        if (this.detection(target) && this.detection2(target) && (this.isAir(feet) || absCity.target.isInWeb)) {return;}
        if (this.canMine(feet)) {this.surroundMine(this.mutablePos.set(feet, 0.0, 0.25, 0.0));}

        else if (
            this.canMine((BlockPos)this.mutablePos.set(feet, 1, 0, 0))
                && (this.canPlace((BlockPos)this.mutablePos.set(feet, 2, -1, 0))
                || this.canPlace((BlockPos)this.mutablePos.set(feet, 3, -1, 0))
                && this.isAir((BlockPos)this.mutablePos.set(feet, 2, 0, 0)))
                && absCity.safeCheck((BlockPos)this.mutablePos.set(feet, 2, 0, 0))
        ) {this.surroundMine(this.mutablePos.set(feet, 1, 0, 0));}

        else if (
            this.canMine((BlockPos)this.mutablePos.set(feet, 0, 0, -1))
                && (this.canPlace((BlockPos)this.mutablePos.set(feet, 0, -1, -2))
                || this.canPlace((BlockPos)this.mutablePos.set(feet, 0, -1, -3))
                && this.isAir((BlockPos)this.mutablePos.set(feet, 0, 0, -2)))
                && absCity.safeCheck((BlockPos)this.mutablePos.set(feet, 0, 0, -2))
        ) {this.surroundMine(this.mutablePos.set(feet, 0, 0, -1));}

        else if (
            this.canMine((BlockPos)this.mutablePos.set(feet, -1, 0, 0))
                && (this.canPlace((BlockPos)this.mutablePos.set(feet, -2, -1, 0))
                || this.canPlace((BlockPos)this.mutablePos.set(feet, -3, -1, 0))
                && this.isAir((BlockPos)this.mutablePos.set(feet, -2, 0, 0)))
                && absCity.safeCheck((BlockPos)this.mutablePos.set(feet, -2, 0, 0))
        ) {this.surroundMine(this.mutablePos.set(feet, -1, 0, 0));}

        else if (
            this.canMine((BlockPos)this.mutablePos.set(feet, 0, 0, 1))
                && (this.canPlace((BlockPos)this.mutablePos.set(feet, 0, -1, 2))
                || this.canPlace((BlockPos)this.mutablePos.set(feet, 0, -1, 3))
                && this.isAir((BlockPos)this.mutablePos.set(feet, 0, 0, 2)))
                && absCity.safeCheck((BlockPos)this.mutablePos.set(feet, 0, 0, 2))
        ) {this.surroundMine(this.mutablePos.set(feet, 0, 0, 1));}

        else if (
            this.isAir((BlockPos)this.mutablePos.set(feet, 1, 0, 0))
                && !this.isAir((BlockPos)this.mutablePos.set(feet, 1, 1, 0))
                && this.canMine((BlockPos)this.mutablePos.set(feet, 2, 0, 0))
                && (this.canPlace((BlockPos)this.mutablePos.set(feet, 3, -1, 0))
                || this.isAir((BlockPos)this.mutablePos.set(feet, 2, 1, 0)))
                && absCity.safeCheck((BlockPos)this.mutablePos.set(feet, 3, 0, 0))
        ) {this.surroundMine(this.mutablePos.set(feet, 2, 0, 0));}

        else if (
            this.isAir((BlockPos)this.mutablePos.set(feet, 0, 0, -1))
                && !this.isAir((BlockPos)this.mutablePos.set(feet, 0, 1, -1))
                && this.canMine((BlockPos)this.mutablePos.set(feet, 0, 0, -2))
                && (this.canPlace((BlockPos)this.mutablePos.set(feet, 0, -1, -3))
                || this.isAir((BlockPos)this.mutablePos.set(feet, 0, 1, -2)))
                && absCity.safeCheck((BlockPos)this.mutablePos.set(feet, 0, 0, -3))
        ) {this.surroundMine(this.mutablePos.set(feet, 0, 0, -2));}

        else if (this.isAir((BlockPos)this.mutablePos.set(feet, -1, 0, 0))
            && !this.isAir((BlockPos)this.mutablePos.set(feet, -1, 1, 0))
            && this.canMine((BlockPos)this.mutablePos.set(feet, -2, 0, 0))
            && (this.canPlace((BlockPos)this.mutablePos.set(feet, -3, -1, 0))
            || this.isAir((BlockPos)this.mutablePos.set(feet, -2, 1, 0)))
            && absCity.safeCheck((BlockPos)this.mutablePos.set(feet, -3, 0, 0))
        ) {this.surroundMine(this.mutablePos.set(feet, -2, 0, 0));}

        else if (this.isAir((BlockPos)this.mutablePos.set(feet, 0, 0, 1))
            && !this.isAir((BlockPos)this.mutablePos.set(feet, 0, 1, 1))
            && this.canMine((BlockPos)this.mutablePos.set(feet, 0, 0, 2))
            && (this.canPlace((BlockPos)this.mutablePos.set(feet, 0, -1, 3))
            || this.isAir((BlockPos)this.mutablePos.set(feet, 0, 1, 2)))
            && absCity.safeCheck((BlockPos)this.mutablePos.set(feet, 0, 0, 3))
        ) {this.surroundMine(this.mutablePos.set(feet, 0, 0, 2));}

        else if ((this.canMine((BlockPos)this.mutablePos.set(feet, 1, -1, 0))
            || this.isAir((BlockPos)this.mutablePos.set(feet, 1, -1, 0)))
            && this.canMine((BlockPos)this.mutablePos.set(feet, 0, -1, 0))
            && (this.canPlace((BlockPos)this.mutablePos.set(feet, 2, -2, 0))
            || this.canPlace((BlockPos)this.mutablePos.set(feet, 3, -2, 0))
            && this.isAir((BlockPos)this.mutablePos.set(feet, 2, -1, 0)))
            && this.under.getValue().booleanValue()
        ) {this.surroundMine(this.mutablePos.set(feet, 0, -1, 0));}

        else if ((this.canMine((BlockPos)this.mutablePos.set(feet, 0, -1, -1)) || this.isAir((BlockPos)this.mutablePos.set(feet, 0, -1, -1))) && this.canMine((BlockPos)this.mutablePos.set(feet, 0, -1, 0)) && (this.canPlace((BlockPos)this.mutablePos.set(feet, 0, -2, -2)) || this.canPlace((BlockPos)this.mutablePos.set(feet, 0, -2, -3)) && this.isAir((BlockPos)this.mutablePos.set(feet, 0, -1, -2))) && this.under.getValue().booleanValue()) {
            this.surroundMine(this.mutablePos.set(feet, 0, -1, 0));

        } else if ((this.canMine((BlockPos)this.mutablePos.set(feet, -1, -1, 0)) || this.isAir((BlockPos)this.mutablePos.set(feet, -1, -1, 0))) && this.canMine((BlockPos)this.mutablePos.set(feet, 0, -1, 0)) && (this.canPlace((BlockPos)this.mutablePos.set(feet, -2, -2, 0)) || this.canPlace((BlockPos)this.mutablePos.set(feet, -3, -2, 0)) && this.isAir((BlockPos)this.mutablePos.set(feet, -2, -1, 0))) && this.under.getValue().booleanValue()) {
            this.surroundMine(this.mutablePos.set(feet, 0, -1, 0));

        } else if ((this.canMine((BlockPos)this.mutablePos.set(feet, 0, -1, 1)) || this.isAir((BlockPos)this.mutablePos.set(feet, 0, -1, 1))) && this.canMine((BlockPos)this.mutablePos.set(feet, 0, -1, 0)) && (this.canPlace((BlockPos)this.mutablePos.set(feet, 0, -2, 2)) || this.canPlace((BlockPos)this.mutablePos.set(feet, 0, -2, 3)) && this.isAir((BlockPos)this.mutablePos.set(feet, 0, -1, 2))) && this.under.getValue().booleanValue()) {
            this.surroundMine(this.mutablePos.set(feet, 0, -1, 0));

        } else if (this.canMine((BlockPos)this.mutablePos.set(feet, 1, 0, 0)) && this.mayPlace((BlockPos)this.mutablePos.set(feet, 1, -1, 0)) && !this.canPlace((BlockPos)this.mutablePos.set(feet, 2, -1, 0)) && this.isAir((BlockPos)this.mutablePos.set(feet, 1, 1, 0)) && absCity.safeCheck((BlockPos)this.mutablePos.set(feet, 2, 0, 0))) {
            this.surroundMine(this.mutablePos.set(feet, 1, 0, 0));

        } else if (this.canMine((BlockPos)this.mutablePos.set(feet, 0, 0, -1)) && this.mayPlace((BlockPos)this.mutablePos.set(feet, 0, -1, -1)) && !this.canPlace((BlockPos)this.mutablePos.set(feet, 0, -1, -2)) && this.isAir((BlockPos)this.mutablePos.set(feet, 0, 1, -1)) && absCity.safeCheck((BlockPos)this.mutablePos.set(feet, 0, 0, -2))) {
            this.surroundMine(this.mutablePos.set(feet, 0, 0, -1));

        } else if (this.canMine((BlockPos)this.mutablePos.set(feet, -1, 0, 0)) && this.mayPlace((BlockPos)this.mutablePos.set(feet, -1, -1, 0)) && !this.canPlace((BlockPos)this.mutablePos.set(feet, -2, -1, 0)) && this.isAir((BlockPos)this.mutablePos.set(feet, -1, 1, 0)) && absCity.safeCheck((BlockPos)this.mutablePos.set(feet, -2, 0, 0))) {
            this.surroundMine(this.mutablePos.set(feet, -1, 0, 0));

        } else if (this.canMine((BlockPos)this.mutablePos.set(feet, 0, 0, 1)) && this.mayPlace((BlockPos)this.mutablePos.set(feet, 0, -1, 1)) && !this.canPlace((BlockPos)this.mutablePos.set(feet, 0, -1, 2)) && this.isAir((BlockPos)this.mutablePos.set(feet, 0, 1, 1)) && absCity.safeCheck((BlockPos)this.mutablePos.set(feet, 0, 0, 2))) {
            this.surroundMine(this.mutablePos.set(feet, 0, 0, 1));

        } else if (this.canMine((BlockPos)this.mutablePos.set(feet, 1, 1, 0)) && this.mayPlace((BlockPos)this.mutablePos.set(feet, 1, -1, 0)) && (this.canMine((BlockPos)this.mutablePos.set(feet, 1, 0, 0)) || this.isAir((BlockPos)this.mutablePos.set(feet, 1, 0, 0))) && absCity.safeCheck((BlockPos)this.mutablePos.set(feet, 2, 0, 0)) && this.cycle.getValue().booleanValue()) {
            this.surroundMine(this.mutablePos.set(feet, 1, 1, 0));

        } else if (this.canMine((BlockPos)this.mutablePos.set(feet, 0, 1, -1)) && this.mayPlace((BlockPos)this.mutablePos.set(feet, 0, -1, -1)) && (this.canMine((BlockPos)this.mutablePos.set(feet, 0, 0, -1)) || this.isAir((BlockPos)this.mutablePos.set(feet, 0, 0, -1))) && absCity.safeCheck((BlockPos)this.mutablePos.set(feet, 0, 0, -2)) && this.cycle.getValue().booleanValue()) {
            this.surroundMine(this.mutablePos.set(feet, 0, 1, -1));

        } else if (this.canMine((BlockPos)this.mutablePos.set(feet, -1, 1, 0)) && this.mayPlace((BlockPos)this.mutablePos.set(feet, -1, -1, 0)) && (this.canMine((BlockPos)this.mutablePos.set(feet, -1, 0, 0)) || this.isAir((BlockPos)this.mutablePos.set(feet, -1, 0, 0))) && absCity.safeCheck((BlockPos)this.mutablePos.set(feet, -2, 0, 0)) && this.cycle.getValue().booleanValue()) {
            this.surroundMine(this.mutablePos.set(feet, -1, 1, 0));

        } else if (this.canMine((BlockPos)this.mutablePos.set(feet, 0, 1, 1)) && this.mayPlace((BlockPos)this.mutablePos.set(feet, 0, -1, 1)) && (this.canMine((BlockPos)this.mutablePos.set(feet, 0, 0, 1)) || this.isAir((BlockPos)this.mutablePos.set(feet, 0, 0, 1))) && absCity.safeCheck((BlockPos)this.mutablePos.set(feet, 0, 0, 2)) && this.cycle.getValue().booleanValue()) {
            this.surroundMine(this.mutablePos.set(feet, 0, 1, 1));
        }
    }

    private void surroundMine(BlockPos.MutableBlockPos position) {
        if (ABBreakManager.SelfMine((BlockPos)position)) {
            return;
        }
        if (InstantMine.breakPos != null && BlockUtil.getBlock(InstantMine.breakPos) == Blocks.REDSTONE_BLOCK) {
            return;
        }
        if (InstantMine.breakPos != null && BlockUtil.getBlock(InstantMine.breakPos) != Blocks.AIR && absCity.mc.player.getDistanceSq(InstantMine.breakPos) <= MathUtil.square(6.0)) {
            return;
        }
        if (ABBreakManager.SelfMine(new BlockPos(absCity.mc.player.posX, absCity.mc.player.posY + 2.0, absCity.mc.player.posZ)) || ABBreakManager.SelfMine(new BlockPos(absCity.mc.player.posX, absCity.mc.player.posY + 3.0, absCity.mc.player.posZ)) || ABBreakManager.SelfMine(new BlockPos(absCity.mc.player.posX, absCity.mc.player.posY - 1.0, absCity.mc.player.posZ))) {
            return;
        }
        if (absCity.mc.player.rotationPitch <= 90.0f && absCity.mc.player.rotationPitch >= 80.0f) {
            return;
        }
        BlockPos immutablePos = position.toImmutable();
        absCity.mc.playerController.onPlayerDamageBlock(immutablePos, BlockUtil.getRayTraceFacing(immutablePos));
    }

    private boolean detection(EntityPlayer player) {
        BlockPos target = EntityUtil.getPlayerPos(player);
        return this.canPlace((BlockPos)this.mutablePos.set(target, 1, -1, 0)) || this.canPlace((BlockPos)this.mutablePos.set(target, 2, -1, 0)) && this.isAir((BlockPos)this.mutablePos.set(target, 1, 0, 0)) || this.canPlace((BlockPos)this.mutablePos.set(target, 3, -1, 0)) && this.isAir((BlockPos)this.mutablePos.set(target, 1, 0, 0)) && this.isAir((BlockPos)this.mutablePos.set(target, 2, 0, 0)) || this.canPlace((BlockPos)this.mutablePos.set(target, -1, -1, 0)) || this.canPlace((BlockPos)this.mutablePos.set(target, -2, -1, 0)) && this.isAir((BlockPos)this.mutablePos.set(target, -1, 0, 0)) || this.canPlace((BlockPos)this.mutablePos.set(target, -3, -1, 0)) && this.isAir((BlockPos)this.mutablePos.set(target, -1, 0, 0)) && this.isAir((BlockPos)this.mutablePos.set(target, -2, 0, 0)) || this.canPlace((BlockPos)this.mutablePos.set(target, 0, -1, 1)) || this.canPlace((BlockPos)this.mutablePos.set(target, 0, -1, 2)) && this.isAir((BlockPos)this.mutablePos.set(target, 0, 0, 1)) || this.canPlace((BlockPos)this.mutablePos.set(target, 0, -1, 3)) && this.isAir((BlockPos)this.mutablePos.set(target, 0, 0, 1)) && this.isAir((BlockPos)this.mutablePos.set(target, 0, 0, 2)) || this.canPlace((BlockPos)this.mutablePos.set(target, 0, -1, -1)) || this.canPlace((BlockPos)this.mutablePos.set(target, 0, -1, -2)) && this.isAir((BlockPos)this.mutablePos.set(target, 0, 0, -1)) || this.canPlace((BlockPos)this.mutablePos.set(target, 0, -1, -3)) && this.isAir((BlockPos)this.mutablePos.set(target, 0, 0, -1)) && this.isAir((BlockPos)this.mutablePos.set(target, 0, 0, -2));
    }

    private boolean skip(EntityPlayer player) {
        BlockPos target = EntityUtil.getPlayerPos(player);
        return this.godblock((BlockPos)this.mutablePos.set(target, 1, 0, 0)) && this.godblock((BlockPos)this.mutablePos.set(target, -1, 0, 0)) && this.godblock((BlockPos)this.mutablePos.set(target, 0, 0, 1)) && this.godblock((BlockPos)this.mutablePos.set(target, 0, 0, -1)) && this.isAir(target) && !this.canMine((BlockPos)this.mutablePos.set(target, 0, -1, 0));
    }

    private boolean detection2(EntityPlayer player) {
        return absCity.mc.world.getBlockState(new BlockPos(player.posX + 1.2, player.posY, player.posZ)).getBlock() == Blocks.AIR || absCity.mc.world.getBlockState(new BlockPos(player.posX - 1.2, player.posY, player.posZ)).getBlock() == Blocks.AIR || absCity.mc.world.getBlockState(new BlockPos(player.posX, player.posY, player.posZ + 1.2)).getBlock() == Blocks.AIR || absCity.mc.world.getBlockState(new BlockPos(player.posX, player.posY, player.posZ - 1.2)).getBlock() == Blocks.AIR;
    }

    private boolean placeCheck(BlockPos block) {
        if (!this.mineweb.getValue().booleanValue() && BlockUtil.getBlock(block).equals(Blocks.WEB)) {
            return false;
        }
        return !(BlockUtil.getMineDistance(block) > MathUtil.square(this.range.getValue().floatValue()));
    }

    private EntityPlayer getTarget(double range) {
        EntityPlayer target = null;
        double distance = range;
        for (EntityPlayer player : absCity.mc.world.playerEntities) {
            if (EntityUtil.isntValid((Entity)player, range) || this.skip(player)) continue;
            if (target == null) {
                target = player;
                distance = EntityUtil.mc.player.getDistanceSq((Entity)player);
                continue;
            }
            if (EntityUtil.mc.player.getDistanceSq((Entity)player) >= distance) continue;
            target = player;
            distance = EntityUtil.mc.player.getDistanceSq((Entity)player);
        }
        return target;
    }

    private boolean canMine(BlockPos block) {
        return !BlockUtil.godBlocks.contains(BlockUtil.getBlock(block)) && this.placeCheck(block);
    }

    private boolean isAir(BlockPos block) {
        return BlockUtil.getBlock(block) == Blocks.AIR;
    }

    private boolean godblock(BlockPos block) {
        return BlockUtil.getBlock(block) == Blocks.BEDROCK;
    }

    private boolean canPlace(BlockPos block) {
        return (BlockUtil.getBlock(block) == Blocks.OBSIDIAN || BlockUtil.getBlock(block) == Blocks.BEDROCK) && BlockUtil.getBlock(block.add(0, 1, 0)) == Blocks.AIR && BlockUtil.getBlock(block.add(0, 2, 0)) == Blocks.AIR;
    }

    private boolean mayPlace(BlockPos block) {
        return BlockUtil.getBlock(block) == Blocks.OBSIDIAN || BlockUtil.getBlock(block) == Blocks.BEDROCK;
    }
}

