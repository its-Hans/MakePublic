package dev.madcat.m3dc3t.features.modules.useless;

import dev.madcat.m3dc3t.M3dC3t;
import dev.madcat.m3dc3t.features.command.Command;
import dev.madcat.m3dc3t.features.modules.Module;
import dev.madcat.m3dc3t.features.setting.Setting;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketChatMessage;

import java.util.HashMap;

public class AutoOtto extends Module {
    public static HashMap<String, Integer> TotemPopContainer = new HashMap();
    private static AutoOtto INSTANCE = new AutoOtto();

    public AutoOtto() {
        super("AutoOtto", "some problem", Category.USELESS, true, false, false);
        this.setInstance();
    }

    public static AutoOtto getInstance() {if (INSTANCE == null) {INSTANCE = new AutoOtto();}return INSTANCE;}
    private void setInstance() {INSTANCE = this;}
    private Setting<Mode> mode = this.register(new Setting<Mode>("Mode", Mode.OTTO));
    private Setting<String> Cus7oMsg = this.register(new Setting<String>("CustomMessage", "NMSL"));


    public void onDeath(EntityPlayer player) {
        if (TotemPopContainer.containsKey(player.getName())) {
            int PlayerPops = TotemPopContainer.get(player.getName());
            TotemPopContainer.remove(player.getName());
            if (M3dC3t.moduleManager.isModuleEnabled("AutoOtto"))
            {
                    Command.sendMessage(player.getName() + " Ezed");
                    if (this.mode.getValue() == Mode.OTTO)
                    {mc.player.connection.sendPacket(new CPacketChatMessage("!" + player.getName() + ","));}
                    if (this.mode.getValue() == Mode.LEFT)
                    {mc.player.connection.sendPacket(new CPacketChatMessage(Cus7oMsg + player.getName()));}
                    if (this.mode.getValue() == Mode.RIGHT)
                    {mc.player.connection.sendPacket(new CPacketChatMessage(player.getName() + Cus7oMsg));}
            }
            }
        }
    public static enum Mode {LEFT, RIGHT, OTTO}
    }

