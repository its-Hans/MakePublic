package dev.madcat.m3dc3t.features.modules.combat;

import com.mojang.realmsclient.gui.ChatFormatting;

import dev.madcat.m3dc3t.features.setting.Setting;
import dev.madcat.m3dc3t.features.command.Command;
import dev.madcat.m3dc3t.features.modules.Module;

import skid.scat3.Util.BlockUtil;
import skid.scat3.Util.EntityUtil;
import skid.scat3.Util.InventoryUtil;
import skid.scat3.Util.RotationUtil;
import skid.scat3.Util.Timer;

import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class BurrowPlus
extends Module {
    public final Setting<Boolean> packet;
    public final Setting<Boolean> onlyGround;
    private final Setting<Boolean> breakCrystal;
    private final Setting<Boolean> multiPlace;
    public final Setting<Boolean> debug;
    public final Setting<Boolean> rotate;
    static final Timer breakTimer = new Timer();

    public BurrowPlus()
    {
        super("BurrowPlus", "skid", Category.COMBAT, true, false, false);
        this.packet = (Setting<Boolean>)this.register(new Setting("Packet", true));
        this.onlyGround = (Setting<Boolean>)this.register(new Setting("onlyGround", true));
        this.debug = (Setting<Boolean>)this.register(new Setting("Debug", false));
        this.breakCrystal = (Setting<Boolean>)this.register(new Setting("BreakCrystal", true));
        this.multiPlace = (Setting<Boolean>)this.register(new Setting("MultiPlace", true));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", true));
    }

    public void attackCrystal()
    {
        if (!breakTimer.passedMs(250L)) {return;}

        breakTimer.reset();
        for (Entity entity : BurrowPlus.mc.world.loadedEntityList)
        {
            if (!(entity instanceof EntityEnderCrystal)) continue;
            if (entity.getDistance(BurrowPlus.mc.player.posX, BurrowPlus.mc.player.posY, BurrowPlus.mc.player.posZ) > 2.5) {continue;}
            BurrowPlus.mc.player.connection.sendPacket(new CPacketUseEntity(entity));
            BurrowPlus.mc.player.connection.sendPacket(new CPacketAnimation(EnumHand.MAIN_HAND));
            BlockPos blockPos = new BlockPos(entity.posX, entity.posY, entity.posZ);
            if (!this.rotate.getValue()) break;
            RotationUtil.facePos(blockPos);
            break;
        }
    }

    @Override
    public void onTick() {
        int n = BurrowPlus.mc.player.inventory.currentItem;
        BlockPos blockPos = new BlockPos(BurrowPlus.mc.player.posX, BurrowPlus.mc.player.posY + 0.5, BurrowPlus.mc.player.posZ);
        if (InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.OBSIDIAN)) == -1 && InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.ENDER_CHEST)) == -1) {
            Command.sendMessage(ChatFormatting.RED + "Obsidian/Ender Chest ?");
            this.disable();
            return;
        }
        if (this.breakCrystal.getValue()) {
            this.attackCrystal();
        }
        if (this.onlyGround.getValue() && !BurrowPlus.mc.player.onGround) {
            return;
        }
        if (!BurrowPlus.mc.world.getBlockState(blockPos.offset(EnumFacing.UP, 2)).getBlock().equals(Blocks.AIR) || BurrowPlus.mc.world.getBlockState(blockPos.add(1, 2, 0)).getBlock() != Blocks.AIR && BurrowPlus.checkSelf(blockPos.add(1, 0, 0)) != null || BurrowPlus.mc.world.getBlockState(blockPos.add(-1, 2, 0)).getBlock() != Blocks.AIR && BurrowPlus.checkSelf(blockPos.add(-1, 0, 0)) != null || BurrowPlus.mc.world.getBlockState(blockPos.add(0, 2, 1)).getBlock() != Blocks.AIR && BurrowPlus.checkSelf(blockPos.add(0, 0, 1)) != null || BurrowPlus.mc.world.getBlockState(blockPos.add(0, 2, -1)).getBlock() != Blocks.AIR && BurrowPlus.checkSelf(blockPos.add(0, 0, -1)) != null || BurrowPlus.mc.world.getBlockState(blockPos.add(1, 2, 1)).getBlock() != Blocks.AIR && BurrowPlus.checkSelf(blockPos.add(1, 0, 1)) != null || BurrowPlus.mc.world.getBlockState(blockPos.add(1, 2, -1)).getBlock() != Blocks.AIR && BurrowPlus.checkSelf(blockPos.add(1, 0, -1)) != null || BurrowPlus.mc.world.getBlockState(blockPos.add(-1, 2, 1)).getBlock() != Blocks.AIR && BurrowPlus.checkSelf(blockPos.add(-1, 0, 1)) != null || BurrowPlus.mc.world.getBlockState(blockPos.add(-1, 2, -1)).getBlock() != Blocks.AIR && BurrowPlus.checkSelf(blockPos.add(-1, 0, -1)) != null) {
            boolean bl = false;
            boolean bl2 = false;
            BlockPos blockPos2 = blockPos;
            if (BurrowPlus.checkSelf(blockPos2) != null && !BurrowPlus.isAir(blockPos2)) {
                BurrowPlus.mc.player.connection.sendPacket(new CPacketPlayer.Position(BurrowPlus.mc.player.posX + ((double)blockPos2.getX() + 0.5 - BurrowPlus.mc.player.posX) / 2.0, BurrowPlus.mc.player.posY + 0.2, BurrowPlus.mc.player.posZ + ((double)blockPos2.getZ() + 0.5 - BurrowPlus.mc.player.posZ) / 2.0, false));
                BurrowPlus.mc.player.connection.sendPacket(new CPacketPlayer.Position(BurrowPlus.mc.player.posX + ((double)blockPos2.getX() + 0.5 - BurrowPlus.mc.player.posX), BurrowPlus.mc.player.posY + 0.2, BurrowPlus.mc.player.posZ + ((double)blockPos2.getZ() + 0.5 - BurrowPlus.mc.player.posZ), false));
                if (this.debug.getValue()) {
                    Command.sendMessage("autochthonous " + ((double) blockPos2.getX() + 0.5 - BurrowPlus.mc.player.posX) + " " + ((double) blockPos2.getZ() + 0.5 - BurrowPlus.mc.player.posZ));
                }
            } else {
                for (EnumFacing enumFacing : EnumFacing.VALUES) {
                    if (enumFacing == EnumFacing.UP) continue;
                    if (enumFacing == EnumFacing.DOWN) {
                        continue;
                    }
                    blockPos2 = blockPos.offset(enumFacing);
                    if (BurrowPlus.checkSelf(blockPos2) == null || BurrowPlus.isAir(blockPos2)) continue;
                    BurrowPlus.mc.player.connection.sendPacket(new CPacketPlayer.Position(BurrowPlus.mc.player.posX + ((double)blockPos2.getX() + 0.5 - BurrowPlus.mc.player.posX) / 2.0, BurrowPlus.mc.player.posY + 0.2, BurrowPlus.mc.player.posZ + ((double)blockPos2.getZ() + 0.5 - BurrowPlus.mc.player.posZ) / 2.0, false));
                    BurrowPlus.mc.player.connection.sendPacket(new CPacketPlayer.Position(BurrowPlus.mc.player.posX + ((double)blockPos2.getX() + 0.5 - BurrowPlus.mc.player.posX), BurrowPlus.mc.player.posY + 0.2, BurrowPlus.mc.player.posZ + ((double)blockPos2.getZ() + 0.5 - BurrowPlus.mc.player.posZ), false));
                    bl = true;
                    if (!this.debug.getValue()) break;
                    Command.sendMessage("no air " + ((double) blockPos2.getX() + 0.5 - BurrowPlus.mc.player.posX) + " " + ((double) blockPos2.getZ() + 0.5 - BurrowPlus.mc.player.posZ));
                    break;
                }
                if (!bl) {
                    for (EnumFacing enumFacing : EnumFacing.VALUES) {
                        if (enumFacing == EnumFacing.UP) continue;
                        if (enumFacing == EnumFacing.DOWN) {
                            continue;
                        }
                        blockPos2 = blockPos.offset(enumFacing);
                        if (BurrowPlus.checkSelf(blockPos2) == null) continue;
                        BurrowPlus.mc.player.connection.sendPacket(new CPacketPlayer.Position(BurrowPlus.mc.player.posX + ((double)blockPos2.getX() + 0.5 - BurrowPlus.mc.player.posX) / 2.0, BurrowPlus.mc.player.posY + 0.2, BurrowPlus.mc.player.posZ + ((double)blockPos2.getZ() + 0.5 - BurrowPlus.mc.player.posZ) / 2.0, false));
                        BurrowPlus.mc.player.connection.sendPacket(new CPacketPlayer.Position(BurrowPlus.mc.player.posX + ((double)blockPos2.getX() + 0.5 - BurrowPlus.mc.player.posX), BurrowPlus.mc.player.posY + 0.2, BurrowPlus.mc.player.posZ + ((double)blockPos2.getZ() + 0.5 - BurrowPlus.mc.player.posZ), false));
                        bl2 = true;
                        if (!this.debug.getValue()) break;
                        Command.sendMessage("entity " + ((double) blockPos2.getX() + 0.5 - BurrowPlus.mc.player.posX) + " " + ((double) blockPos2.getZ() + 0.5 - BurrowPlus.mc.player.posZ));
                        break;
                    }
                    if (!bl2) {
                        for (EnumFacing enumFacing : EnumFacing.VALUES) {
                            if (enumFacing == EnumFacing.UP) continue;
                            if (enumFacing == EnumFacing.DOWN) {
                                continue;
                            }
                            blockPos2 = blockPos.offset(enumFacing);
                            if (!BurrowPlus.isAir(blockPos2) || !BurrowPlus.isAir(blockPos2.offset(EnumFacing.UP))) continue;
                            BurrowPlus.mc.player.connection.sendPacket(new CPacketPlayer.Position(BurrowPlus.mc.player.posX + ((double)blockPos2.getX() + 0.5 - BurrowPlus.mc.player.posX) / 2.0, BurrowPlus.mc.player.posY + 0.2, BurrowPlus.mc.player.posZ + ((double)blockPos2.getZ() + 0.5 - BurrowPlus.mc.player.posZ) / 2.0, false));
                            BurrowPlus.mc.player.connection.sendPacket(new CPacketPlayer.Position(BurrowPlus.mc.player.posX + ((double)blockPos2.getX() + 0.5 - BurrowPlus.mc.player.posX), BurrowPlus.mc.player.posY + 0.2, BurrowPlus.mc.player.posZ + ((double)blockPos2.getZ() + 0.5 - BurrowPlus.mc.player.posZ), false));
                            if (!this.debug.getValue()) break;
                            Command.sendMessage("air " + ((double) blockPos2.getX() + 0.5 - BurrowPlus.mc.player.posX) + " " + ((double) blockPos2.getZ() + 0.5 - BurrowPlus.mc.player.posZ));
                            break;
                        }
                    }
                }
            }
        } else {
            if (this.debug.getValue()) {
                Command.sendMessage("fake jump");
            }
            BurrowPlus.mc.player.connection.sendPacket(new CPacketPlayer.Position(BurrowPlus.mc.player.posX, BurrowPlus.mc.player.posY + 0.4199999868869781, BurrowPlus.mc.player.posZ, false));
            BurrowPlus.mc.player.connection.sendPacket(new CPacketPlayer.Position(BurrowPlus.mc.player.posX, BurrowPlus.mc.player.posY + 0.7531999805212017, BurrowPlus.mc.player.posZ, false));
            BurrowPlus.mc.player.connection.sendPacket(new CPacketPlayer.Position(BurrowPlus.mc.player.posX, BurrowPlus.mc.player.posY + 0.9999957640154541, BurrowPlus.mc.player.posZ, false));
            BurrowPlus.mc.player.connection.sendPacket(new CPacketPlayer.Position(BurrowPlus.mc.player.posX, BurrowPlus.mc.player.posY + 1.1661092609382138, BurrowPlus.mc.player.posZ, false));
        }
        BurrowPlus.mc.player.inventory.currentItem = InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.OBSIDIAN)) != -1 ? InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.OBSIDIAN)) : InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.ENDER_CHEST));
        BurrowPlus.mc.playerController.updateController();
        if (this.multiPlace.getValue()) {
            if (BurrowPlus.isAir(new BlockPos(BurrowPlus.mc.player.posX + 0.3, BurrowPlus.mc.player.posY, BurrowPlus.mc.player.posZ + 0.3))) {
                try {
                    BlockUtil.placeBlock(new BlockPos(BurrowPlus.mc.player.posX + 0.3, BurrowPlus.mc.player.posY, BurrowPlus.mc.player.posZ + 0.3), EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
            if (BurrowPlus.isAir(new BlockPos(BurrowPlus.mc.player.posX + 0.3, BurrowPlus.mc.player.posY, BurrowPlus.mc.player.posZ - 0.3))) {
                try {
                    BlockUtil.placeBlock(new BlockPos(BurrowPlus.mc.player.posX + 0.3, BurrowPlus.mc.player.posY, BurrowPlus.mc.player.posZ - 0.3), EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
            if (BurrowPlus.isAir(new BlockPos(BurrowPlus.mc.player.posX - 0.3, BurrowPlus.mc.player.posY, BurrowPlus.mc.player.posZ + 0.3))) {
                try {
                    BlockUtil.placeBlock(new BlockPos(BurrowPlus.mc.player.posX - 0.3, BurrowPlus.mc.player.posY, BurrowPlus.mc.player.posZ + 0.3), EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
            if (BurrowPlus.isAir(new BlockPos(BurrowPlus.mc.player.posX - 0.3, BurrowPlus.mc.player.posY, BurrowPlus.mc.player.posZ - 0.3))) {
                try {
                    BlockUtil.placeBlock(new BlockPos(BurrowPlus.mc.player.posX - 0.3, BurrowPlus.mc.player.posY, BurrowPlus.mc.player.posZ - 0.3), EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        } else if (BurrowPlus.isAir(blockPos)) {
            try {
                BlockUtil.placeBlock(blockPos, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        } else if (BurrowPlus.isAir(new BlockPos(BurrowPlus.mc.player.posX + 0.3, BurrowPlus.mc.player.posY, BurrowPlus.mc.player.posZ + 0.3))) {
            try {
                BlockUtil.placeBlock(new BlockPos(BurrowPlus.mc.player.posX + 0.3, BurrowPlus.mc.player.posY, BurrowPlus.mc.player.posZ + 0.3), EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        } else if (BurrowPlus.isAir(new BlockPos(BurrowPlus.mc.player.posX + 0.3, BurrowPlus.mc.player.posY, BurrowPlus.mc.player.posZ - 0.3))) {
            try {
                BlockUtil.placeBlock(new BlockPos(BurrowPlus.mc.player.posX + 0.3, BurrowPlus.mc.player.posY, BurrowPlus.mc.player.posZ - 0.3), EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        } else if (BurrowPlus.isAir(new BlockPos(BurrowPlus.mc.player.posX - 0.3, BurrowPlus.mc.player.posY, BurrowPlus.mc.player.posZ + 0.3))) {
            try {
                BlockUtil.placeBlock(new BlockPos(BurrowPlus.mc.player.posX - 0.3, BurrowPlus.mc.player.posY, BurrowPlus.mc.player.posZ + 0.3), EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        } else if (BurrowPlus.isAir(new BlockPos(BurrowPlus.mc.player.posX - 0.3, BurrowPlus.mc.player.posY, BurrowPlus.mc.player.posZ - 0.3))) {
            try {
                BlockUtil.placeBlock(new BlockPos(BurrowPlus.mc.player.posX - 0.3, BurrowPlus.mc.player.posY, BurrowPlus.mc.player.posZ - 0.3), EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        BurrowPlus.mc.player.inventory.currentItem = n;
        BurrowPlus.mc.playerController.updateController();
        BurrowPlus.mc.player.connection.sendPacket(new CPacketPlayer.Position(BurrowPlus.mc.player.posX, -7.0, BurrowPlus.mc.player.posZ, false));
        this.disable();
    }

    static Entity checkSelf(BlockPos blockPos) {
        Vec3d[] vec3dArray;
        Entity entity = null;
        for (Vec3d vec3d : vec3dArray = EntityUtil.getVarOffsets(0, 0, 0)) {
            BlockPos blockPos2 = new BlockPos(blockPos).add(vec3d.x, vec3d.y, vec3d.z);
            for (Entity entity2 : BurrowPlus.mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(blockPos2))) {
                if (entity2 != BurrowPlus.mc.player) continue;
                if (entity != null) {
                    continue;
                }
                entity = entity2;
            }
        }
        return entity;
    }

    public static boolean isAir(BlockPos blockPos) {
        Block block = BurrowPlus.mc.world.getBlockState(blockPos).getBlock();
        return block instanceof BlockAir;
    }
}

