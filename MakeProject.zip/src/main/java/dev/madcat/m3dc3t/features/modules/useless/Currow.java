package dev.madcat.m3dc3t.features.modules.useless;

import com.mojang.realmsclient.gui.ChatFormatting;
import dev.madcat.m3dc3t.M3dC3t;
import dev.madcat.m3dc3t.features.command.Command;
import dev.madcat.m3dc3t.features.modules.Module;
import dev.madcat.m3dc3t.features.modules.combat.Surround;
import dev.madcat.m3dc3t.features.setting.Setting;
import dev.madcat.m3dc3t.util.BlockUtil;
import dev.madcat.m3dc3t.util.EntityUtil;
import dev.madcat.m3dc3t.util.InventoryUtil;
import dev.madcat.m3dc3t.util.skidding.SeijaBlockUtil;
import dev.madcat.m3dc3t.util.Util;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

public class Currow extends Module
{
    private boolean isSneaking;
    private final Setting<Boolean> tpcenter;
    private Setting<Boolean> rotate;
    private final Setting<Boolean> smartOffset;
    private final Setting<Boolean> me;
    private final Setting<Boolean> me2;
    private final Setting<Double> offsetX;
    private final Setting<Double> offsetY;
    private final Setting<Double> offsetZ;
    private final Setting<Boolean> breakCrystal;
    private final Setting<BlockMode> mode;
    
    public Currow() {
        super("Currow", "testing XD", Category.USELESS, true, false, false);
        this.me = (Setting<Boolean>)this.register(new Setting("MulPlace", (Object)true));
        this.me2 = (Setting<Boolean>)this.register(new Setting("PlusMulPlace", (Object)true));
        this.smartOffset = (Setting<Boolean>)this.register(new Setting("smartOffset", (Object)true));
        this.tpcenter = (Setting<Boolean>)this.register(new Setting("TPCenter", (Object)false));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (Object)true));
        this.offsetX = (Setting<Double>)this.register(new Setting("OffsetX", (Object)(-7.0), (Object)(-10.0), (Object)10.0));
        this.offsetY = (Setting<Double>)this.register(new Setting("OffsetY", (Object)(-7.0), (Object)(-10.0), (Object)10.0));
        this.offsetZ = (Setting<Double>)this.register(new Setting("OffsetZ", (Object)(-7.0), (Object)(-10.0), (Object)10.0));
        this.breakCrystal = (Setting<Boolean>)this.register(new Setting("BreakCrystal", (Object)true));
        this.mode = (Setting<BlockMode>)this.register(new Setting("BlockMode", (Object)BlockMode.Obsidian));
        this.isSneaking = false;
    }
    
    public void onDisable() {
        this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
    }
    
    public static void breakcrystal() {
        for (final Object crystal : (List)Currow.mc.world.loadedEntityList.stream().filter(e -> e instanceof EntityEnderCrystal && !e.isDead).sorted(Comparator.comparing(e -> Currow.mc.player.getDistance(e))).collect(Collectors.toList())) {
            if (crystal instanceof EntityEnderCrystal && Currow.mc.player.getDistance((Entity) crystal) <= 4.0f) {
                Currow.mc.player.connection.sendPacket((Packet)new CPacketUseEntity((Entity) crystal));
                Currow.mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.OFF_HAND));
            }
        }
    }
    
    public void onTick() {
        this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
        if (this.breakCrystal.getValue()) {
            final Currow Currow = this;
            breakcrystal();
        }
        if (!Util.mc.world.isBlockLoaded(Util.mc.player.getPosition())) {
            return;
        }
        if (!Util.mc.player.onGround || Util.mc.world.getBlockState(new BlockPos(Util.mc.player.posX, Util.mc.player.posY + 2.0, Util.mc.player.posZ)).getBlock() != Blocks.AIR) {
            this.disable();
            return;
        }
        if (Util.mc.world.getBlockState(new BlockPos(Util.mc.player.posX, (double)Math.round(Util.mc.player.posY), Util.mc.player.posZ)).getBlock() != Blocks.AIR) {
            this.disable();
            return;
        }
        if (this.mode.getValue() == BlockMode.Obsidian && InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.OBSIDIAN)) == -1) {
            Command.sendMessage(ChatFormatting.RED + "Ob??");
            this.disable();
            return;
        }
        if (this.mode.getValue() == BlockMode.Chest && InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.ENDER_CHEST)) == -1) {
            Command.sendMessage(ChatFormatting.RED + "EC??");
            this.disable();
            return;
        }
        if (this.mode.getValue() == BlockMode.Smart && InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.OBSIDIAN)) == -1 && InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.ENDER_CHEST)) == -1) {
            Command.sendMessage(ChatFormatting.RED + "Ob&EC??????????????");
            this.disable();
            return;
        }
        if (this.tpcenter.getValue()) {
            final BlockPos startPos = EntityUtil.getRoundedBlockPos((Entity) Surround.mc.player);
            M3dC3t.positionManager.setPositionPacket(startPos.getX() + 0.5, (double)startPos.getY(), startPos.getZ() + 0.5, true, true, true);
        }
        Currow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Currow.mc.player.posX, Currow.mc.player.posY + 0.41999998688698, Currow.mc.player.posZ, false));
        Currow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Currow.mc.player.posX, Currow.mc.player.posY + 0.7500019, Currow.mc.player.posZ, false));
        Currow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Currow.mc.player.posX, Currow.mc.player.posY + 0.9999962, Currow.mc.player.posZ, false));
        Util.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Util.mc.player.posX, Util.mc.player.posY + 1.166109260938214, Util.mc.player.posZ, false));
        Util.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Util.mc.player.posX, Util.mc.player.posY + 1.166109260938215, Util.mc.player.posZ, false));
        final int a = Util.mc.player.inventory.currentItem;
        if (this.mode.getValue() == BlockMode.Obsidian) {
            InventoryUtil.switchToHotbarSlot(InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.OBSIDIAN)), false);
        }
        if (this.mode.getValue() == BlockMode.Chest) {
            InventoryUtil.switchToHotbarSlot(InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.ENDER_CHEST)), false);
        }
        if (this.mode.getValue() == BlockMode.Smart) {
            if (InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.ENDER_CHEST)) != -1) {
                InventoryUtil.switchToHotbarSlot(InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.ENDER_CHEST)), false);
            }
            else if (InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.OBSIDIAN)) != -1) {
                InventoryUtil.switchToHotbarSlot(InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.OBSIDIAN)), false);
            }
        }
        this.isSneaking = BlockUtil.placeBlock(new BlockPos((Vec3i)getPlayerPosFixY((EntityPlayer)Currow.mc.player)), EnumHand.MAIN_HAND, (boolean)this.rotate.getValue(), true, this.isSneaking);
        if (this.me.getValue()) {
            this.isSneaking = BlockUtil.placeBlock(new BlockPos((Vec3i)getPlayerPosFixY2((EntityPlayer)Currow.mc.player)), EnumHand.MAIN_HAND, (boolean)this.rotate.getValue(), true, this.isSneaking);
            final Vec3d baseVec = new Vec3d(Currow.mc.player.posX, Currow.mc.player.posY, Currow.mc.player.posZ);
            if (!SeijaBlockUtil.isAir(baseVec.add(0.3, -1.0, 0.3))) {
                SeijaBlockUtil.placeBlock(baseVec.add(0.3, 0.0, 0.3), EnumHand.MAIN_HAND, false, true);
            }
            if (!SeijaBlockUtil.isAir(baseVec.add(-0.3, -1.0, 0.3))) {
                SeijaBlockUtil.placeBlock(baseVec.add(-0.3, 0.0, 0.3), EnumHand.MAIN_HAND, false, true);
            }
            if (!SeijaBlockUtil.isAir(baseVec.add(0.3, -1.0, -0.3))) {
                SeijaBlockUtil.placeBlock(baseVec.add(0.3, 0.0, -0.3), EnumHand.MAIN_HAND, false, true);
            }
            if (!SeijaBlockUtil.isAir(baseVec.add(-0.3, -1.0, -0.3))) {
                SeijaBlockUtil.placeBlock(baseVec.add(-0.3, 0.0, -0.3), EnumHand.MAIN_HAND, false, true);
            }
            if (!(boolean)this.me2.getValue()) {
                if (!SeijaBlockUtil.isAir(baseVec.add(0.3, -1.0, 0.3))) {
                    SeijaBlockUtil.placeBlock(baseVec.add(0.3, 0.0, 0.3), EnumHand.MAIN_HAND, false, true);
                }
                if (!SeijaBlockUtil.isAir(baseVec.add(-0.3, -1.0, 0.3))) {
                    SeijaBlockUtil.placeBlock(baseVec.add(-0.3, 0.0, 0.3), EnumHand.MAIN_HAND, false, true);
                }
                if (!SeijaBlockUtil.isAir(baseVec.add(0.3, -1.0, -0.3))) {
                    SeijaBlockUtil.placeBlock(baseVec.add(0.3, 0.0, -0.3), EnumHand.MAIN_HAND, false, true);
                }
                if (!SeijaBlockUtil.isAir(baseVec.add(-0.3, -1.0, -0.3))) {
                    SeijaBlockUtil.placeBlock(baseVec.add(-0.3, 0.0, -0.3), EnumHand.MAIN_HAND, false, true);
                }
            }
            Util.mc.playerController.updateController();
            Util.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(a));
            Util.mc.player.inventory.currentItem = a;
            Util.mc.playerController.updateController();
            if (this.smartOffset.getValue()) {
                boolean defaultOffset = true;
                if (Currow.mc.player.posY >= 3.0) {
                    for (int i = -10; i < 10; ++i) {
                        if (i == -1) {
                            i = 3;
                        }
                        if (Currow.mc.world.getBlockState(SeijaBlockUtil.getFlooredPosition((Entity)Currow.mc.player).add(0, i, 0)).getBlock().equals(Blocks.AIR) && Currow.mc.world.getBlockState(SeijaBlockUtil.getFlooredPosition((Entity)Currow.mc.player).add(0, i + 1, 0)).getBlock().equals(Blocks.AIR)) {
                            final BlockPos pos = SeijaBlockUtil.getFlooredPosition((Entity)Currow.mc.player).add(0, i, 0);
                            Util.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(pos.getX() + 0.3, (double)pos.getY(), pos.getZ() + 0.3, true));
                            defaultOffset = false;
                            break;
                        }
                    }
                }
                if (defaultOffset) {
                    Util.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Util.mc.player.posX + (double)this.offsetX.getValue(), Util.mc.player.posY + (double)this.offsetY.getValue(), Util.mc.player.posZ + (double)this.offsetZ.getValue(), true));
                }
            }
            else {
                Util.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Util.mc.player.posX + (double)this.offsetX.getValue(), Util.mc.player.posY + (double)this.offsetY.getValue(), Util.mc.player.posZ + (double)this.offsetZ.getValue(), true));
            }
            this.disable();
        }
    }
    
    public static BlockPos getPlayerPosFixY(final EntityPlayer player) {
        return new BlockPos(Math.floor(player.posX), (double)Math.round(player.posY), Math.floor(player.posZ));
    }
    
    public static BlockPos getPlayerPosFixY2(final EntityPlayer player) {
        return new BlockPos(Math.floor(player.posX - 0.3), (double)Math.round(player.posY), Math.floor(player.posZ));
    }
    
    public static BlockPos getPlayerPosFixY3(final EntityPlayer player) {
        return new BlockPos(Math.floor(player.posX + 0.3), (double)Math.round(player.posY), Math.floor(player.posZ));
    }
    
    public static BlockPos getPlayerPosFixY4(final EntityPlayer player) {
        return new BlockPos(Math.floor(player.posX), (double)Math.round(player.posY), Math.floor(player.posZ - 0.3));
    }
    
    public static BlockPos getPlayerPosFixY5(final EntityPlayer player) {
        return new BlockPos(Math.floor(player.posX), (double)Math.round(player.posY), Math.floor(player.posZ + 0.3));
    }
    
    enum BlockMode
    {
        Obsidian, 
        Chest, 
        Smart;
    }
}
