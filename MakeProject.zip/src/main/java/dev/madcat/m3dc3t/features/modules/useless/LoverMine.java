package dev.madcat.m3dc3t.features.modules.useless;

import dev.madcat.m3dc3t.event.events.BlockEvent;
import dev.madcat.m3dc3t.event.events.PacketEvent;
import dev.madcat.m3dc3t.event.events.Render3DEvent;
import dev.madcat.m3dc3t.features.Feature;
import dev.madcat.m3dc3t.features.modules.Module;
import dev.madcat.m3dc3t.features.setting.Bind;
import dev.madcat.m3dc3t.features.setting.Setting;
import dev.madcat.m3dc3t.util.skidding.BlockRenderSmooth;
import dev.madcat.m3dc3t.util.BlockUtil;
import dev.madcat.m3dc3t.util.skidding.FadeUtils;
import dev.madcat.m3dc3t.util.InventoryUtil;
import dev.madcat.m3dc3t.util.MathUtil;
import dev.madcat.m3dc3t.util.skidding.RenderUtils3D;
import dev.madcat.m3dc3t.util.Timer;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.block.Block;
import net.minecraft.block.BlockObsidian;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class LoverMine extends Module
{
    public static BlockRenderSmooth blockRenderSmooth;
    public static FadeUtils fadeBlockSize;
    public static FadeUtils pos2FadeBlockSize;
    Timer timer;
    Setting<Boolean> haste;
    Setting<Boolean> ghostHand;
    Setting<Boolean> fuck;
    public static Setting<Boolean> doubleBreak;
    Setting<Boolean> crystal;
    Setting<Boolean> attackcrystal;
    Setting<Bind> bind;
    Setting<Float> range;
    Setting<Boolean> instant;
    Setting<Boolean> render;
    Setting<Boolean> boxRender;
    Setting<Integer> boxAlpha;
    Setting<Integer> red;
    Setting<Integer> green;
    Setting<Integer> blue;
    Setting<Integer> alpha;
    Setting<RenderMode> renderMode;
    Setting<Boolean> render2;
    Setting<Boolean> render3;
    Setting<Boolean> boxRender2;
    Setting<Integer> boxAlpha2;
    Setting<Integer> red2;
    Setting<Integer> green2;
    Setting<Integer> blue2;
    Setting<Integer> alpha2;
    Setting<RenderMode> renderMode2;
    public static final List<Block> godBlocks;
    private static boolean cancelStart;
    private static boolean empty;
    private static EnumFacing facing;
    public static BlockPos breakPos;
    public static BlockPos breakPos2;
    private static final Timer breakSuccess;
    public static int tickCount;
    public static int tickCount2;
    public static double time;
    public static double time2;
    private static LoverMine INSTANCE;
    private Block block;
    
    public LoverMine() {
        super("LoverMine", "uselessable", Category.USELESS, true, false, false);
        this.timer = new Timer();
        this.haste = (Setting<Boolean>)this.register(new Setting("Haste", (Object)true));
        this.range = (Setting<Float>)this.register(new Setting("Range", (Object)256.0f, (Object)1.0f, (Object)256.0f));
        this.ghostHand = (Setting<Boolean>)this.register(new Setting("GhostHand", (Object)true));
        this.fuck = (Setting<Boolean>)this.register(new Setting("Super Ghost hand", (Object)false));
        LoverMine.doubleBreak = (Setting<Boolean>)this.register(new Setting("DoubleBreak", (Object)false));
        this.crystal = (Setting<Boolean>)this.register(new Setting("Crystal", (Object)false));
        this.attackcrystal = (Setting<Boolean>)this.register(new Setting("Attack Crystal", (Object)false, v -> this.crystal.getValue()));
        this.bind = (Setting<Bind>)this.register(new Setting("ObsidianBind", (Object)new Bind(-1), v -> this.crystal.getValue()));
        this.instant = (Setting<Boolean>)this.register(new Setting("Instant", (Object)true));
        this.render = (Setting<Boolean>)this.register(new Setting("Render", (Object)true));
        this.render2 = (Setting<Boolean>)this.register(new Setting("FirstRender", (Object)true, v -> this.render.getValue()));
        this.boxRender = (Setting<Boolean>)this.register(new Setting("FirstBox", (Object)true, v -> this.render.getValue()));
        this.boxAlpha = (Setting<Integer>)this.register(new Setting("FirstBoxAlpha", (Object)85, (Object)0, (Object)255, v -> this.boxRender.getValue() && this.render.getValue()));
        this.red = (Setting<Integer>)this.register(new Setting("FirstRed", (Object)255, (Object)0, (Object)255, v -> this.render.getValue()));
        this.green = (Setting<Integer>)this.register(new Setting("FirstGreen", (Object)255, (Object)0, (Object)255, v -> this.render.getValue()));
        this.blue = (Setting<Integer>)this.register(new Setting("FirstBlue", (Object)255, (Object)0, (Object)255, v -> this.render.getValue()));
        this.alpha = (Setting<Integer>)this.register(new Setting("FirstAlpha", (Object)60, (Object)0, (Object)255, v -> this.render.getValue()));
        this.renderMode = (Setting<RenderMode>)this.register(new Setting("FirstRenderMode", (Object)RenderMode.Outline));
        this.render3 = (Setting<Boolean>)this.register(new Setting("SecondRender", (Object)true, v -> this.render.getValue()));
        this.boxRender2 = (Setting<Boolean>)this.register(new Setting("SecondBox", (Object)true, v -> this.render.getValue()));
        this.boxAlpha2 = (Setting<Integer>)this.register(new Setting("SecondBoxAlpha", (Object)85, (Object)0, (Object)255, v -> this.render.getValue()));
        this.red2 = (Setting<Integer>)this.register(new Setting("SecondRed", (Object)255, (Object)0, (Object)255, v -> this.render.getValue()));
        this.green2 = (Setting<Integer>)this.register(new Setting("SecondGreen", (Object)255, (Object)0, (Object)255, v -> this.render.getValue()));
        this.blue2 = (Setting<Integer>)this.register(new Setting("SecondBlue", (Object)255, (Object)0, (Object)255, v -> this.render.getValue()));
        this.alpha2 = (Setting<Integer>)this.register(new Setting("SecondAlpha", (Object)60, (Object)0, (Object)255, v -> this.render.getValue()));
    }
    
    public static LoverMine getInstance() {
        if (LoverMine.INSTANCE == null) {
            LoverMine.INSTANCE = new LoverMine();
        }
        return LoverMine.INSTANCE;
    }
    
    private void setInstance() {
        LoverMine.INSTANCE = this;
    }
    
    public static void attackcrystal() {
        for (final Object crystal : (List)LoverMine.mc.world.loadedEntityList.stream().filter(e -> e instanceof EntityEnderCrystal && !e.isDead).sorted(Comparator.comparing(e -> LoverMine.mc.player.getDistance(e))).collect(Collectors.toList())) {
            if (crystal instanceof EntityEnderCrystal && ((EntityEnderCrystal) crystal).getDistanceSq(LoverMine.breakPos) <= 2.0) {
                LoverMine.mc.player.connection.sendPacket((Packet)new CPacketUseEntity((Entity) crystal));
                LoverMine.mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.OFF_HAND));
            }
        }
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send event) {
        if (Feature.fullNullCheck()) {
            rend();
            return;
        }
        if (LoverMine.breakPos != null && LoverMine.mc.player != null && LoverMine.mc.player.getDistanceSq(LoverMine.breakPos) > MathUtil.square(this.range.getValue())) {
            LoverMine.breakPos = null;
            LoverMine.breakPos2 = null;
            LoverMine.cancelStart = false;
            return;
        }
        if (!this.isEnabled()) {
            rend();
            return;
        }
        if (!(event.getPacket() instanceof CPacketPlayerDigging)) {
            return;
        }
        final CPacketPlayerDigging packet = (CPacketPlayerDigging)event.getPacket();
        if (packet.getAction() != CPacketPlayerDigging.Action.START_DESTROY_BLOCK) {
            return;
        }
        event.setCanceled(LoverMine.cancelStart);
    }
    
    public int getBestAvailableToolSlot(final IBlockState blockState) {
        int toolSlot = -1;
        double max = 0.0;
        for (int i = 0; i < 9; ++i) {
            final ItemStack stack = LoverMine.mc.player.inventory.getStackInSlot(i);
            float speed;
            final int eff;
            if (!stack.isEmpty && (speed = stack.getDestroySpeed(blockState)) > 1.0f && (speed += (float)(((eff = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, stack)) > 0) ? (Math.pow(eff, 2.0) + 1.0) : 0.0)) > max) {
                max = speed;
                toolSlot = i;
            }
        }
        return toolSlot;
    }
    
    public static void ondeve(final BlockPos pos) {
        if (Feature.fullNullCheck()) {
            return;
        }
        if (!BlockUtil.canBreak(pos)) {
            return;
        }
        if (LoverMine.breakPos != null && LoverMine.breakPos.equals((Object)pos)) {
            return;
        }
        rend();
        LoverMine.blockRenderSmooth.setNewPos(pos);
        LoverMine.fadeBlockSize.reset();
        LoverMine.empty = false;
        LoverMine.cancelStart = false;
        LoverMine.breakPos = pos;
        LoverMine.tickCount = 0;
        LoverMine.breakSuccess.reset();
        LoverMine.facing = EnumFacing.UP;
        if (LoverMine.breakPos == null) {
            return;
        }
        LoverMine.mc.player.swingArm(EnumHand.MAIN_HAND);
        LoverMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, LoverMine.breakPos, LoverMine.facing));
        LoverMine.cancelStart = true;
        LoverMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, LoverMine.breakPos, LoverMine.facing));
    }
    
    public static void ondeve2(final BlockPos pos) {
        if (Feature.fullNullCheck()) {
            return;
        }
        if (!BlockUtil.canBreak(pos)) {
            return;
        }
        if (LoverMine.breakPos != null && LoverMine.breakPos.equals((Object)pos)) {
            return;
        }
        rend();
        LoverMine.blockRenderSmooth.setNewPos(pos);
        LoverMine.pos2FadeBlockSize.reset();
        LoverMine.empty = false;
        LoverMine.cancelStart = false;
        LoverMine.breakPos2 = pos;
        LoverMine.tickCount2 = 0;
        LoverMine.breakSuccess.reset();
        LoverMine.facing = EnumFacing.UP;
        if (LoverMine.breakPos == null) {
            return;
        }
        LoverMine.mc.player.swingArm(EnumHand.MAIN_HAND);
        LoverMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, LoverMine.breakPos, LoverMine.facing));
        LoverMine.cancelStart = true;
        LoverMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, LoverMine.breakPos, LoverMine.facing));
    }
    
    @SubscribeEvent
    public void onBlockEvent(final BlockEvent event) {
        if (Feature.fullNullCheck()) {
            rend();
            return;
        }
        if (!this.isEnabled()) {
            return;
        }
        if (!BlockUtil.canBreak(event.pos)) {
            return;
        }
        if (LoverMine.breakPos != null && LoverMine.breakPos.equals((Object)event.pos)) {
            return;
        }
        if (LoverMine.mc.world.getBlockState(new BlockPos(LoverMine.blockRenderSmooth.getRenderPos())).getBlock().material != Material.AIR) {
            LoverMine.pos2FadeBlockSize.reset();
        }
        LoverMine.blockRenderSmooth.setNewPos(event.pos);
        LoverMine.fadeBlockSize.reset();
        LoverMine.empty = false;
        LoverMine.cancelStart = false;
        LoverMine.breakPos2 = LoverMine.breakPos;
        LoverMine.breakPos = event.pos;
        LoverMine.tickCount2 = LoverMine.tickCount;
        LoverMine.tickCount = 0;
        LoverMine.breakSuccess.reset();
        LoverMine.facing = event.facing;
        if (LoverMine.breakPos == null) {
            return;
        }
        LoverMine.mc.player.swingArm(EnumHand.MAIN_HAND);
        LoverMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, LoverMine.breakPos, LoverMine.facing));
        LoverMine.cancelStart = true;
        LoverMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, LoverMine.breakPos, LoverMine.facing));
        event.setCanceled(true);
    }
    
    public Block whatBlock(final BlockPos pos) {
        return LoverMine.mc.world.getBlockState(pos).getBlock();
    }
    
    @Override
    public void onRender3D(final Render3DEvent event) {
        if (Feature.fullNullCheck()) {
            rend();
            return;
        }
        if (!LoverMine.cancelStart) {
            return;
        }
        if ((LoverMine.breakPos != null || (this.instant.getValue() && LoverMine.mc.world.getBlockState(LoverMine.breakPos).getBlock() == Blocks.AIR)) && LoverMine.mc.player != null && LoverMine.mc.player.getDistanceSq(LoverMine.breakPos) > MathUtil.square(this.range.getValue())) {
            LoverMine.breakPos = null;
            LoverMine.breakPos2 = null;
            LoverMine.cancelStart = false;
            return;
        }
        if (InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE) == -1) {
            return;
        }
        if (!this.fuck.getValue() && InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE) == -1) {
            return;
        }
        if (LoverMine.doubleBreak.getValue() && LoverMine.breakPos2 != null) {
            final int slotMains = LoverMine.mc.player.inventory.currentItem;
            if (LoverMine.mc.world.getBlockState(LoverMine.breakPos2).getBlock() != Blocks.AIR && InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE) != -1) {
                if (LoverMine.mc.world.getBlockState(LoverMine.breakPos2).getBlock() == Blocks.OBSIDIAN && !LoverMine.breakSuccess.passedMs(1234L)) {
                    return;
                }
                LoverMine.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE)));
                LoverMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, LoverMine.breakPos2, LoverMine.facing));
            }
            if (LoverMine.mc.world.getBlockState(LoverMine.breakPos2).getBlock() == Blocks.AIR) {
                LoverMine.breakPos2 = null;
                LoverMine.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slotMains));
            }
        }
        if (LoverMine.godBlocks.contains(LoverMine.mc.world.getBlockState(LoverMine.breakPos).getBlock())) {
            return;
        }
        if (!this.ghostHand.getValue() || (!this.fuck.getValue() && InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE) == -1) || InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE) == -1) {
            LoverMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, LoverMine.breakPos, LoverMine.facing));
            if (LoverMine.doubleBreak.getValue()) {
                LoverMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, LoverMine.breakPos2, LoverMine.facing));
            }
            return;
        }
        final int slotMain = LoverMine.mc.player.inventory.currentItem;
        if (LoverMine.mc.world.getBlockState(LoverMine.breakPos).getBlock() == Blocks.OBSIDIAN) {
            if (!LoverMine.breakSuccess.passedMs(1234L)) {
                return;
            }
            if (this.fuck.getValue() && InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE) == -1) {
                for (int i = 9; i < 36; ++i) {
                    if (LoverMine.mc.player.inventory.getStackInSlot(i).getItem() == Items.DIAMOND_PICKAXE) {
                        LoverMine.mc.playerController.windowClick(LoverMine.mc.player.inventoryContainer.windowId, i, LoverMine.mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)LoverMine.mc.player);
                        LoverMine.mc.playerController.updateController();
                        LoverMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, LoverMine.breakPos, LoverMine.facing));
                        LoverMine.mc.playerController.windowClick(LoverMine.mc.player.inventoryContainer.windowId, i, LoverMine.mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)LoverMine.mc.player);
                        LoverMine.mc.playerController.updateController();
                        return;
                    }
                }
                return;
            }
            LoverMine.mc.player.inventory.currentItem = InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE);
            LoverMine.mc.playerController.updateController();
            LoverMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, LoverMine.breakPos, LoverMine.facing));
            LoverMine.mc.player.inventory.currentItem = slotMain;
            LoverMine.mc.playerController.updateController();
        }
        else {
            if (this.fuck.getValue() && InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE) == -1) {
                for (int i = 9; i < 35; ++i) {
                    if (LoverMine.mc.player.inventory.getStackInSlot(i).getItem() == Items.DIAMOND_PICKAXE) {
                        LoverMine.mc.playerController.windowClick(LoverMine.mc.player.inventoryContainer.windowId, i, LoverMine.mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)LoverMine.mc.player);
                        LoverMine.mc.playerController.updateController();
                        LoverMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, LoverMine.breakPos, LoverMine.facing));
                        LoverMine.mc.playerController.windowClick(LoverMine.mc.player.inventoryContainer.windowId, i, LoverMine.mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)LoverMine.mc.player);
                        LoverMine.mc.playerController.updateController();
                        return;
                    }
                }
                return;
            }
            LoverMine.mc.player.inventory.currentItem = InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE);
            LoverMine.mc.playerController.updateController();
            LoverMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, LoverMine.breakPos, LoverMine.facing));
            LoverMine.mc.player.inventory.currentItem = slotMain;
            LoverMine.mc.playerController.updateController();
        }
    }
    
    public boolean check() {
        return LoverMine.breakPos.equals((Object)new BlockPos(LoverMine.mc.player.posX, LoverMine.mc.player.posY + 2.0, LoverMine.mc.player.posZ)) || LoverMine.breakPos.equals((Object)new BlockPos(LoverMine.mc.player.posX, LoverMine.mc.player.posY + 3.0, LoverMine.mc.player.posZ)) || LoverMine.breakPos.equals((Object)new BlockPos(LoverMine.mc.player.posX, LoverMine.mc.player.posY - 1.0, LoverMine.mc.player.posZ)) || LoverMine.breakPos.equals((Object)new BlockPos(LoverMine.mc.player.posX + 1.0, LoverMine.mc.player.posY, LoverMine.mc.player.posZ)) || LoverMine.breakPos.equals((Object)new BlockPos(LoverMine.mc.player.posX - 1.0, LoverMine.mc.player.posY, LoverMine.mc.player.posZ)) || LoverMine.breakPos.equals((Object)new BlockPos(LoverMine.mc.player.posX, LoverMine.mc.player.posY, LoverMine.mc.player.posZ + 1.0)) || LoverMine.breakPos.equals((Object)new BlockPos(LoverMine.mc.player.posX, LoverMine.mc.player.posY, LoverMine.mc.player.posZ - 1.0)) || LoverMine.breakPos.equals((Object)new BlockPos(LoverMine.mc.player.posX + 1.0, LoverMine.mc.player.posY + 1.0, LoverMine.mc.player.posZ)) || LoverMine.breakPos.equals((Object)new BlockPos(LoverMine.mc.player.posX - 1.0, LoverMine.mc.player.posY + 1.0, LoverMine.mc.player.posZ)) || LoverMine.breakPos.equals((Object)new BlockPos(LoverMine.mc.player.posX, LoverMine.mc.player.posY + 1.0, LoverMine.mc.player.posZ + 1.0)) || LoverMine.breakPos.equals((Object)new BlockPos(LoverMine.mc.player.posX, LoverMine.mc.player.posY + 1.0, LoverMine.mc.player.posZ - 1.0));
    }
    
    @Override
    public void onTick() {
        if (fullNullCheck()) {
            return;
        }
        if (LoverMine.mc.player.capabilities.isCreativeMode) {
            return;
        }
        if (!LoverMine.cancelStart) {
            return;
        }
        if (this.crystal.getValue() && this.attackcrystal.getValue() && LoverMine.mc.world.getBlockState(LoverMine.breakPos).getBlock() == Blocks.AIR) {
            attackcrystal();
        }
        if (this.bind.getValue().isDown() && this.crystal.getValue() && InventoryUtil.findHotbarBlock(BlockObsidian.class) != -1 && LoverMine.mc.world.getBlockState(LoverMine.breakPos).getBlock() == Blocks.AIR) {
            final int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
            final int old = LoverMine.mc.player.inventory.currentItem;
            this.switchToSlot(obbySlot);
            BlockUtil.placeBlock(LoverMine.breakPos, EnumHand.MAIN_HAND, false, true, false);
            this.switchToSlot(old);
        }
        if (LoverMine.breakPos != null && LoverMine.mc.player != null && LoverMine.mc.player.getDistanceSq(LoverMine.breakPos) > MathUtil.square(this.range.getValue())) {
            LoverMine.breakPos = null;
            LoverMine.breakPos2 = null;
            LoverMine.cancelStart = false;
            return;
        }
        if (LoverMine.mc.world.getBlockState(LoverMine.breakPos).getBlock() == Blocks.AIR && !this.instant.getValue()) {
            LoverMine.breakPos = null;
            LoverMine.breakPos2 = null;
            LoverMine.cancelStart = false;
            return;
        }
        if (LoverMine.godBlocks.contains(LoverMine.mc.world.getBlockState(LoverMine.breakPos).getBlock())) {
            return;
        }
        if (InventoryUtil.getItemHotbar(Items.END_CRYSTAL) != -1 && this.crystal.getValue() && LoverMine.mc.world.getBlockState(LoverMine.breakPos).getBlock() == Blocks.OBSIDIAN && !this.check() && !LoverMine.breakPos.equals((Object)AntiBurrow.pos)) {
            BlockUtil.placeCrystalOnBlock(LoverMine.breakPos, EnumHand.MAIN_HAND, true, false, true);
        }
        if (this.ghostHand.getValue() || (this.ghostHand.getValue() && this.fuck.getValue())) {
            final float breakTime = LoverMine.mc.world.getBlockState(LoverMine.breakPos).getBlockHardness((World)LoverMine.mc.world, LoverMine.breakPos);
            final int slotMain = LoverMine.mc.player.inventory.currentItem;
            if (!LoverMine.breakSuccess.passedMs((int)breakTime)) {
                return;
            }
            if (this.fuck.getValue() && InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE) == -1) {
                for (int i = 9; i < 36; ++i) {
                    if (LoverMine.mc.player.inventory.getStackInSlot(i).getItem() == Items.DIAMOND_PICKAXE) {
                        LoverMine.mc.playerController.windowClick(LoverMine.mc.player.inventoryContainer.windowId, i, LoverMine.mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)LoverMine.mc.player);
                        LoverMine.mc.playerController.updateController();
                        LoverMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, LoverMine.breakPos, LoverMine.facing));
                        LoverMine.mc.playerController.windowClick(LoverMine.mc.player.inventoryContainer.windowId, i, LoverMine.mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)LoverMine.mc.player);
                        LoverMine.mc.playerController.updateController();
                        return;
                    }
                }
            }
            try {
                this.block = LoverMine.mc.world.getBlockState(LoverMine.breakPos).getBlock();
            }
            catch (Exception ex) {}
            final int toolSlot = this.getBestAvailableToolSlot(this.block.getBlockState().getBaseState());
            if (LoverMine.mc.player.inventory.currentItem != toolSlot && toolSlot != -1) {
                LoverMine.mc.player.inventory.currentItem = toolSlot;
                LoverMine.mc.playerController.updateController();
                LoverMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, LoverMine.breakPos, LoverMine.facing));
                LoverMine.mc.player.inventory.currentItem = slotMain;
                LoverMine.mc.playerController.updateController();
                return;
            }
        }
        LoverMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, LoverMine.breakPos, LoverMine.facing));
        ++LoverMine.tickCount;
        ++LoverMine.tickCount2;
    }
    
    private static void rend() {
        LoverMine.time = 0.0;
        LoverMine.time2 = 0.0;
        LoverMine.empty = false;
        LoverMine.cancelStart = false;
        LoverMine.breakPos = null;
    }
    
    @Override
    public void onDisable() {
        if (Feature.fullNullCheck()) {
            return;
        }
        rend();
        LoverMine.fadeBlockSize.reset();
        if (this.haste.getValue()) {
            LoverMine.mc.player.removePotionEffect(MobEffects.HASTE);
        }
    }
    
    @Override
    public void onEnable() {
        if (Feature.fullNullCheck()) {
            rend();
        }
        LoverMine.fadeBlockSize.reset();
    }
    
    private double normalize(final double value, final double max, final double min) {
        return 0.5 * ((value - min) / (max - min)) + 0.5;
    }
    
    @SubscribeEvent
    public void onRenderWorld(final RenderWorldLastEvent event) {
        if (fullNullCheck()) {
            rend();
            return;
        }
        if (!this.isEnabled()) {
            rend();
            return;
        }
        if (!this.render.getValue()) {
            return;
        }
        if (this.render.getValue() && LoverMine.breakPos != null && LoverMine.cancelStart && this.render2.getValue()) {
            final Vec3d interpolateEntity = MathUtil.interpolateEntity((Entity)LoverMine.mc.player, LoverMine.mc.getRenderPartialTicks());
            AxisAlignedBB pos = new AxisAlignedBB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0).offset(LoverMine.blockRenderSmooth.getRenderPos());
            pos = pos.grow(0.0020000000949949026).offset(-interpolateEntity.x, -interpolateEntity.y, -interpolateEntity.z);
            this.renderESP1(pos, (float)LoverMine.fadeBlockSize.easeOutQuad());
        }
        if (LoverMine.breakPos2 != null && this.render3.getValue()) {
            final Vec3d interpolateEntity = MathUtil.interpolateEntity((Entity)LoverMine.mc.player, LoverMine.mc.getRenderPartialTicks());
            AxisAlignedBB pos = new AxisAlignedBB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0).offset(LoverMine.breakPos2);
            pos = pos.grow(0.0020000000949949026).offset(-interpolateEntity.x, -interpolateEntity.y, -interpolateEntity.z);
            this.renderESP2(pos, (float)LoverMine.pos2FadeBlockSize.easeOutQuad());
        }
    }
    
    public void renderESP1(final AxisAlignedBB axisAlignedBB, final float size) {
        final double centerX = axisAlignedBB.minX + (axisAlignedBB.maxX - axisAlignedBB.minX) / 2.0;
        final double centerY = axisAlignedBB.minY + (axisAlignedBB.maxY - axisAlignedBB.minY) / 2.0;
        final double centerZ = axisAlignedBB.minZ + (axisAlignedBB.maxZ - axisAlignedBB.minZ) / 2.0;
        final double full = axisAlignedBB.maxX - centerX;
        final double progressValX = full * size;
        final double progressValY = full * size;
        final double progressValZ = full * size;
        final AxisAlignedBB axisAlignedBB2 = new AxisAlignedBB(centerX - progressValX, centerY - progressValY, centerZ - progressValZ, centerX + progressValX, centerY + progressValY, centerZ + progressValZ);
        if (axisAlignedBB2 != null) {
            RenderUtils3D.drawBoxTest((float)axisAlignedBB2.minX, (float)axisAlignedBB2.minY, (float)axisAlignedBB2.minZ, (float)axisAlignedBB2.maxX - (float)axisAlignedBB2.minX, (float)axisAlignedBB2.maxY - (float)axisAlignedBB2.minY, (float)axisAlignedBB2.maxZ - (float)axisAlignedBB2.minZ, this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue(), 63);
        }
    }
    
    public void renderESP2(final AxisAlignedBB axisAlignedBB, final float size) {
        final double centerX = axisAlignedBB.minX + (axisAlignedBB.maxX - axisAlignedBB.minX) / 2.0;
        final double centerY = axisAlignedBB.minY + (axisAlignedBB.maxY - axisAlignedBB.minY) / 2.0;
        final double centerZ = axisAlignedBB.minZ + (axisAlignedBB.maxZ - axisAlignedBB.minZ) / 2.0;
        final double full = axisAlignedBB.maxX - centerX;
        final double progressValX = full * size;
        final double progressValY = full * size;
        final double progressValZ = full * size;
        final AxisAlignedBB axisAlignedBB2 = new AxisAlignedBB(centerX - progressValX, centerY - progressValY, centerZ - progressValZ, centerX + progressValX, centerY + progressValY, centerZ + progressValZ);
        if (axisAlignedBB2 != null) {
            RenderUtils3D.drawBoxTest((float)axisAlignedBB2.minX, (float)axisAlignedBB2.minY, (float)axisAlignedBB2.minZ, (float)axisAlignedBB2.maxX - (float)axisAlignedBB2.minX, (float)axisAlignedBB2.maxY - (float)axisAlignedBB2.minY, (float)axisAlignedBB2.maxZ - (float)axisAlignedBB2.minZ, this.red2.getValue(), this.green2.getValue(), this.blue2.getValue(), this.alpha2.getValue(), 63);
        }
    }
    
    @Override
    public String getDisplayInfo() {
        return "Instant";
    }
    
    private void switchToSlot(final int slot) {
        LoverMine.mc.player.inventory.currentItem = slot;
        LoverMine.mc.playerController.updateController();
    }
    
    static {
        godBlocks = Arrays.asList(Blocks.AIR, (Block)Blocks.FLOWING_LAVA, (Block)Blocks.LAVA, (Block)Blocks.FLOWING_WATER, (Block)Blocks.WATER, Blocks.BEDROCK);
        LoverMine.INSTANCE = new LoverMine();
        LoverMine.blockRenderSmooth = new BlockRenderSmooth(new BlockPos(0, 0, 0), 500L);
        LoverMine.fadeBlockSize = new FadeUtils(2000L);
        LoverMine.pos2FadeBlockSize = new FadeUtils(2000L);
        LoverMine.cancelStart = false;
        LoverMine.empty = false;
        breakSuccess = new Timer();
    }
    
    public enum RenderMode
    {
        Fill, 
        Outline, 
        Both;
    }
}
