package dev.madcat.m3dc3t.features.modules.misc;

import dev.madcat.m3dc3t.features.command.Command;
import dev.madcat.m3dc3t.features.modules.Module;
import dev.madcat.m3dc3t.features.setting.Setting;
import skid.skura.other.GodMode;

public class Test1 extends Module
{
    public Test1() {
        super("TestingModule", "TestingModule", Category.MISC, true, false, false);
    }
	private Setting<Mode> mode = this.register(new Setting<Mode>("Mode", Mode.outHWID));

	@Override
	public void onEnable()
	{
		if (this.mode.getValue() == Mode.Crash)
		{
			GodMode.crashOnYou();
			this.disable();
		}
		if (this.mode.getValue() == Mode.outHWID)
		{
			if (GodMode.hwidCheck()) {Command.sendMessage("true");};
			if (!GodMode.hwidCheck()) {Command.sendMessage("false");};
			Command.sendMessage(GodMode.GensHWID());
			this.disable();
		}
	}
	private enum Mode {Crash, outHWID}
}