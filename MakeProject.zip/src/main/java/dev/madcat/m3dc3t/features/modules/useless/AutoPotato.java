package dev.madcat.m3dc3t.features.modules.useless;

import dev.madcat.m3dc3t.features.modules.Module;
import dev.madcat.m3dc3t.features.setting.Setting;
import dev.madcat.m3dc3t.M3dC3t;


import java.util.Random;
import net.minecraft.network.play.client.CPacketChatMessage;



public class AutoPotato extends Module {
    public AutoPotato() {
        super("AutoPotato", "One Potato , dont use it maybe lag!", Category.USELESS, true, false, false);
    }

    private final Setting<Boolean> yee = this.register(new Setting<Boolean>("yee", true));


    String PotatoMessage = "none";
    Integer rMax = 4;
    Integer rMin = 0;
    Integer rOut;



    @Override
    public void onEnable() {
        Random awas = new Random();
        rOut = awas.nextInt(rMax) % (rMax - rMin + 1) + rMin;

        if (rOut == 0) {
            PotatoMessage = "F";
        } else {
            if (rOut == 1) {
                PotatoMessage = "The best 1.12 server for anachy cpvp";
            }
            if (rOut == 2) {
                PotatoMessage = "OMG Lag again cwc";
            }
            if (rOut == 3) {
                PotatoMessage = "i went sleep and wakeup why STILL LAG";
            }
            if (rOut == 4) {
                PotatoMessage = "Funny server lagging everytime^";
            }
        }
        if (this.yee.getValue()) {
            while (true) { // yet i using while this autopotato is a potato xd
                if (M3dC3t.serverManager.isServerNotResponding()) {
                    if (M3dC3t.serverManager.serverRespondingTime() > 4444) {
                        mc.player.connection.sendPacket(new CPacketChatMessage("[AutoPotato] " + PotatoMessage));
                        break;
                    }
                }
            }
            this.disable();
        }
    }
}