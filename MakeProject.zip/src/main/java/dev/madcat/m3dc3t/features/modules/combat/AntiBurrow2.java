package dev.madcat.m3dc3t.features.modules.combat;

import dev.madcat.m3dc3t.features.modules.useless.CAT3INSTANT;
import dev.madcat.m3dc3t.features.setting.Setting;
import dev.madcat.m3dc3t.M3dC3t;
import dev.madcat.m3dc3t.features.Feature;
import dev.madcat.m3dc3t.features.modules.Module;
import skid.scat3.Util.BlockUtil;
import skid.scat3.Util.EntityUtil;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.gui.GuiHopper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

public class AntiBurrow2
extends Module {
    public static BlockPos pos;
    private final Setting<Double> range;
    private final Setting<Boolean> toggle;

    public AntiBurrow2() {
        super("AntiBurrow2", "anti", Category.COMBAT, true, false, false);
        this.range = (Setting<Double>) this.register(new Setting("Range", 5.0, 1.0, 8.0));
        this.toggle = (Setting<Boolean>) this.register(new Setting("Toggle", false));

    }
    private EntityPlayer getTarget(double d) {
        EntityPlayer entityPlayer = null;
        double d2 = Math.pow(d, 2.0) + 1.0;
        for (EntityPlayer entityPlayer2 : AntiBurrow2.mc.world.playerEntities) {
            if (EntityUtil.isntValid(entityPlayer2, d)) continue;
            if (M3dC3t.speedManager.getPlayerSpeed(entityPlayer2) > 10.0) {
                continue;
            }
            if (entityPlayer == null) {
                entityPlayer = entityPlayer2;
                d2 = AntiBurrow2.mc.player.getDistanceSq(entityPlayer2);
                continue;
            }
            if (AntiBurrow2.mc.player.getDistanceSq(entityPlayer2) >= d2) {
                continue;
            }
            entityPlayer = entityPlayer2;
            d2 = AntiBurrow2.mc.player.getDistanceSq(entityPlayer2);
        }
        return entityPlayer;
    }

    private boolean isInLiquid() {
        double d = AntiBurrow2.mc.player.posY + 0.01;
        for (int i = MathHelper.floor(AntiBurrow2.mc.player.posX); i < MathHelper.ceil(AntiBurrow2.mc.player.posX); ++i) {
            for (int j = MathHelper.floor(AntiBurrow2.mc.player.posZ); j < MathHelper.ceil(AntiBurrow2.mc.player.posZ); ++j) {
                BlockPos blockPos = new BlockPos(i, (int)d, j);
                if (!(AntiBurrow2.mc.world.getBlockState(blockPos).getBlock() instanceof BlockLiquid)) {
                    continue;
                }
                return true;
            }
        }
        return false;
    }

    private boolean isOnLiquid() {
        double d = AntiBurrow2.mc.player.posY - 0.03;
        for (int i = MathHelper.floor(AntiBurrow2.mc.player.posX); i < MathHelper.ceil(AntiBurrow2.mc.player.posX); ++i) {
            for (int j = MathHelper.floor(AntiBurrow2.mc.player.posZ); j < MathHelper.ceil(AntiBurrow2.mc.player.posZ); ++j) {
                BlockPos blockPos = new BlockPos(i, MathHelper.floor(d), j);
                if (!(AntiBurrow2.mc.world.getBlockState(blockPos).getBlock() instanceof BlockLiquid)) {
                    continue;
                }
                return true;
            }
        }
        return false;
    }

    @Override
    public void onUpdate() {
        if (Feature.fullNullCheck()) {
            return;
        }
        if (AntiBurrow2.mc.currentScreen instanceof GuiHopper) {
            return;
        }
        EntityPlayer entityPlayer = this.getTarget(this.range.getValue());
        if (this.toggle.getValue()) {
            this.disable();
        }
        if (entityPlayer == null) {
            return;
        }
        pos = new BlockPos(entityPlayer.posX, entityPlayer.posY + 0.5, entityPlayer.posZ);
        if (CAT3INSTANT.breakPos != null) {
            if (CAT3INSTANT.breakPos.equals(pos)) {
                return;
            }
            if (CAT3INSTANT.breakPos.equals(new BlockPos(AntiBurrow2.mc.player.posX, AntiBurrow2.mc.player.posY + 2.0, AntiBurrow2.mc.player.posZ))) {
                return;
            }
            if (CAT3INSTANT.breakPos.equals(new BlockPos(AntiBurrow2.mc.player.posX, AntiBurrow2.mc.player.posY - 1.0, AntiBurrow2.mc.player.posZ))) {
                return;
            }
            if (AntiBurrow2.mc.world.getBlockState(CAT3INSTANT.breakPos).getBlock() == Blocks.WEB) {
                return;
            }
        }
        if (AntiBurrow2.mc.world.getBlockState(pos).getBlock() != Blocks.AIR && AntiBurrow2.mc.world.getBlockState(pos).getBlock() != Blocks.WEB && AntiBurrow2.mc.world.getBlockState(pos).getBlock() != Blocks.REDSTONE_WIRE && !this.isOnLiquid() && !this.isInLiquid() && AntiBurrow2.mc.world.getBlockState(pos).getBlock() != Blocks.WATER && AntiBurrow2.mc.world.getBlockState(pos).getBlock() != Blocks.LAVA) {
            AntiBurrow2.mc.playerController.onPlayerDamageBlock(pos, BlockUtil.getRayTraceFacing(pos));
        }
    }


}

