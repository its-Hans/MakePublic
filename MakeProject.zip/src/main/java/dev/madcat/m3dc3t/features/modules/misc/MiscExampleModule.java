package dev.madcat.m3dc3t.features.modules.misc;

import dev.madcat.m3dc3t.features.modules.Module;
import dev.madcat.m3dc3t.features.setting.Setting;


import dev.madcat.m3dc3t.features.command.Command;
import net.minecraft.network.play.client.CPacketChatMessage;


public class MiscExampleModule extends Module
{
    public MiscExampleModule()
    {
        super("MiscExampleModule", "Module Description", Category.MISC, true, false, false);
    }

    private final Setting<Boolean> examb1 = this.register(new Setting<Boolean>("ExampleB1", true));


    private final Setting<Boolean> examb2 = this.register(new Setting<Boolean>("ExampleB2", true));

    private final Setting<Boolean> say = this.register(new Setting<Boolean>("ChatMessage", false));
    String f;


    @Override
    public void onEnable() {
        f = " ";
        if (this.examb1.getValue() | this.examb2.getValue()) {
            if (this.examb1.getValue()) {
                f = f + "b1 ";
            }
            if (this.examb2.getValue()) {
                f = f + "b2 ";
            }
        } else {
            f = f + "nothing";
        }

        if (this.say.getValue()) {
            mc.player.connection.sendPacket(new CPacketChatMessage("[Test] " + f));
        } else {
            Command.sendMessage(f);
        }
    }
    @Override
    public void onDisable()
    {
        f = " ";
    }
}