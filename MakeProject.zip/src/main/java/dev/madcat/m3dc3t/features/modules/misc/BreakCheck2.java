package dev.madcat.m3dc3t.features.modules.misc;

import java.util.HashMap;
import skid.scat3.Event.events.BlockBreakEvent;
import dev.madcat.m3dc3t.features.modules.Module;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class BreakCheck2
extends Module {
    public final HashMap<EntityPlayer, BlockPos> MineMap = new HashMap();
    private static BreakCheck2 INSTANCE = new BreakCheck2();

    @SubscribeEvent
    public void BrokenBlock2(BlockBreakEvent blockBreakEvent) {
        if (blockBreakEvent.getBreakerId() == BreakCheck2.mc.player.getEntityId()) {
            return;
        }
        if (blockBreakEvent.getPosition().getY() == -1) {
            return;
        }
        if (BreakCheck2.mc.world.getBlockState(new BlockPos(blockBreakEvent.getPosition())).getBlock() == Blocks.BEDROCK) {
            return;
        }
        this.MineMap.put((EntityPlayer)BreakCheck2.mc.world.getEntityByID(blockBreakEvent.getBreakerId()), blockBreakEvent.getPosition());
    }

    @Override
    public void onDisable() {
        this.MineMap.clear();
    }

    public static BreakCheck2 Instance() {
        if (INSTANCE == null) {
            INSTANCE = new BreakCheck2();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    public BreakCheck2() {
        super("Crit", "criticals", Module.Category.COMBAT, true, false, false);
        this.setInstance();
    }
}

