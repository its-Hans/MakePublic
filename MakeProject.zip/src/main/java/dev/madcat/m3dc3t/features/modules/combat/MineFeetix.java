package dev.madcat.m3dc3t.features.modules.combat;

import dev.madcat.m3dc3t.M3dC3t;
import dev.madcat.m3dc3t.features.modules.Module;
import dev.madcat.m3dc3t.features.setting.Setting;
import net.minecraft.entity.player.EntityPlayer;
import dev.madcat.m3dc3t.util.lCBlockUtil;

public class MineFeetix extends Module
{
    public static EntityPlayer target;
private final Setting<Double> range = this.register(new Setting<Double>("Range", 4.8, 1.0, 6.0));
private final Setting<Boolean> minebur = this.register(new Setting<Boolean>("MineBurrow", true));
    public MineFeetix() {
        super("MineFeetix", "descript", Category.COMBAT, true, false, false);
    }
}