package dev.madcat.m3dc3t.features.modules.useless;

import java.util.ArrayList;

import dev.madcat.m3dc3t.event.events.KuraBlockEvents;
import dev.madcat.m3dc3t.features.modules.Module;
import dev.madcat.m3dc3t.features.setting.Setting;
import dev.madcat.m3dc3t.util.BlockUtil;
import dev.madcat.m3dc3t.util.EntityUtil;
import dev.madcat.m3dc3t.util.InventoryUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.Event;

public class KuraFeetMine extends Module
{
    public final Setting<Integer> range;
    public final Setting<Boolean> disable;

    public EntityPlayer target;
    
    public KuraFeetMine()
    {
        super("KuraFeetMine", "city", Category.USELESS, true, false, false);
        this.range = (Setting<Integer>) this.register(new Setting("Range",  4,  0,  6));
        this.disable = (Setting<Boolean>) this.register(new Setting("autoToggle",  false));
    }
    
    public void onUpdate()
    {
        if (fullNullCheck()) {return;}
        try
        {
            if (this.disable.getValue()) {this.disable();}
            if (InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE) == -1) {return;}
            this.target = this.getTarget(this.range.getValue());
            if (this.target != null) {this.surroundMineBlock(this.target);}
        } catch (Exception ex) {}
    }
    
    public void surroundMineBlock(final EntityPlayer player)
    {
        final Vec3d a = player.getPositionVector();
        
        if (EntityUtil.getSurroundWeakness(a, 1, -1))
        {
            this.surroundMine(a, -1.0, 0.0, 0.0);
            return;
        }
        if (EntityUtil.getSurroundWeakness(a, 2, -1))
        {
            this.surroundMine(a, 1.0, 0.0, 0.0);
            return;
        }
        if (EntityUtil.getSurroundWeakness(a, 3, -1))
        {
            this.surroundMine(a, 0.0, 0.0, -1.0);
            return;
        }
        if (EntityUtil.getSurroundWeakness(a, 4, -1))
        {
            this.surroundMine(a, 0.0, 0.0, 1.0);
            return;
        }
        if (EntityUtil.getSurroundWeakness(a, 5, -1))
        {
            this.surroundMine(a, -1.0, 0.0, 0.0);
            return;
        }
        if (EntityUtil.getSurroundWeakness(a, 6, -1))
        {
            this.surroundMine(a, 1.0, 0.0, 0.0);
            return;
        }
        if (EntityUtil.getSurroundWeakness(a, 7, -1))
        {
            this.surroundMine(a, 0.0, 0.0, -1.0);
            return;
        }
        
        if (!EntityUtil.getSurroundWeakness(a, 8, -1)) {return;}
        this.surroundMine(a, 0.0, 0.0, 1.0);
    }
    
    public void surroundMine(final Vec3d pos, final double x, final double y, final double z)
    {
        final BlockPos position = new BlockPos(pos).add(x, y, z);
        if (!BlockUtil.canBreak(position)) {return;}
        if (InstantMine.breakPos != null || InstantMine.breakPos2 != null)
        {
            if (InstantMine.breakPos.equals(position)) {return;}
            if (InstantMine.breakPos.equals(new BlockPos(this.target.posX, this.target.posY, this.target.posZ)) && KuraFeetMine.mc.world.getBlockState(new BlockPos(this.target.posX, this.target.posY, this.target.posZ)).getBlock() != Blocks.AIR) {return;}
        }
        MinecraftForge.EVENT_BUS.post((Event)new KuraBlockEvents(position, BlockUtil.getRayTraceFacing(position)));
    }
    
    public EntityPlayer getTarget(final double range) {
        for (final EntityPlayer player : new ArrayList<EntityPlayer>(KuraFeetMine.mc.world.playerEntities)) {
            if (!EntityUtil.isntValid((Entity)player, range)) {
                if (!EntityUtil.isInHole((Entity)player)) {
                    continue;
                }
                if (KuraFeetMine.mc.player.getDistance((Entity)player) > range) {
                    continue;
                }
                return player;
            }
        }
        return null;
    }
}
