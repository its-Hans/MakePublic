package dev.madcat.m3dc3t.features.modules.useless;

import skid.sxulu.Event.x.EventClickBlock;
import dev.madcat.m3dc3t.event.events.PacketEvent;
import dev.madcat.m3dc3t.features.modules.Module;
import dev.madcat.m3dc3t.features.setting.Setting;
import dev.madcat.m3dc3t.util.InventoryUtil;
import dev.madcat.m3dc3t.util.Timer;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemSword;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

import skid.sxulu.Event.Event;
import skid.sxulu.Event.EventTarget;
import skid.sxulu.Event.x.EventPlayerDamageBlock;
import skid.sxulu.Event.x.EventSendPacket;

public class XuluMining extends Module {

    public Setting<XuluMining.Mode> mode;
    public Setting<Float> damage;
    public Setting<Boolean> tweaks;
    public Setting<Boolean> reset;
    public Setting<Boolean> noBreakAnim;
    public Setting<Boolean> noDelay;
    public Setting<Boolean> noSwing;
    public Setting<Boolean> allow;
    public Setting<Boolean> doubleBreak;
    public Setting<Boolean> webSwitch;
    public Setting<Boolean> noTrace;
    public Setting<Boolean> render;
    public Setting<Boolean> pickaxe;
    public Setting<Boolean> box;
    public Setting<Boolean> outline;
    public Setting<Integer> boxAlpha;
    public Setting<Float> lineWidth;

    public BlockPos currentPos;
    public IBlockState currentBlockState;
    private final Timer timer;
    private boolean isMining;
    private BlockPos lastPos;
    private EnumFacing lastFacing;

    public XuluMining() {
        super("XuluMining", "Speeds up mining.", Category.USELESS, true, false, false);
        this.tweaks = (Setting<Boolean>)this.register(new Setting("Tweaks", true));
        this.mode = (Setting<XuluMining.Mode>)this.register(new Setting("Mode",  XuluMining.Mode.PACKET, v -> (boolean)this.tweaks.getValue()));
        this.reset = (Setting<Boolean>)this.register(new Setting("Reset", true));
        this.damage = (Setting<Float>)this.register(new Setting("Damage", 0.7f, 0.0f, 1.0f, v -> this.mode.getValue() == XuluMining.Mode.DAMAGE && (boolean)this.tweaks.getValue()));
        this.noBreakAnim = (Setting<Boolean>)this.register(new Setting("NoBreakAnim", false));
        this.noDelay = (Setting<Boolean>)this.register(new Setting("NoDelay", false));
        this.noSwing = (Setting<Boolean>)this.register(new Setting("NoSwing", false));
        this.noTrace = (Setting<Boolean>)this.register(new Setting("noTrace", false));
        this.allow = (Setting<Boolean>)this.register(new Setting("AllowMultiTask", false));
        this.pickaxe = (Setting<Boolean>)this.register(new Setting("Pickaxe", false));
        this.doubleBreak = (Setting<Boolean>)this.register(new Setting("DoubleBreak", false));
        this.webSwitch = (Setting<Boolean>)this.register(new Setting("WebSwitch", false));
        this.render = (Setting<Boolean>)this.register(new Setting("Render", false));
        this.box = (Setting<Boolean>)this.register(new Setting("Box", false, v -> (boolean)this.render.getValue()));
        this.outline = (Setting<Boolean>)this.register(new Setting("Outline", true, v -> (boolean)this.render.getValue()));
        this.boxAlpha = (Setting<Integer>)this.register(new Setting("BoxAlpha", 85, 0, 255, v -> (boolean)this.box.getValue() && (boolean)this.render.getValue()));
        this.lineWidth = (Setting<Float>)this.register(new Setting("LineWidth", 1.0f, 0.1f, 5.0f, v -> (boolean)this.outline.getValue() && (boolean)this.render.getValue()));

        this.timer = new Timer();
        this.isMining = false;
        this.lastPos = null;
        this.lastFacing = null;
    }

    PacketEvent.Send packetE;
    @Override
    public void onUpdate() {
        if (mc.world == null || mc.player == null) {
            return;
        }
        if (this.currentPos != null) {
            if (!XuluMining.mc.world.getBlockState(this.currentPos).equals(this.currentBlockState) || XuluMining.mc.world.getBlockState(this.currentPos).getBlock() == Blocks.AIR) {
                this.currentPos = null;
                this.currentBlockState = null;
            }
            else if (this.webSwitch.getValue() && this.currentBlockState.getBlock() == Blocks.WEB && XuluMining.mc.player.getHeldItemMainhand().getItem() instanceof ItemPickaxe) {
                InventoryUtil.switchToHotbarSlot(ItemSword.class, false);
            }
        }
        if (this.noDelay.getValue()) {
            XuluMining.mc.playerController.blockHitDelay = 0;
        }
        if (this.isMining && this.lastPos != null && this.lastFacing != null && this.noBreakAnim.getValue()) {
            XuluMining.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, this.lastPos, this.lastFacing));
        }
        if (this.reset.getValue() && XuluMining.mc.gameSettings.keyBindUseItem.isKeyDown() && !this.allow.getValue()) {
            XuluMining.mc.playerController.isHittingBlock = false;
        }
    }

    @EventTarget
    public void onPacketSend(final EventSendPacket event) {
        if (mc.world == null || mc.player == null) {
            return;
        }
        if (Event.getEventState() == Event.State.PRE) {
            if (this.noSwing.getValue() && event.getPacket() instanceof CPacketAnimation) {
                packetE.setCanceled(true);
            }
            if (this.noBreakAnim.getValue() && event.getPacket() instanceof CPacketPlayerDigging) {
                final CPacketPlayerDigging packet =(CPacketPlayerDigging) event.getPacket();
                if (packet != null && packet.getPosition() != null) {
                    try {
                        for (final Entity entity : XuluMining.mc.world.getEntitiesWithinAABBExcludingEntity((Entity)null, new AxisAlignedBB(packet.getPosition()))) {
                            if (entity instanceof EntityEnderCrystal) {
                                this.showAnimation();
                                return;
                            }
                        }
                    }
                    catch (Exception ex) {}
                    if (packet.getAction().equals(CPacketPlayerDigging.Action.START_DESTROY_BLOCK)) {
                        this.showAnimation(true, packet.getPosition(), packet.getFacing());
                    }
                    if (packet.getAction().equals(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK)) {
                        this.showAnimation();
                    }
                }
            }
        }
    }
    
    @EventTarget
    public void onClickBlock(final EventClickBlock event) {
        if (mc.player == null || mc.world == null) {
            return;
        }
        if (this.reset.getValue() && XuluMining.mc.playerController.curBlockDamageMP > 0.1f) {
            XuluMining.mc.playerController.isHittingBlock = true;
        }
    }

    @EventTarget
    public void onBlockEvent(final EventPlayerDamageBlock event) {
        if (mc.player == null || mc.world == null) {
            return;
        }
        if (this.tweaks.getValue()) {
            if (canBreak(event.getPos())) {
                if (this.reset.getValue()) {
                    XuluMining.mc.playerController.isHittingBlock = false;
                }
                switch (this.mode.getValue()) {
                    case PACKET: {
                        if (this.currentPos == null) {
                            this.currentPos = event.getPos();
                            this.currentBlockState = XuluMining.mc.world.getBlockState(this.currentPos);
                            this.timer.reset();
                        }
                        XuluMining.mc.player.swingArm(EnumHand.MAIN_HAND);
                        XuluMining.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, event.getPos(), event.getFacing()));
                        XuluMining.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, event.getPos(), event.getFacing()));
                        packetE.setCanceled(true);
                        break;
                    }
                    case DAMAGE: {
                        if (XuluMining.mc.playerController.curBlockDamageMP >= this.damage.getValue()) {
                            XuluMining.mc.playerController.curBlockDamageMP = 1.0f;
                            break;
                        }
                        break;
                    }
                    case INSTANT: {
                        XuluMining.mc.player.swingArm(EnumHand.MAIN_HAND);
                        XuluMining.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, event.getPos(), event.getFacing()));
                        XuluMining.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, event.getPos(), event.getFacing()));
                        XuluMining.mc.playerController.onPlayerDestroyBlock(event.getPos());
                        XuluMining.mc.world.setBlockToAir(event.getPos());
                        break;
                    }
                }
            }
            if (this.doubleBreak.getValue()) {
                final BlockPos above = event.getPos().add(0, 1, 0);
                if (canBreak(above) && XuluMining.mc.player.getDistance((double)above.getX(), (double)above.getY(), (double)above.getZ()) <= 5.0) {
                    XuluMining.mc.player.swingArm(EnumHand.MAIN_HAND);
                    XuluMining.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, above, event.getFacing()));
                    XuluMining.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, above, event.getFacing()));
                    XuluMining.mc.playerController.onPlayerDestroyBlock(above);
                    XuluMining.mc.world.setBlockToAir(above);
                }
            }
        }
    }

    private void showAnimation(final boolean isMining, final BlockPos lastPos, final EnumFacing lastFacing) {
        this.isMining = isMining;
        this.lastPos = lastPos;
        this.lastFacing = lastFacing;
    }

    public void showAnimation() {
        this.showAnimation(false, null, null);
    }

    public String getHudInfo() {
        return this.mode.getValue().name();
    }

    public static boolean canBreak(final BlockPos pos) {
        final IBlockState blockState = mc.world.getBlockState(pos);
        final Block block = blockState.getBlock();
        return block.getBlockHardness(blockState, mc.world, pos) != -1.0f;
    }


    public enum Mode
    {
        PACKET,
        DAMAGE,
        INSTANT;
    }
}
