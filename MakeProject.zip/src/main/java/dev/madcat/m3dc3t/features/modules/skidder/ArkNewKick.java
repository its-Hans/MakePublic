package dev.madcat.m3dc3t.features.modules.skidder;

import dev.madcat.m3dc3t.M3dC3t;
import dev.madcat.m3dc3t.event.events.Render2DEvent;
import dev.madcat.m3dc3t.features.modules.Module;
import dev.madcat.m3dc3t.features.modules.useless.AntiCity;
import dev.madcat.m3dc3t.features.setting.Setting;
import dev.madcat.m3dc3t.util.BlockUtil;
import dev.madcat.m3dc3t.util.EntityUtil;
import dev.madcat.m3dc3t.util.InventoryUtil;
import dev.madcat.m3dc3t.util.MathUtil;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import net.minecraft.block.BlockPistonBase;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class ArkNewKick extends Module
{
    public static EntityPlayer target;
    private final Setting<Float> range;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> disable;
    private final Setting<Boolean> debug;
    private final Setting<Boolean> BreakCrystal;
    int one;
    int two;
    int three;
    int four;
    
    public ArkNewKick() {
        super("ArKickXD", "WTF", Category.SKIDDER, true, false, false);
        this.range = (Setting<Float>)this.register(new Setting("Range", (Object)8.0f, (Object)1.0f, (Object)12.0f));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (Object)true));
        this.disable = (Setting<Boolean>)this.register(new Setting("Disable", (Object)true));
        this.debug = (Setting<Boolean>)this.register(new Setting("Debug", (Object)true));
        this.BreakCrystal = (Setting<Boolean>)this.register(new Setting("BreakCrystal", (Object)true));
        this.one = 0;
        this.two = 0;
        this.three = 0;
        this.four = 0;
    }
    
    public void onEnable() {
        if (this.BreakCrystal.getValue()) {
            breakcrystal();
        }
    }
    
    public void onUpdate() {
        if (InventoryUtil.findHotbarBlock((Class)BlockPistonBase.class) == -1) {
            return;
        }
        if (InventoryUtil.findHotbarBlock(Blocks.REDSTONE_BLOCK) == -1) {
            return;
        }
        ArkNewKick.target = this.getTarget((float)this.range.getValue());
        if (ArkNewKick.target == null) {
            return;
        }
        final BlockPos pos = new BlockPos(ArkNewKick.target.posX, ArkNewKick.target.posY, ArkNewKick.target.posZ);
        final float[] angle = MathUtil.calcAngle(ArkNewKick.mc.player.getPositionEyes(ArkNewKick.mc.getRenderPartialTicks()), new Vec3d((double)(pos.getX() + 0.5f), (double)(pos.getY() + 0.5f), (double)(pos.getZ() + 0.5f)));
        if (angle[1] >= -71.0f && angle[1] <= 71.0f && angle[0] >= -51.0f && angle[0] <= 51.0f && (this.getBlock(pos.add(0, 1, 1)).getBlock() == Blocks.AIR | this.getBlock(pos.add(0, 1, 1)).getBlock() == Blocks.PISTON)) {
            this.perform(pos.add(0, 1, 1));
            if (this.getBlock(pos.add(0, 2, 1)).getBlock() == Blocks.AIR) {
                this.perform1(pos.add(0, 2, 1));
            }
            else if (this.getBlock(pos.add(0, 2, 1)).getBlock() != Blocks.REDSTONE_BLOCK) {
                if (this.getBlock(pos.add(1, 1, 1)).getBlock() == Blocks.AIR) {
                    this.perform1(pos.add(1, 1, 1));
                }
                else if (this.getBlock(pos.add(1, 1, 1)).getBlock() != Blocks.REDSTONE_BLOCK) {
                    if (this.getBlock(pos.add(0, 1, 2)).getBlock() == Blocks.AIR) {
                        this.perform1(pos.add(0, 1, 2));
                    }
                    else if (this.getBlock(pos.add(0, 1, 2)).getBlock() != Blocks.REDSTONE_BLOCK && this.getBlock(pos.add(-1, 1, 1)).getBlock() == Blocks.AIR) {
                        this.perform1(pos.add(-1, 1, 1));
                    }
                }
            }
            ++this.one;
        }
        else if (angle[1] >= -71.0f && angle[1] <= 71.0f && (angle[0] >= 129.0f | angle[0] <= -129.0f) && (this.getBlock(pos.add(0, 1, -1)).getBlock() == Blocks.AIR | this.getBlock(pos.add(0, 1, -1)).getBlock() == Blocks.PISTON)) {
            this.perform(pos.add(0, 1, -1));
            if (this.getBlock(pos.add(0, 2, -1)).getBlock() == Blocks.AIR) {
                this.perform1(pos.add(0, 2, -1));
            }
            else if (this.getBlock(pos.add(0, 2, -1)).getBlock() != Blocks.REDSTONE_BLOCK) {
                if (this.getBlock(pos.add(1, 1, -1)).getBlock() == Blocks.AIR) {
                    this.perform1(pos.add(1, 1, -1));
                }
                else if (this.getBlock(pos.add(1, 1, -1)).getBlock() != Blocks.REDSTONE_BLOCK) {
                    if (this.getBlock(pos.add(0, 1, -2)).getBlock() == Blocks.AIR) {
                        this.perform1(pos.add(0, 1, -2));
                    }
                    else if (this.getBlock(pos.add(0, 1, -2)).getBlock() != Blocks.REDSTONE_BLOCK && this.getBlock(pos.add(-1, 1, -1)).getBlock() == Blocks.AIR) {
                        this.perform1(pos.add(-1, 1, -1));
                    }
                }
            }
            ++this.two;
        }
        else if (angle[1] >= -71.0f && angle[1] <= 71.0f && angle[0] <= -51.0f && angle[0] >= -129.0f && (this.getBlock(pos.add(1, 1, 0)).getBlock() == Blocks.AIR | this.getBlock(pos.add(1, 1, 0)).getBlock() == Blocks.PISTON)) {
            this.perform(pos.add(1, 1, 0));
            if (this.getBlock(pos.add(1, 2, 0)).getBlock() == Blocks.AIR) {
                this.perform1(pos.add(1, 2, 0));
            }
            else if (this.getBlock(pos.add(1, 2, 0)).getBlock() != Blocks.REDSTONE_BLOCK) {
                if (this.getBlock(pos.add(1, 1, 1)).getBlock() == Blocks.AIR) {
                    this.perform1(pos.add(1, 1, 1));
                }
                else if (this.getBlock(pos.add(1, 1, 1)).getBlock() != Blocks.REDSTONE_BLOCK) {
                    if (this.getBlock(pos.add(2, 1, 0)).getBlock() == Blocks.AIR) {
                        this.perform1(pos.add(2, 1, 0));
                    }
                    else if (this.getBlock(pos.add(2, 1, 0)).getBlock() != Blocks.REDSTONE_BLOCK && this.getBlock(pos.add(1, 1, -1)).getBlock() == Blocks.AIR) {
                        this.perform1(pos.add(1, 1, -1));
                    }
                }
            }
            ++this.three;
        }
        else if (angle[1] >= -71.0f && angle[1] <= 71.0f && angle[0] >= 51.0f && angle[0] <= 129.0f && (this.getBlock(pos.add(-1, 1, 0)).getBlock() == Blocks.AIR | this.getBlock(pos.add(-1, 1, 0)).getBlock() == Blocks.PISTON)) {
            this.perform(pos.add(-1, 1, 0));
            if (this.getBlock(pos.add(-1, 2, 0)).getBlock() == Blocks.AIR) {
                this.perform1(pos.add(-1, 2, 0));
            }
            else if (this.getBlock(pos.add(-1, 2, 0)).getBlock() != Blocks.REDSTONE_BLOCK) {
                if (this.getBlock(pos.add(-1, 1, 1)).getBlock() == Blocks.AIR) {
                    this.perform1(pos.add(-1, 1, 1));
                }
                else if (this.getBlock(pos.add(-1, 1, 1)).getBlock() != Blocks.REDSTONE_BLOCK) {
                    if (this.getBlock(pos.add(-2, 1, 0)).getBlock() == Blocks.AIR) {
                        this.perform1(pos.add(-2, 1, 0));
                    }
                    else if (this.getBlock(pos.add(-2, 1, 0)).getBlock() != Blocks.REDSTONE_BLOCK && this.getBlock(pos.add(-1, 1, -1)).getBlock() == Blocks.AIR) {
                        this.perform1(pos.add(-1, 1, -1));
                    }
                }
            }
            ++this.four;
        }
        else if (this.disable.getValue()) {
            this.toggle();
        }
        if ((boolean)this.disable.getValue() && (this.one == 4 | this.two == 4 | this.three == 4 | this.four == 4)) {
            this.toggle();
        }
    }
    
    public void onDisable() {
        this.one = 0;
        this.two = 0;
        this.three = 0;
        this.four = 0;
    }
    
    public String getDisplayInfo() {
        if (ArkNewKick.target != null) {
            return ArkNewKick.target.getName();
        }
        return null;
    }
    
    public void onRender2D(final Render2DEvent event) {
        if (!(boolean)this.debug.getValue()) {
            return;
        }
        if (InventoryUtil.findHotbarBlock((Class)BlockPistonBase.class) == -1) {
            return;
        }
        if (InventoryUtil.findHotbarBlock(Blocks.REDSTONE_BLOCK) == -1) {
            return;
        }
        ArkNewKick.target = this.getTarget((float)this.range.getValue());
        if (ArkNewKick.target == null) {
            return;
        }
        final BlockPos pos = new BlockPos(ArkNewKick.target.posX, ArkNewKick.target.posY, ArkNewKick.target.posZ);
        final float[] angle = MathUtil.calcAngle(ArkNewKick.mc.player.getPositionEyes(ArkNewKick.mc.getRenderPartialTicks()), new Vec3d((double)(pos.getX() + 0.5f), (double)(pos.getY() + 0.5f), (double)(pos.getZ() + 0.5f)));
        ArkNewKick.mc.fontRenderer.drawString(angle[0] + "   " + angle[1], 200.0f, 200.0f, 255, true);
    }
    
    private EntityPlayer getTarget(final double range) {
        EntityPlayer target = null;
        double distance = Math.pow(range, 2.0) + 1.0;
        for (final EntityPlayer player : ArkNewKick.mc.world.playerEntities) {
            if (!EntityUtil.isntValid((Entity)player, range)) {
                if (M3dC3t.speedManager.getPlayerSpeed(player) > 10.0) {
                    continue;
                }
                if (target == null) {
                    target = player;
                    distance = ArkNewKick.mc.player.getDistanceSq((Entity)player);
                }
                else {
                    if (ArkNewKick.mc.player.getDistanceSq((Entity)player) >= distance) {
                        continue;
                    }
                    target = player;
                    distance = ArkNewKick.mc.player.getDistanceSq((Entity)player);
                }
            }
        }
        return target;
    }
    
    private IBlockState getBlock(final BlockPos block) {
        return ArkNewKick.mc.world.getBlockState(block);
    }
    
    private void perform(final BlockPos pos) {
        final int old = AntiCity.mc.player.inventory.currentItem;
        if (ArkNewKick.mc.world.getBlockState(pos).getBlock() == Blocks.AIR) {
            ArkNewKick.mc.player.inventory.currentItem = InventoryUtil.findHotbarBlock((Class)BlockPistonBase.class);
            ArkNewKick.mc.playerController.updateController();
            BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, (boolean)this.rotate.getValue(), true, false);
            ArkNewKick.mc.player.inventory.currentItem = old;
            ArkNewKick.mc.playerController.updateController();
        }
    }
    
    private void perform1(final BlockPos pos) {
        final int old = AntiCity.mc.player.inventory.currentItem;
        if (ArkNewKick.mc.world.getBlockState(pos).getBlock() == Blocks.AIR) {
            ArkNewKick.mc.player.inventory.currentItem = InventoryUtil.findHotbarBlock(Blocks.REDSTONE_BLOCK);
            ArkNewKick.mc.playerController.updateController();
            BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, (boolean)this.rotate.getValue(), true, false);
            ArkNewKick.mc.player.inventory.currentItem = old;
            ArkNewKick.mc.playerController.updateController();
        }
    }
    
    public static void breakcrystal() {
        for (final Object crystal : (List)ArkNewKick.mc.world.loadedEntityList.stream().filter(e -> e instanceof EntityEnderCrystal && !e.isDead).sorted(Comparator.comparing(e -> ArkNewKick.mc.player.getDistance(e))).collect(Collectors.toList())) {
            if (crystal instanceof EntityEnderCrystal) {
                if (ArkNewKick.mc.player.getDistance((Entity) crystal) > 4.0f) {
                    continue;
                }
                ArkNewKick.mc.player.connection.sendPacket((Packet)new CPacketUseEntity((Entity) crystal));
                ArkNewKick.mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.OFF_HAND));
            }
        }
    }
}
