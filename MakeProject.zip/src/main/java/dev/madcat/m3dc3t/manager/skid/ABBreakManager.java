package dev.madcat.m3dc3t.manager.skid;

import java.util.HashMap;
import java.util.Map;
import dev.madcat.m3dc3t.features.Feature;
import dev.madcat.m3dc3t.features.modules.useless.InstantMine;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.server.SPacketBlockBreakAnim;
import net.minecraft.util.math.BlockPos;

public class ABBreakManager
extends Feature {
    public static Map<String, BlockPos> map = new HashMap<String, BlockPos>();

    public static boolean isMine(BlockPos pos, boolean self) {
        for (Map.Entry<String, BlockPos> block : map.entrySet()) {
            if (!block.getValue().equals((Object)pos)) continue;
            return true;
        }
        return self && InstantMine.breakPos != null && InstantMine.breakPos.equals((Object)pos);
    }

    public static boolean SelfMine(BlockPos pos) {
        return InstantMine.breakPos != null && InstantMine.breakPos.equals((Object)pos);
    }

    public void onPacketReceive(SPacketBlockBreakAnim packet) {
        BlockPos pos = packet.getPosition();
        Entity breaker = ABBreakManager.mc.world.getEntityByID(packet.getBreakerId());
        if (breaker == null) {
            return;
        }
        map.put(breaker.getName(), pos);
    }
}

