package dev.madcat.m3dc3t.util;

import net.minecraft.client.Minecraft;

public interface MinecraftInstance {
    public static final Minecraft mc = Minecraft.getMinecraft();
}
