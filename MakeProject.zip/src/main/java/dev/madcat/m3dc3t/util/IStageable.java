package dev.madcat.m3dc3t.util;

public interface IStageable {

    Stage getStage();
    void setStage(Stage stage);

}
