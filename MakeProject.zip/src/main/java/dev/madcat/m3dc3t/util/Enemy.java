package dev.madcat.m3dc3t.util;

public class Enemy {
    public String username;

    public Enemy(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }
}