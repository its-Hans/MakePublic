package dev.madcat.m3dc3t.util;

public interface IFriendable {
    String getAlias();
    void setAlias(String alias);
}
