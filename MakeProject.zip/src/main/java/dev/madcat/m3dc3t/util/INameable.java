package dev.madcat.m3dc3t.util;

public interface INameable {

    String getName();
    String getDisplayName();
    void setName(String name);
    void setDisplayName(String displayName);

}
