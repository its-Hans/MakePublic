package dev.madcat.m3dc3t.util;

public enum Stage {
    PRE,
    POST
}
