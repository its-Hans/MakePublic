package dev.madcat.m3dc3t.util.skidding;

public class GLTexture
{
    private final int id;
    
    public GLTexture(final int id) {
        this.id = id;
    }
    
    public int getId() {
        return this.id;
    }
}
