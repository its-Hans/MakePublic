package dev.madcat.m3dc3t.util;

import net.minecraft.client.Minecraft;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

public class lCBlockUtil
        implements Util {
    public static BlockPos blockpos;
    public static EnumFacing facing;
    private static Minecraft mc;
    public static void onPlayerDmg(){
        lCBlockUtil.mc.playerController.onPlayerDamageBlock(blockpos, BlockUtil.getRayTraceFacing(blockpos));
    }
    public static void CPacketDig(){
        mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, blockpos, facing));
        mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, blockpos, facing));
    }
}